# Current implementation and evidence queue

This file is generated from the current explicitly reviewed ledger. It replaces the initial gap list: items already implemented are omitted. The complete per-clause review and standing-rule table are in `closeout-review.md`.

Current clauses: 265 implemented, 7 partial, 3 pending, 7 deferred, 1 superseded. Each open record below states the concrete remaining work; a missing finished product is not automatically a blocker for an explained model.

## Source, geometry or verification work

| Clause | Scenes | Remaining work |
| --- | --- | --- |
| `F27.shlLattice3d.2` | `a_arches`, `a_lattice` | Markers are not force magnitude or equilibrium results, and there is no validated curved-shell response. |
| `F27.shlLattice3d.3` | `a_arches` | It does not show stress spreading under a specified hand load or distinguish local stress intensity. |

## Unavailable source or direct comparison evidence

| Clause | Scenes | Remaining work |
| --- | --- | --- |
| `F27.flagships.1` | `a_price`, `a_market`, `a_rank` | The data are not a matched test set; Starlight X endurance is still unpublished, and some prices use launch MSRP rather than one common date. |
| `F27.arc.1` | `a_bridge`, `a_direct` | The exact personal tensioner photographs and real dimensions are unavailable, so accurate reproduction of that specific tensioner is not established. |
| `F27.clk_pomtune.3` | `a_rails` | A named competitor, sample/revision, common datums, instrument and matched loaded measurements are still missing. |
| `F27.shcArms.1` | `a_pcb`, `a_board` | The rival arms are a schematic, not the actual referenced G-Wolves board forms; Brock's personal photos remain unavailable. |
| `F27.shcArms.3` | `a_pcb` | The F28.3 photograph itself is absent, so exact photographic fidelity and failure-location tracing cannot be closed. |
| `F27.wheel.1` | `a_wheel` | No plastic/rubber wheel test group has been weighed, so the requested main average comparison cannot be made. |
| `F27.wheel.2` | `a_wheel` | These reports do not form the requested common-protocol test group; sample revisions, scale readings and included parts remain missing. |

## Explicit design approval or deferral

| Clause | Scenes | Remaining work |
| --- | --- | --- |
| `F27.shlsheet1.5` | `a_seams` | Sticker design/selection remains undecided; omission is not design approval. |
| `F27.shlsheet2.1` | `a_close` | The bottom cover remains explicitly deferred; this no-note rating cannot override the later rejection or approve geometry. |
| `F27.pltPlate.2` | `a_close` | No bottom-cover geometry has been approved; later development must start from the rejection, not from an archived completion claim. |
| `F27.pltSim.1` | `a_close` | The physical cover and its simulation remain for a later requested development round. |
| `F27.pltOptions.2` | `a_close` | A later design round and Brock's decision are still required, including the associated final shell-switch notch. |
| `F27.srf_gripmap.1` | `a_grip` | The actual pattern still requires Brock’s requested aesthetic/ergonomic review; its optimized final friction performance is not established. |
| `F27.srf_marks.1` | `a_surface` | Decorative engraving choices remain deferred; the rating supplies no final approved mark design. |
| `F27.details.1` | `a_surface` | Final decorative details remain deferred rather than treated as completed by omission. |

The schematic front-gap comparison and same-material skate-area model are implemented and therefore absent from this queue. The specifically requested weighed wheel test group and direct named-rival tolerance comparison remain source boundaries. The old fitted price frontier is explicitly superseded by a direct scatter, rather than falsely marked as a repaired curve. A completed teaching model still does not validate whole-mouse strength, runtime, latency, wear, ergonomic performance or manufactured fit.
