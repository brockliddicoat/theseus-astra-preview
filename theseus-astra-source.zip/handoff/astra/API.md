# Independent Astra film contract

New implementation lives in `astra/film/`. Original `deck/` is reference only. Do not import Sol scenes.

Stage: 1600 x 900. Canvas draw each frame. Fixed typography: Inter (bundled original font, extracted by build), 54px header, 27px subtitle, diagram labels >=23, 19px source line. Palette D.C: bg #101214, ink #f7f6f2, mute #a8adb5, blue #398cff, yellow #e8c34a, red #ef6267, panel #1b1e22, line #484e56. Flat surfaces. Helpers available through global D. Every scene first frame shows header and meaningful part context, not empty/fade-only frame.

Register: `Film.add({id:'a_...', title:'UPPERCASE TITLE', chapter:'Clicks', duration:18, old:['arc'], sources:[{label:'...',url:'https://...',note:'evidence boundary'}], evidence:'Short clear model/target/source boundary', beats:[{t:0,label:'...'},...], draw(t){...}, checks(t){return {namedState:number,...}}})` in an IIFE. Drawing time seconds clamped >=0. Each scene settles before duration-2 and holds. No random calls; procedural randomness via deterministic indices. `checks` exposes actual parameters driving draw for causal testing. The register order is later fixed by root manifest.

Renderer draws header at (70,90), subtitle/evidence line optional at (70,132), bottom scene caption at y815 and evidence at y862. Draw content rectangle x60..1540 y180..760; do not draw outside it. `D.caption(text)` overrides current bottom caption. `D.evidence(text)` overrides bottom source line. Keep captions <=95 chars and evidence <=145 chars. Display intermediate concept words inside draw as needed but never collide with header/footer.

Helpers (plain canvas is fine too):
`D.ctx` active context. `D.C` colors. `D.p(t,a,b)` smoothstep 0..1, `D.lin(t,a,b)` linear 0..1, `D.lerp(a,b,p)`, `D.clamp(x,a=0,b=1)`.
`D.text(str,x,y,size=26,color=D.C.ink,align='left',weight=600)` baseline alphabetic. Records hit boxes and supports per-scene direct text edit.
`D.wrap(str,x,y,width,size=26,color=D.C.ink,lineHeight=34)` wraps words, returns next y.
`D.line(x1,y1,x2,y2,color=D.C.line,width=3,dash=[])`; `D.path(points,{stroke,fill,width=3,close=false,dash=[]})` points arrays; `D.bezier(points,color,width)` manually use ctx for curves.
`D.rect(x,y,w,h,fill=D.C.panel,r=6,stroke=null,width=2)`; `D.circle(x,y,r,fill,stroke=null,width=2)`.
`D.arrow(x1,y1,x2,y2,color=D.C.ink,width=4)` with arrowhead; `D.dim(x1,y1,x2,y2,label,color=D.C.mute)`.
`D.group(x,y,scale,angle,fn)` save/translate/scale/rotate radians/restore. `D.alpha(a,fn)` save alpha.
`D.label(str,x,y,color=D.C.mute)` size23. `D.badge` NOT provided: use plain text.
`D.bar(x,y,w,h,v,max,color,label,value)` horizontal bar with label above and value at right.
`D.mouse(x,y,scale=1,{color=D.C.ink,fill=null,seam=true})` drawn from baseline simplified Sora top outline, width ~190,height360, nose at y-180. No raw scan. Plain silhouette for density.
`D.hand(x,y,scale=1,{press=0})` simple monochrome fingertip for load context.
`D.force(x,y,length,label,color=D.C.ink)` downward arrow, force label.
`D.phase(t, [{t,label},...])` returns latest label; use caption for causal narration.

Owner files:
- root: engine.js, player.js, intro.js, index.html, build.py, QA, publishing.
- mechanics: mechanics.js (12-15 scenes; strongest ideas take priority).
- electronics_surface: systems.js (10-12 scenes; can combine closely related demonstrations without tiny type).
- feedback_integrity: ledger.json + requirements/report + review-data.js builder if needed. Root builds review UI; ledger final contract follows.

Motion sequence: establish context immediately, assembly/input 0..3s, rival response 3..7s, correction / same input 7..13s, held before/after 13..18s. Not every scene needs exact timing. Move real geometry and inputs. Before case remains visible in final frame. Numerical comparisons are sources or conditional calculations; geometry deformation explicitly illustrative when not a solve.

Root story allocation (IDs may be proposed and adjusted): cover, inertia/density, honest weight, market, price, then direct drive / rails / bridge / front stops / seams / SPDT, focus/support, shell thinwall/lattice/arches/fillets/whole PCB/tolerance, surface/grip/wheel, electronics/web/timing/wiring/battery/board, shape/repair, close. No mandatory missed shot story. Comfort, feel, wear, battery are often the better benefit.

2D is primary. For spatial assembly choose code-drawn projected geometry with explicit mode support only where implemented. Do not expose a fake 3D toggle. Root will integrate real 3D support separately if warranted. Never copy hidden raw scans. Final saved artifact must be reproducible and offline standalone.
