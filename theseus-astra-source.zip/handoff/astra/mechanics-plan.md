# independent mechanical motion plan

The mechanical package is fourteen scenes in `film/mechanics.js`. Every scene starts with its title and recognizable part context, performs a real geometric action under a stated shared input, and holds the comparison. Theseus is blue; comparison yellow is sparse; red marks a fault. Geometry is procedural code. The original baseline and supplied references are read-only context; no Sol scene implementation is used.

## scene manifest

| id | causal demonstration | inherited content carried |
|---|---|---|
| `a_direct` | Fixed PCB and switch; one press path approaches both plungers. Project the same path speed onto a 20-degree misaligned axis versus the aligned GT01-style axis. Freeze between threshold crossings, then hold both travel bars. | clicks, arc, clk_wedge |
| `a_rails` | Whole trigger context into an enlarged front view. Same off-center press racks an unguided trigger; two equal guided posts translate together. Show the identical module rotated for the shell-held side switch. | anchors, sidebuttons, clk_pomtune |
| `a_bridge` | A fixed rear screw, trigger arm and switch establish the assembly. Equal press bends a stiff unrelieved arm diffusely; an integral thin-center bridge concentrates the intended flex, without fillets where it meets the trigger. | tensioner, clk_tenmat |
| `a_front` | Two finger positions on the same trigger. A curved front edge lands one side first and rolls; Theseus's straight stop lands across its width. Shallowing comfort grooves retain finger contact without making the stop curved. | clk_front |
| `a_seams` | Plan view and one continuous center split establish location. Finger paths cross an exposed outer seam; move the split toward the center and the cutout toward the wall/ceiling, then repeat the same sweep. Straight rear cutouts remain visible. | cutouts, shlsheet1 |
| `a_spdt` | Large real three-terminal contact diagram: COM touches NC at rest, breaks NC in transit, then touches NO. A synchronized state strip distinguishes electrical edge from physical travel; release reverses the sequence. | clk_spdt, latency, clk_debounce, clk_wait, clk_methods |
| `a_focus` | A schematic sensor camera captures a drawn weave, then shifts relative to its lens/plane. The actual same pattern spreads through a deterministic blur kernel. Paired displacement and focus strip link structural deflection to image contrast. | gld_camera, gld_corr, gld_blur, focus |
| `a_support` | Same illustrative palm load on an underside section: edge skates leave the lens span free; sensor-adjacent dots shorten that span. Wide remote skates are contrasted with accurately located small supports. | dots, gld_sag, gld_under, gld_module |
| `a_ruler` | One 2.000 g rectangular beam bends flat, rotates onto its edge, receives the same 10 N illustrative center load, then holds both profiles. | materials, thinwall, shlHotspot, shlMargin |
| `a_material` | Equal-weight fixed-footprint strips explain why lower density buys thickness and thickness buys bending stiffness. The screen keeps stiffness and tensile strength in separate named jobs. | shlSpecific, shlScatter, shlPick, shlNoPick, shlWork |
| `a_lattice` | Pin-jointed four-bar frame racks under lateral input; a diagonal closes the mechanism. A separate width sweep shows axial stiffness proportional to width and in-plane bending stiffness proportional to width cubed. | lattice, shlDeterminate, shlThin, shlShell3d |
| `a_arches` | A hanging chain settles between supports and flips to an arch. Force follows the continuous arch to its feet; multiple continuous families interweave into a curved shell, revealing triangles at intersections. | shbArches, shbPress, shbThrust, shbBend |
| `a_fillets` | The same channel corner is shown sharp and rounded. A load path crowds the sharp root; flow-aligned fibre markers follow the rounded channel. A cutter reaches the rounded root; no unsupported shell multiplier. | fillet, filletsize, shbFibres, shbWidth, shbMill, shbMillDirect, shbTol |
| `a_pcb` | A woven FR4 strip becomes the approved board footprint. Narrow illustrative arms concentrate attachment load; broad opposing anchors use the whole board as a tie. Pads seat at contact to prevent rubbing. | shlPcbRib, shcCarry, shcArms, shlStructs, grind |

Root owns inertia and tolerance stack. Board detailed placement is coordinated with the electronics lane. Bottom-cover choices, final side-seam approval, physical first-fit/rethread simulations and unknown actual tensioner dimensions remain deferred.

## geometric invariants

- PCB never moves with a click. Contact leaf pivots from a fixed COM; NC/NO contacts stay fixed. A break-before-make transfer contains a both-open interval and never simultaneously connects NC and NO.
- All two guide posts, POM contact pads and side-button versions use the same dimensions and construction function. Side switches are full-size and held by shell, without a side PCB. Measured rival rail gaps are unavailable; no invented tolerance measurements.
- GT01-style body uses the supplied Gateron side render and `GT01-PLUNGER.md`: 20-degree body; no fourth pin; cap long dimension across X (2.1 mm) versus 1.5 mm along body, 0.80 mm proud; travel along `[0,cos20,sin20]`. The old 0.45 mm lower walls are superseded by visibly thicker, uniform illustrative 0.80 mm walls. This is a render-derived design representation, not a published Gateron drawing or verified manufactured dimension.
- One main split continues through the wheel; no central strip or fork. Rear trigger cutout is straight. Bridge roots meet squarely; no reintroduced taller fulcrum (#59 was abandoned).
- Sensor supports sit at x ±11.5 mm relative to the lens and move forward with the lens. The mouse balance remains at the body center. Corner ledges are connected and filleted into the rim; no floating skate mounts.
- Arches are smooth continuous members terminating on the lower support rim. Triangles arise where arch families intersect. No polyline that merely draws triangles into a dome is sold as a continuous arch.
- Board plan 5 is the basis, with F30.25 corrections: mirror-pair holes; centered chamfered/filleted wheel bay; rear notch length equals side-notch length; USB-C back 1.05 mm; 0.44 mm leg web; 1.60 mm overhang; bay front z44.13; one notch depth 3.61 mm; consistent tangent fillets. The 4.05 mm shell-opening mismatch remains for the shell round.

## numerical and evidence invariants

- `cos20 = 0.93969262`; axial component 94.0% to 100.0%. Relative axial-force gain 6.4178%. Approved **6% sooner** means `1-cos20 = 6.0307%` under equal travel and prescribed path speed. The optional illustrative `0.35 mm /0.1 mm/ms` segment is 3.7246 ms to 3.5000 ms; it is not reaction time or press-to-PC latency. The constant-force model instead gives 3.0623%, so the chosen assumption stays visible.
- 70 microseconds is an electrical design target measured from an electrical edge, not the time from the start of finger travel. The SPDT scene can explain separate NC/NO states without promising a finished debounce algorithm.
- 0.2 mm focus band is Brock's design criterion, compared with his 0.4 mm setup example. No recovered PAW3970 data proves this range. Blur and support deformation are clearly explanatory; neither produces claimed measured tracking/aim improvement or zero sag.
- Ruler: length60 mm, width10 mm, depth3.3 mm, density1.01 g/cm3, E13.5 GPa, illustrative center load10 N. Mass1.9998 g. Euler-Bernoulli stiffness ratio after rotation9.182736; calculated deflections0.11131 mm and0.01212 mm. Strength capacity at equal stress is3.0303, not9.1827. Do not relabel a beam result as a mouse-shell measurement.
- Fixed-footprint, free-thickness bending index is `E^(1/3)/rho`; equal-mass stiffness scales as `E/rho^3`. Halving thickness yields half mass, one-eighth bending stiffness, one-quarter same-stress capacity. A pin-jointed triangle removes in-plane racking; it does not prove arbitrary shell rigidity or immunity to buckling.
- FR4 source: glass-fabric epoxy, typical longwise tensile430 MPa, density1.85 g/cm3, longwise flexural modulus20 GPa. Stronger and stiffer are distinct. No unvalidated whole-board `18x` hotspot or `1.8x` shell-stiffness claim.
- Do not reproduce old `90% of grams work`, 21x arch strength, zero-micron sag, or 26-point sharper metrics as measurements. Detailed shell deformation here is an explanatory model unless separately solved and validated.
- Missing personal G-Wolves broken-arm photos and matched rival rail measurements remain open in the ledger. A diagram can explain the principle but cannot close those clauses.

## source anchors freshly inspected

- Omron, basic switches: https://www.ia.omron.com/data_pdf/guide/29/microswitch_tg_e_3_2.pdf (COM/NC/NO, snap action and mechanical transfer; no Theseus electrical timing claim).
- Open University ruler demonstration: https://www.open.edu/openlearn/science-maths-technology/design-innovation/design/content-section-6.5
- TeachEngineering straw bridge activity: https://www.teachengineering.org/activities/cub_brid_lesson01_activity2
- University of Iowa catenary demonstration: https://instructional-resources.physics.uiowa.edu/1j3090-catenary
- Envalior radii and chamfers: https://www.envalior.com/en-us/radii-and-chamfers (geometry-specific stress concentration and flow guidance).
- Envalior fibre-orientation fatigue use case: https://assets.envalior.com/document_0qbautli6p42b89pimtu9e7f2n/default/inline/document/Envalior_UseCases_Fatigue.pdf (orientation and flow modeling matter; visual streamlines are not a molded fibre prediction).
- Mitsubishi PP-C-20A coupon data: https://www.m-chemical.co.jp/carbon-fiber/pdf/pellet/pellet.pdf
- Gund FR4 directional coupon data: https://thegundcompany.com/wp-content/uploads/2024/03/NEMA-FR4-Glass-Epoxy-Laminate-by-The-Gund-Co.pdf
- Supplied independent mechanics-resource calculations and claim review were read; no final Sol scenes were used.

## verification plan

Each scene exports `checks(t)` from the same pure state function used by drawing. Check rest, approach/load, rival event, corrected event, and held result. Numeric tests cover common time, click thresholds, NC/NO exclusivity, fixed PCB, equal post sizes, beam formula/units and width scaling. Render event frames and final frames, inspect at stage and phone scale, then fix layout collisions. Full scene and review acceptance belongs to integration.

The parent assigned this lane as GPT-6 Astra at max effort. The child API does not expose an independent runtime model/effort introspection field; no stronger self-verification is claimed here.
