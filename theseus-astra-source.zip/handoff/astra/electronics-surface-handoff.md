# Systems implementation handoff

`film/systems.js` is ready for root browser integration. It contains fifteen independently authored scenes, with source notes and deterministic event state exposed through `checks(t)`. No Sol implementation, raster assets, raw scan, publication, or messages to Claude were used by this lane.

## Required integration facts

- `build.py` now loads and hashes `film/data/board-spec.json`, injects `FILM_BOARD`, and orders `a_finish_tests` after `a_surface`. These were the only root-owned build changes made by this lane.
- Shared board APIs remain `window.AstraBoardSpec` and `window.AstraDrawBoard(cx,cy,scale=7,{placed:1,under:false,variant:'window'|'edge',coat:0})`.
- The JSON is editable. Run `python astra/film/tools/board_geometry.py --write` after changing parameters, then run it without `--write` to verify no generated fields are stale.
- The 3D renderer should consume `B.bayOutline`, module body dimensions and `B.variants.A.window` directly. The old literal13.85 mm module body is a planning envelope, not Raytac's published13.3 mm package. The window datum is exactly[10,19.45], not[9.995,19.455]. Root was notified and owns these spatial changes.
- Actual corner radii are1 mm, not1 mm equal tangent lengths. The side nominal flat remains13.09 mm; the rear nominal span is12.689534528 mm. Their **finished** straight lengths are both12.054261463 mm, explicitly checked and displayed. Physical fit, routing and manufactured-board validation are not claimed.

## Verification recorded

- Syntax: `node --check astra/film/systems.js`.
- Geometry: sixteen checks in `board-geometry-checks.json`, all pass.
- Causal draw checks: six checks in `work/systems-offline/checks.json`, all pass. They inspect the actual draw calls for identical finger motion, inertial-force application at the battery center, moment arm, bare versus insulated water paths, scroll reports, film arithmetic, and settled board datums.
-45 native Canvas renders, three frames per scene, with no text leaving the stage. Named frames and contact sheet are in `work/systems-offline/`. Noncanonical font weights are rounded in that offline renderer only; browser rendering remains root's acceptance check.
- A source-only integrated build succeeded as `astra-c9adee810800` before the final datum normalization and label-only updates. Root must rebuild for the final reviewed artifact; this old build identity is not acceptance of the newest source.

## Evidence that remains unavailable or intentionally open

Matched retail plastic/rubber wheel masses and scroll-force testing; measured full wheel assembly mass; final grip-map approval; selected finished battery; final coating/net mass; final power-switch cover/notch decision; physical fit and rethread tests; assembled-board electrical/radio/thermal tests; finished Theseus latency, strength, comfort, aim and endurance. These limits are distinct from the completed explanatory drawings.

Source retrieval receipts in `systems-source-receipts.json` identify the HumiSeal manufacturer TDS despite its distributor filename, the exact black-coating/photopolymer UV test, the exact chemical fluid/color report, and the actual F-Series cure schedule. The earlier13-chemical file was too large for live extraction; its numeric claims were removed from final scene content.
