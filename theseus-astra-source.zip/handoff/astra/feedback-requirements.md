# Theseus Astra feedback requirements and review integrity

This is the independent Astra requirements record for imported baseline `7d8f926ebb8fca1653b3d30509ef6f8f60ac093e`. It is an audit and ledger handoff, not a claim that the new film has implemented or passed these requirements. The initial generated ledger has **114 original ratings, 100 exact written notes and 283 tracked records: 269 written-note clauses plus 14 ratings without a written note. All 283 initially remain pending.**

The subsequent clause-by-clause implementation review is in `closeout-review.md`, with an owner-ready feasible-work list in `implementation-gaps.md`. Current individual responses are authored in `ledger-closeout.tsv` and compiled into `ledger-responses.json`; `closeout-status.json` records the latest counts and scene lookup. Those later responses replace the initial pending placeholders without changing any original note or source clause. Source implementation, visual verification, physical measurement and user acceptance remain separate.

The full current `FEEDBACK.md` through F37, the assignment, source audit, all K briefs, original handoffs/progress notes, DESIGN, and supplied evidence/resource handoffs were read. Their exact bytes are in `context/`, with SHA-256 and lengths in `context/manifest.json`. No Sol scene implementation was copied. Original baseline files remain reference context; the independent film lives in `film/`.

The feedback-integrity worker's actual session record identifies `/root/feedback_integrity`, session `01a1ac6a-5ac2-7d50-8b0a-5a89867668c5`, model `gpt-6-astra`, effort `max`. This was read from `session_meta` and `turn_context`, rather than inferred from the assignment text. The root lead's model is the root's separately verified evidence.

## Authority and known source traps

1. Latest direct instructions and explicit DECIDED items govern. Earlier notes stay intact even when superseded. F37.1 changes the model boundary for this Astra experiment only: Astra ultra lead, Astra max workers. F34.3's Sol preference does not apply here.
2. F32.2 governs the format: **new story, fewer denser scenes, just build it**. K3–K8 describe per-slide feedback, not an approved new outline. DESIGN's many-sparse-slides rule is superseded; readable type and generous space for the mechanism remain requirements.
3. F35.1 governs color: **Theseus blue, sparse yellow comparisons/secondary items, neutral black/grey/white stage and chapter chrome, red faults**. The neutral portion of F34.6 remains. Neither F11.2's rainbow chapters nor an all-yellow primary returns.
4. F29.2 governs feedback closure. A title, unit, metadata, drawing touch or new scene mapping cannot archive a note. A response string is an implementation claim to verify, not proof or user acceptance.
5. The imported source audit's JSON has the corrected four `sealed` clauses and one `shlGrams` removal clause. Its Markdown body still shows the earlier incorrect “No written change requested” placeholders for those two entries, despite its correction footer. Use the intact raw note and corrected JSON. Preserve each rating's `auditCorrections`; do not delete the old extraction history.
6. The audit's FEEDBACK line numbers predate later sections inserted at the top. The ledger keeps `importedSource` unchanged, and resolves a current numeric `sourceLine` from the exact original rating text in the captured FEEDBACK file. The file's “Last updated” header is also older than its appended steering; it is not the source cutoff.
7. The 252 numbered F0–F33 source-audit records are preserved separately from the 283 F27 records. Current numbered feedback, including F34–F37, is indexed independently. Do not say that 283 records alone exhaust every standing instruction.
8. Fourteen ratings genuinely have no written note. Do not manufacture a user request for them. `weightgap` literally has the written note “no comment”; preserve it as supplied, alongside its 10/10 value.
9. F24.1 records historical note-attribution bugs in the original artifact. Preserve the supplied F27 record exactly; do not silently rewrite authorship or retarget a note based on an inference.
10. HANDOFF and PUBLISHING describe historical Claude states. Their optical encoder, old counts, old mass/budget questions, publishing workflow and old module wording are not current requirements. Original archived screenshots and tests that are absent are not reproduced evidence.

## Film-wide requirements

The story sells **solutions to understandable problems**. Establish what a rival design does mechanically, apply a visible input, show the consequence, then show Theseus under the same condition and the strongest player benefit. The benefit may be control, comfort, feel, wear, battery life, useful weight or repair. F33.6 explicitly prevents a compulsory missed-shot threat on every scene. “ZERO compromises” is the organizing proposal, not permission to invent measured superiority or hide a rival that wins a chart.

Every important idea needs a substantive animated demonstration. Decorative opacity changes, looping arrows or idle oscillation do not close motion feedback. Show approach or assembly, load/input, response, correction and a readable held comparison. Keep the original bad case/value available when the improved value arrives. A fixed PCB stays fixed; a support cannot quietly move between comparisons; force and motion arrows mean different things. Exaggerated displacements must say illustration. Causal checks should read the actual parameters used to draw the scene.

Use researched classroom examples where engineering is otherwise abstract: rotate the same ruler; rack a straw square then brace it; invert a loaded chain and show support thrust; distinguish load direction from wood-grain splitting; stack recognizable mouse parts against a fixed clearance. Carry the same mechanical idea into the mouse. Human-scale example loads are stated as illustrative rather than asserted to be a universal gaming grip. Give these demonstrations substantial screen area.

Every opening frame has a useful header and meaningful geometry. F14.5/F27 `shlNoPick` is a repeated, previously missed requirement: “what if you didn't have to pick” cannot be the only opening content. Use enough full-part or locator context to identify the region before a close-up. Simplified mouse outlines are appropriate for density; lazy blobs or an unrecognizable isolated cross-section are not.

At a glance, the viewer should see what changes, which direction is better and any supported magnitude. Label “Peak experienced stress (lower is better).” Retain good sources and useful quantities, but do not fake a measured win, exaggerate a rival's fault or alter a stress scale separately between rivals. Material behavior, model results and prototype outcomes remain different claims.

Use plain labels and large, strong Inter typography. No pills with dots, dot-separated concepts, decorative gradients, same-color tile outlines, black outlines around selected colored graph marks, peach skin or rainbow chapter chrome. Limited rounding and flat surfaces suit the inherited language. Selective gradients can appear in the Theseus name or a major number. The style still needs variation in placement and ample open space; dense does not mean uniformly packed.

Plain words: **battery**, **weight** for the idea and `g` for a quantity, **khz**, **Dual 8khz wired and wireless**, **PIAKNOW'S** in an uppercase context. No `pts` or `points` metric. Name engineering concepts directly, including Newtonian shape analysis and dual rail main/side buttons. `SPDT` expands to **single pole, double throw**, correcting the source's “pull” typo without changing the raw feedback. Keep one precision per comparison.

## Important concepts that must survive condensation

F33.5 names 19 priorities. They must receive more attention because their original execution was poor. Their old low score does not authorize deletion.

| Original concept | Required result in the new film |
|---|---|
| `cutouts` | Identify the mouse region, then show why the cutout geometry matters to the player. |
| `clk_front` | Show press-location-dependent first contact and wobble with deep front grooves; show the straight front, diminishing grooves, finger contact and independent gap/cutout argument clearly. |
| `clk_wedge` | Explain the many-parts problem before the integrated correction; keep it near the tolerance/parts story. |
| `arc` | Accurate tensioner, direct-drive alignment, force/motion distinction, approved ideal 6% wording with assumptions. |
| `anchors` | Recognizable guided motion, one permitted plane, identical plungers/pads, cheap feel and wear from unwanted motion. |
| `sidebuttons` | Full-size SPDT held by shell, uniform POM/plunger mechanism, simplified guide, clear no-compromise benefit. |
| `thinwall` | Teach the structural job and wall/rib geometry so both a glance and closer inspection make sense. |
| `shlSpecific` | Show what specific strength/stiffness buys for the stated job; explain before showing the metric. |
| `shlNoPick` | Correct the strength–weight fallacy with its own clear Theseus comparison, readable axes and a real opening frame. |
| `shlMargin` | Make peak stress, remaining margin and failure meaningful rather than another unexplained graphic. |
| `shlThin` | Show why triangulation matters more in very light structures, without a fabricated whole-shell strength claim. |
| `shlWork` | Use the requested “PUTTING THAT WEIGHT TO WORK” wording and connect load participation to actual design choices. |
| `shcArms` | Preserve the whole-board-versus-fragile-arm idea and shipping-break account, with the missing-photo boundary explicit. |
| `tolerance` | Explain a real stack-up principle using simplified mouse parts; show how one bad fit can spoil the assembly. |
| `shlsheet1` cutout seams | Move beside the click/cutout story; explain why seams farther from the center can catch fingers. |
| `ntr_density` | Rival problem first, accurate outlines at one scale, honest bounding-box proxy and the player benefit. |
| `zerograms` | Explain inertia and direction changes; avoid an invented overall aiming-speed gain. |
| `market` | Demonstrate sourced flagship compromises in weight/battery/package instead of an empty claim. |
| `grip` | Preserve the praised directional-grip demonstration and make the result more intuitive. |

Highly rated information also survives: the 10/10 weight-honesty story and fillet-size lesson; 9/10 density, size–weight and ranking information; praised sensor/lens module explanation; useful repair, screw, coating, grip and wiring content. Ratings guide information value, not a mechanical deletion threshold.

## Intro, comparisons and shape

- Cover: PIAKNOW'S in capitals; ZERO compromises replaces routine 8khz as the main selling point. Density may replace the “100+ ideas” count. Preserve a confident cover composition without the rejected detailed 2D mouse. Original 3D cover/close excludes the shell cover (F12.2).
- Use the Theseus **29.31 g target**, **$189 proposal**, **119.3 × 62.4 × 39.9 mm** numerical dimensions and **200 h at 1khz target**. The dimension decision changes numbers only, not the reference scan shape. Bounding-box volume is 297.028368 cm³ and the mass/volume proxy is about 0.099 g/cm³. It is neither material density nor a universal ergonomics score.
- X2F uses the supplied recovered published top/side paths and official dimensions at one physical scale. Leaders must share that transform. The 29.5 g owner sample is one mouse with four dots, within the maker's 29 ±2 g tolerance, not a minimum or proof of deceit. Distinguish that sample from wheel-component masses.
- Include G-Wolves even when it makes Theseus look less exceptional. Do not mix one revision's lower weight with another's size, price or sensor. The verified source pack explicitly identifies HTX/HTR/HSK conflicts and the unmatched HTS Deluxe price.
- Density ranks wireless mice; XA25 is shown as wired and excluded from that rank. Price comparisons retain price, VMSE, Zaunkoenig and the actual X3 SUPERSTRIKE. Keep wired/wireless and currency/date/configuration distinctions. X2 values cannot be renamed X3.
- Preserve the desire for a smooth attractive Pareto guide without fabricating continuous measured options. Discrete non-dominated points remain truthful; any interpolating curve is a guide. Unknown runtime stays unknown because capacity alone cannot derive it.
- Starlight X is the requested weight comparison. A 41.58 g sample versus a 38 g claim gives about 9.4%; do not reuse a percentage calculated from a different sample. No SLX hour rating is established by the supplied sources.
- Automatic mass budgets should derive from one authoritative component set. The board's 5.6 g includes its module, PMIC, antenna and USB-C. Historical shell-study mass is a study, not the final shell budget.
- Explain lower translational inertia through force and direction change, and distinguish it from rotational inertia or measured aim. The 12 mm grip-height decision and battery placement for balance remain; research the opposing high-battery rationale honestly. Balance stays at the center of the mouse when the sensor moves.
- Keep Newtonian shape analysis and the approved flatter-mouse quotation. Equal pressures on both sides and thicker low side bands belong naturally in the shape story. No unapproved Pro model or sticker promise.

## Clicks and interfaces

- Trace GT01 side-profile intent from the available Gateron reference. Keep normal detailed SPDT internals, a flat leaf, COM/NO/NC only, and a cap wider across the switch rather than vertical along it. The above-housing cap rotates 90°; preserve the acceptable lower plunger. All main and side plungers/pads must visibly match when uniformity is the argument.
- The 0.45 mm straight-wall repair was subsequently rejected as too thin (F30.24). Preserve straight, consistent lower walls and visibly thicken them from the available render. Scale-derived dimensions are representative because published GT01 dimensions are absent. GT01 procurement itself is not final.
- The trigger has its own aligned one-screw tensioner arm and bridge. The taller fulcrum idea #59 is abandoned. The bridge is continuous and connects both pieces but has no fillets at its trigger joins per the later note. Real span/width/crown stay unknown.
- Compare Starlight X's stiff composite/no-bridge behavior with a labelled proposed correction. Explain a stiff trigger with a light click; do not say stiffness is universally better. Earlier 26.9-to-7.7 gf examples are models, not product measurements.
- At 20° misalignment, cos θ gives 94.0% axial and sin θ gives 34.2% sideways components. These orthogonal percentages do not add. Alignment gives a 6.4178% relative axial increase. Approved “6% sooner” is a 6.0307% ideal equal-travel/equal-prescribed-path-speed result, not measured reaction time or press-to-PC latency; a different acceleration model gives a different time.
- Dual rails constrain unwanted movement. Show recognizably located parts, intended motion and unwanted looseness before guided correction. POM is used everywhere. Factory pad-thickness tuning remains important, but the requested named-rival tolerance comparison stays open without measurements.
- Main/front geometry needs separate causal beats: deep grooves make contact depend on press position and produce wobble/wear; shallower front grooves and a straight stop improve consistent contact while providing finger constraint and area. Do not rely only on a cross-section. Distinguish the separate oversized-gap problem and explain ceiling/wall-facing cutouts. Keep one Sora-like center seam with no fork around the wheel and no center strip, plus the straight rear cutout at the smile's deepest point.
- Side buttons use full-size SPDT switches held by the shell, no side PCB and no obsolete miniature switches. Explain the repeated tolerancing practice and four-full-size-switch weight argument. “No company has SPDT side buttons” is Brock's checked claim, not our exhaustive current market survey. His “I'd have to see” on the fixed guide is an open review boundary.
- SPDT needs an animated contact-state explanation with large readable words. A correct press/release signal is distinct from a debounce policy. Merge confusing timing slides, retain low default latency and configurable behavior for users who deliberately want double-click behavior.
- 70 µs is an electrical target at NC release, not the entire physical press-to-PC path. Frame-sync 202 and 42 µs are Brock's figures; XBAB's 163 µs difference is a separate source claim. Do not silently harmonize them into a measured comparison.
- Hot-swap shows visible claw clips and the repair/customization benefit. Irrelevant switch-selection detail can disappear; any provable-bin/Hall-binning commitment remains a proposal, without reintroducing magnetic clicks.

## Focus, skates and tracking

- Combine the camera, surface correlation and focus lesson into a coherent demonstration. Draw the pad in the same code-native style; avoid a photographic texture. Use accurate sensor/snap-on lens geometry and preserve the praised module explanation.
- Show why lens distance matters through blur and sampling; the proposed 0.2 mm optimum against ordinary 0.4 mm optimization must be identified by its source/model scope. No invented measured aim improvement or unsupported “sharper” metric.
- Show a stated load causing sag, then the same load with targeted dots near the lens. Compare the weight-efficient placement with large skates, not simply a static underside graphic. Plate-off sensor dots belong to the clip-on lens and sit left/right at ±11.5 mm in the supplied decision.
- Corner ledges are uniform, gap-free to the shell, filleted at the junction and long enough for up to three dots, matching the sensor ledge rationale. The rejected right-side underside drawing is not an accepted design. Final bottom-cover/skate options remain deferred.
- PAW3970 is a suspected identity/conditional plan after exclusivity; Viper V4 published specifications are labelled as that product's claims. No assured access/release date. Derived suffix lettering is not an official SKU.
- Tracking/report illustrations must visibly demonstrate sampling and the changed result. Move the 0.1 mm configurable lift-off benefit beside web software, and keep software explanations simple.

## Shell, load paths and tolerances

- Compare materials for a clearly stated job, load, section and mass. A flat-plane classroom beam is not a whole-mouse test. Keep ABS/PC, magnesium, aluminium, FR4 and PP-C-20A where relevant. Explain why strength/stiffness per weight matters rather than expecting the viewer to understand an unexplained index.
- For fixed footprint and variable thickness, `E^(1/3)/rho` is a bending mass index; equal-mass stiffness scales as `E/rho^3`. Stiffness and failure capacity are different quantities. A rotated rectangular ruler does not prove the same ratio in the shell.
- Preserve the strength–weight fallacy, including Brock's GPX2/ULX build-quality observation with its proper evidence class. Show clear better-direction axes and a distinct Theseus comparison. Do not imply arbitrary perceived build quality is a measured strength ordinate.
- Show both parts' weights for the milled-out-versus-solid example, peak location, useful load distribution and remaining margin. Connect “putting that weight to work” to the actual design choices. A participation threshold is a model definition, not measured grams universally “working.”
- Triangles remove a pin-jointed racking mechanism; real ribs still bend or buckle. The hex/square response needs to be visibly legible under the same stated force, without faking a measured advantage. Keep cells complete and eliminate stray lines. Remove the persistent multi-scene strength meter.
- Continuous arches intersect to form triangles, rather than disconnected triangles being assembled into arches. The arches must be smooth and structurally continuous. Explain thrust and the needed supports/tie, then link to the whole PCB. Do not silently move supports, claim arbitrary mouse loads are pure compression, or restore the removed Mars-base example.
- Fibre orientation matters. Show load direction and crack direction distinctly; moulded short-fibre PP is not continuous unidirectional carbon laminate. Curved/filleted flow paths, gate and rib-width reasoning can merge into the stronger lesson. Historical Choi/Hexcel ratios need their material/test scope, not direct shell multipliers.
- Fillet every visible lattice. A red hotspot is the failure risk. Preserve the 10/10 fillet-size lesson. Tooling benefits should merge into the geometry/manufacturing story; both EDM and direct milling remain options because the mold method is undecided. Do not claim one manufacturing route is selected.
- Both flatter low sides get the same thicker band and equal illustrative squeeze. Keep structural geometry consistent across scenes.
- Explain FR4 as a woven composite and use the entire already-required PCB instead of added carbon rods and tiny fragile arms. Avoid exact photographed-arm fidelity because the personal images are absent. An 18× or 1.8× historical result needs its stated model/material scope rather than a product claim.
- Tolerance stack-up uses recognizable shell, guide, switch and board parts, not drops or a Theseus teardown. Four independent centered ±0.05 mm dimensions give ±0.20 mm worst-case and ±0.10 mm RSS only under the appropriate assumptions. Fewer parts alone does not prove yield. One essential bad fit can spoil the whole assembly, but series reliability is a separate principle.
- Factory Poron at PCB/shell contact addresses creaking, including the existing G-Wolves mod context. Physical first-fit/rethread simulation is deferred; the useful reasoning stays in words.

## Surface, wheel and service

- Improve the coating's appearance in every supported view. Use recognizable drawn pots and flames for the coating analogy where that content remains. Show the original surface height, blasting/sanding and coating height together, with the soft-touch comparison. Merge the thin coating/mass lesson.
- Net Cerakote mass stays unnumbered until weighed; do not restore “only coating that adds no weight” or 0.49 g as a measured fact. Preserve film thinness and the no-adhesive/no-tape-thickness benefit.
- Directional engraving is functional grip: strong where needed, freedom in other directions, and blended attractive patterns. Final grip-map approval remains open after the finished demonstration. Decorative marks, legends and serial-number scenes stay hidden; do not mistake this for removal of the functional grip/two-tone argument.
- Two-tone means etch through to carbon, avoiding an added colored coating layer. Preserve material realism while acknowledging the prior pattern was not accepted. State “9H on Cerakote's tests”; preserve manufacturer UV/chemical tests without turning them into a universal lifetime guarantee or unverified rival failure rate.
- Wheel: six thin arms, open hub, thin rim, straight fine tread, nominal 0.900 g magnesium-body model. Diamond knurl is superseded. The full rotating assembly must separately account for axle/bushing, magnet, adhesive, finish and any tyre before an assembled-wheel comparison.
- The requested plastic/rubber retail test group is still missing. Named component reports are not a matched sample group; do not average them, infer a group mean or advertise savings. PMM's 1.0 g is a secondary maker specification with its own polymer-pin boundary.
- Preserve repair and screw value. Four titanium grade-5 screws replace the earlier steel budget (0.42 g model figure rather than 0.75 g). Hardness can support a recess-wear argument only against the actual steel grade; it does not prove titanium beats all steel or that a brass internal thread cannot strip.
- Brass inserts support durable service. ABS 90%, carbon-filled 70%, brass 0% are Brock's changed-feel-after-reassembly estimates, not first-fit probabilities or population measurements. First-assembly accuracy stays in words until the deferred study. Redundant ownership summaries should merge each useful idea into the relevant scene.

## Electronics, energy and approved board direction

- One approximately 5.6 g complete PCB, assembled on one side, with single-sided-reflow wording kept accurate. No separate front/back boards. Animate manufacturing rather than simply printing a claim.
- Radio module is black AN54LM-P20A with its long antenna; old -20A/chip-antenna wording is superseded. Keep keep-out and surrounding metal geometry consistent with the final layout. Use the actual PMIC identity nPM1300 where named.
- Magnetic encoder everywhere, with an inspectable transparent top. Explain contact wear versus obstructed optical path and contactless sensing. Hall avoids an optical path, not every possible dust or mechanical failure. Mechanical clicks have no light emitter; no RGB joins this story beside web software.
- Hall is not zero-current. Sensor active/sleep interval, conversion/startup, channel count, MCU/ADC work, regulators and first-scroll behavior must be considered. Example TI parts are not selected Theseus components. A manufacturer's 90.5 µA example and a 95.26 µA rectangular calculation are different models, not interchangeable readings.
- Razer “almost half” is an unverified public attribution via Brock. The inherited assumed 17.65% optical-switch share gives 21.43% ideal runtime recovery; exactly 18% removed gives 21.95%. Neither is a measured Viper breakdown or guaranteed Theseus benefit. Cross-rail currents need voltage and efficiency conversion. Avoid an unsupported 2× runtime claim.
- Compare mouse-sized batteries at equal nominal capacity/voltage: the supplied 350 mAh, 3.7 V 7 g pouch / 9 g cylinder is one example from different makers, with different minimum capacities and incomplete finished-pack boundaries. Do not revive an 18650 comparison or a universal chemistry rule. Battery selection and 200 h endurance remain open target/prototype work.
- Three 32 AWG wires made from 40 AWG strands are the accepted side lead. Demonstrate tear resistance, radio-noise rationale and flex life, preserving model/test limitations. Paracord/USB assets must be recognizable and mechanically active rather than a plain line.
- Conformal coating shows moisture protection for little material, without waterproof certification. Dry film thickness cannot be multiplied by liquid density to produce finished coating mass. The coated board still needs weighing.
- Plan 5 with F30.25's final edits is the approved direction. Required geometry and interfaces include: symmetric outline and wheel bay; one chamfer angle; equal apparent fillets; rear notch depth and length matched to side notches; a trapezoid front; wheel bay chamfered/filleted with gold trim; mirrored mounting pairs; dropped SH1/SH2 and LH1/LH2; no restored rear discretionary cutouts; retained/adapted underside dark triangles, gold clusters, wordmark, labels and QR; traces kept detailed.
- Sensor moves forward, MCU behind it, PMIC to the left-middle and far from MCU. Keep three centerline gaps equal and avoid thin webs. Parts should have sensible centered spacing. Battery connector faces rearward and is not cramped. Lens window and nearby dots move with the sensor while balance stays at mouse center.
- F30.25 resolves USB leg interference: move receptacle back 1.05 mm, leave 0.44 mm at the legs, retain 1.60 mm protrusion, move bay front to z44.13. The resulting 4.05 mm shortfall to the old shell mouth is a future shell-interface issue, not proof of fit. Build both power-switch A/window and B/edge variants. Final shell notch remains deferred.
- Keep the current 1 mm board thickness until an explicit change, and avoid recalculating for every minor idea. Later re-design makes the PMIC move due now; F21.11 is not permission to omit it again.

## Explicit supersession chains

The ledger preserves every imported precedence entry and adds the Astra/latest-steering entries. These are the main implementation traps:

| Earlier instruction/history | Governing later meaning |
|---|---|
| Red primary, old dot/lower-third tags, rainbow chapters | Plain-type labels; F35.1 blue/sparse-yellow/neutral palette. |
| Many sparse slides and old chapter work packages | F32.2 new story, fewer denser scenes; preserve every important requirement. |
| Mini side switches and PTFE uncertainty | Full-size SPDT, shell-held glove, POM everywhere. |
| Optical five-pin TTC product drawing | F27 magnetic encoder everywhere; historical optical detail applies only to an explicitly identified comparator. |
| Strength meter across shell scenes | Remove meter; retain load-spreading and light-structure reasoning. |
| Mars dome example | Remove example; retain continuous arches and fibres. |
| Optical sealing/failure scene | Remove old scene; magnetic dust-path and transparent-housing requirements remain. |
| Coating 0.49 g / unique zero-mass headline | Unnumbered net mass and accurate thickness/process comparison. |
| Standalone stats and redundant idea sheets | Redistribute useful information into causal feature stories. |
| Sora dimensions as numerical placeholder | Use 119.3 × 62.4 × 39.9 mm numbers, without rescaling the reference shape. |
| Tall fulcrum #59 and bridge fillets | #59 abandoned; continuous bridge with no fillets at trigger joins. |
| 85% carbon-filled re-screw estimate | 70%; ABS 90 and brass 0, all owner changed-feel estimates. |
| Unnamed sensor / definite PAW3970 claim | Suspected PAW3970 relationship and conditional access plan after exclusivity. |
| Plate pills, half-moons and historical FE wins | Bottom-cover proposals rejected/deferred; no approval implied by omission. |
| Steel screws | Grade-5 titanium with grade-specific evidence and correct model mass. |
| Diamond knurl | Straight fine tread, six thin arms and complete assembly accounting. |
| Old rear hole positions cannot move | Latest mirrored pairs allows the plan's tiny symmetric moves. |
| Keep USB as today / flush connector | Latest plan-5 backshift and slight protrusion with explicit shell gap. |
| Same numeric fillet radius | Latest equal apparent size/tangent intent; inspect chamfer junctions rather than simply changing a numeric radius. |
| Add discretionary rear cutouts | Drop them per F30.19. |
| 0.45 mm GT01 wall repair marked done | F30.24 asks for thicker lower walls; remains implementation work. |
| 20% faster direct-drive proposal | F31.2 approved 6% ideal local travel wording, with assumptions and no measured-latency claim. |
| Every feature costs a shot | F33.6 strongest relevant benefit, including feel, comfort, wear and battery. |
| Any code/text change archives rating | F29.2 deliberate substantive revision and all-clause accountability, plus persistent reopen. |

## Missing resources and open design boundaries

The original inventory remains in the copied audit JSON. Missing items include BRIEF-V5/COMMON/V4; earlier per-builder/fixer/reviewer/plate prompts and last-message snippets; the 23-finding historical review report; original QA/contact sheets; rejected/intermediate PCB render scratch files; old orchestration scripts; the three exact F28.2 tensioner photos; the two exact F28.3 broken-arm images; F30.11's marked intermediate plan; and the remote ratings/history/edits database. Supplied GT01 photo copies and final plan 5 are available, but no byte-identity claim to absent attachment IDs is made.

The independent reference pack supplies published X2F SVG paths, numerical mechanics/energy checks, qualified wheel reports and a weighing protocol. It does **not** supply a matched weighed retail wheel group, measured named-rival rail gaps, the personal broken-arm photo or a prototype Theseus test. Its successful numerical/package checks do not constitute visual acceptance of this film.

The raw Sora scan remains excluded and must never be touched or redistributed in this task. The latest inaccessible embedded Opus film was not inspected. Comparisons can only identify the actual accessible supplied version. No Claude outreach is authorized.

Explicit open boundaries are also represented in `ledger.json.boundaries`: bottom cover and final power-switch shell notch; next-iteration side seam; final grip-map and side-guide approval; unknown tensioner size; battery/component selection; physical first-fit/rethread studies; PAW3970 identity/access; GT01 thickening and finished plan-5 implementation; coating mass; matched latency/power and wheel measurements. These do not justify stopping the independent film: build what is supported, and keep the exact remaining reason visible.

## Review model and browser-local behavior

`film/ledger.json` is generated by `film/tools/build_ledger.py` from the exact context snapshot plus `handoff/astra/ledger-responses.json`. The root player owns user interactions. The source audit, normalized implementation status and user review state are three separate layers.

Each normalized clause has its stable ID, legacy slide, exact `originalNote` (null only for an actual no-note record), source line, source-clause record, raw-note hash, status, concrete response, pending reason, scene IDs and evidence. `ratings` remains a deep-equal copy of the original full records, including original statuses and the two extraction-correction histories. Every generated note and score is matched against the captured raw FEEDBACK lines before writing.

The normalized states are `pending`, `implemented`, `partial`, `superseded`, `deferred`. A scene mapping changes none of those automatically. `implemented` requires a nonempty concrete response and evidence with `kind`, `result`, `artifact`; the evidence still needs human/agent judgment to determine whether it proves the particular clause. A `partial` state must say precisely what remains. Superseded requires a real later instruction, and deferred requires the actual user/evidence boundary. Source `DONE` is never promoted automatically.

Global `lookup.byLegacySlide` and `lookup.byScene` support all-scene searching. A requirement that appears in several scenes has one global status. Show “addressed in” for evidenced work, and “planned in” or a plainly pending scene link when there is only a mapping. Do not call the same shared clause “still open” solely because its answer is in another scene, and do not hide its real partial/pending state.

User reopen is an independent override keyed by stable clause ID. It persists through navigation, reload, import/export and later film versions, and must show as open even if the source implementation status is `implemented`. Keep a timestamp/history and the old evidence/response visible. A new revision cannot erase or automatically clear that override. Only a deliberate user action should resolve the user's reopened state.

Bind note drafts to the scene ID captured when editing begins, and text overrides to scene plus exact string/key. Flush on navigation, seek-to-new-scene and drawer close; never send delayed text to whatever scene happens to be current. Preserve both imported history and new browser-local reviews. Label local storage plainly and provide export/import rather than claiming cloud sync. Imports need schema/version validation and collision handling, with no silent deletion of existing notes or reopen state. Unicode punctuation and multiline notes must round-trip exactly.

Ratings guide the value of information. An explicit substantive revision can display the earlier score as historical while keeping every original clause, its response, remaining work and reopen control visible. A new scene can be unrated without presenting the feedback as completed. Whole-note closure is blocked by any genuine pending, partial or reopened clause.

## Verification and handoff

Run `python film/tools/build_ledger.py --check` to verify source hashes, 114 ratings, 100 exact notes, all 283 unique clauses, the 269/14 split, per-rating correction history, response references and deterministic output. Normal regeneration reads only the captured context. `--capture-context` is an explicit allowlisted copy operation and refuses to overwrite a differing prior snapshot.

For the final film, verify syntax/build; deterministic first/mid/settled and mechanical event frames; numerical assumptions/units; actual rendered screenshots; and glance readability. Check coordinate invariants and wrong-state risks such as cap orientation, double contacts, moving supports, nonuniform pads, incomplete arch paths and inconsistent outlines. All these are separate from successful JSON or JavaScript parsing.

Use real mobile browser emulation with `isMobile` and `hasTouch`, portrait and landscape, and actual taps. Verify viewport metadata; toolbar wrapping; reachable scene/rating/source/editor close buttons; keyboard-safe note and text editing; correct scene attribution after immediate navigation; seek/replay; all-clause search; cross-scene links; reopening; export/import and safe update handling. A desktop viewport resize does not meet this requirement.

Original 2D-first and real-3D requests remain part of the record. A fake 3D toggle is unacceptable. If the new film only implements 2D or projected geometry, record that limitation and leave actual 3D support unverified rather than claiming parity from a button label.

Root alone owns publication. The Astra preview must be distinct from the Sol site and visibly show build identity, with a matching manifest and a safe available-update action. Never reload while a review or text edit is unsaved. Verify Pages build and actual served runtime against the exact tested artifact; a push or local hash alone does not show that the user's live page updated. Line-ending differences alone do not establish staleness.

Initial data generation is verified. **No scene implementation, rendered quality, mobile behavior, physical product performance or publication is accepted by this audit.** Those statuses will change only against the independent film's actual evidence.
