# Mechanics implementation and QA handoff

Frozen source: `astra/film/mechanics.js`.

SHA256: `ef33300e899337a58bd11acde61892837b799243fe34cafabd169466cecaee6b`.

15 independent procedural scenes. Required worker assignment was `gpt-6-astra` with `max` effort; this resumed worker has not independently verified a runtime model/effort record. No child workers were created. No Sol scene code or finished visuals were imported by this lane. The shared Sora outline and corrected board helper are lead-provided geometry dependencies.

## Validation actually performed

`node --check astra/film/mechanics.js` passed.

`node work/mechanics-check-v2.cjs` passed 20 named check groups. `work/mechanics-check.cjs` now forwards to that current script. Machine-readable result is `work/mechanics-qa/numeric.json`, which includes the exact source hash.

This run is Node state/math and emitted drawing-primitives verification. It is not pixel, font, browser, mobile or physical testing. Browser execution remains owned by the lead, following the earlier blocked approval. Older browser captures do not establish final pixel acceptance for this source hash.

The checks cover:

1. All 15 registrations and finite sampled state values.
2. Actual shared-time interval in which the direct-drive target has actuated while the comparison has not.
3. NC/NO exclusivity and actual moving-contact surface clearances throughout transfers.
4. Two accepted presses, two rejected duplicate bounce edges and NC re-arming in the expanded example.
5. Actual drawn front-edge contact: comparison first contact flips with finger position; both corrected ends contact together.
6. Equal main/side post, POM pad length and pad thickness; guide clearance changes from 8 to 2 model units.
7. Equal ruler mass and distinct bending-stiffness versus same-stress capacity ratios.
8. Constant square and hex bar lengths, fixed hex bottom datum and diagonal length.
9. Exact arch/rim projection, constant catenary length during spreading, and the stated static reactions.
10. Correlation recovers the actual generated image translation, including the blurred phase.
11. Targeted-support area/mass calculation and sensor-clip removal/reseating.
12. Equal mass/section area in the conditional load-limit graph and its chosen stress-limit formula.
13. Thickness-driven weight/stiffness/capacity readouts and the fixed-deflection rib loads.
14. Minimum fillet/tool envelope and the 0.02 mm remaining chosen allowance.
15. Fixed hotswap PCB/socket locations and final replacement seating/retention state.
16. Every draw function executes at start, intermediate and held states.
17. Actual emitted front path, contact circles, dome rim and normalized main/side POM rectangles match the checked geometry.
18. The current 3D GT01 constants and profile formula are evaluated directly from `3d/parts/gt01.js`; the 2D wall, exact lift, inner profile vertices, fillet radii, triangular opening, circular openings, slot and cap dimensions agree.
19. The actual emitted GT01 lower profile, circles, slot dimensions and projected slot angle use that matching geometry.
20. Local dimension labels clear their dimension lines, cursor endpoint and following copy. The shared engine is unchanged.

## Final scene manifest and review events

| Scene | Duration | Useful event times in seconds |
| --- | ---: | --- |
| `a_direct` | 18 | 0 context; 10.2 between contact thresholds; 14 held result |
| `a_rails` | 19 | 4 roll; 7 guides; 9 pad tuning; 16 side assembly |
| `a_bridge` | 18 | 4 stiff arm; 11 proposed bridge; 16 held comparison |
| `a_front` | 18 | 4 first left contact; 6 first right contact; 14 both corrected contacts |
| `a_seams` | 19 | 5 exposed opening; 13 corrected sweep and connected zoom |
| `a_spdt` | 24 | 0 NC; 4.4 open transfer; 5 NO; 7.4 reverse transfer; 8 NC; 16 bounce; 22 accepted/rejected hold |
| `a_hotswap` | 21 | 0 seated; 4 claws open; 8.5 extracted; 13 replacement above sockets; 17 seated; 20 retained |
| `a_focus` | 20 | 0 unshifted; 2 translated/sharp; 7 defocused; 13 focus restored; 18 hold |
| `a_support` | 22 | 0 corner ledges; 10 assembled clip; 13 loaded comparison; 15.8 clip removed; 20 reseated |
| `a_ruler` | 19 | 5 flat; 10 rotation; 15 same-load comparison |
| `a_material` | 32 | 0 full strips/100%; 3.5 thinning; 5 final ratios; 14 structural sketch; 23 curves; 30 final graph |
| `a_lattice` | 19 | 0 fixed bars; 5 hinge mechanisms; 12 half-width model; 17 deflection-limit loads |
| `a_arches` | 24 | 2 hanging; 7 inverted; 10 feet spread; 14 tied; 18 statics comparison; 23 weave hold |
| `a_fillets` | 36 | 4 corner response; 9 fibre markers; 14 cutter; 21 width/tool bounds; 30 grain separation; 35 held analogy |
| `a_pcb` | 20 | 5 small-root schematic; 10 whole-board supports; 18 Poron/contact load paths |

## Numerical meanings and boundaries

- Direct drive: 20 degrees, equal 0.35 mm travel and prescribed 0.1 mm/ms press-path speed. The 6.03% result is only that ideal travel segment; it is not measured finger-to-PC latency. PCB remains fixed. The GT01 lower wall is an illustrative 0.80 mm render-derived revision, not a manufactured-dimension assertion.
- Contact sequencing uses fixed NC/NO positions and moving-tip radii. Expanded bounce is separate illustrative firmware logic; 70 microseconds remains an electrical target. The 2 ms quiet-time example is explicitly chosen, not a rival measurement or firmware implementation.
- Targeted supports compare two chosen 30 by 12 mm pads with two diameter-6 mm dots at equal material/thickness. Added area/mass ratio is pi/40, or about 7.85%. Sag is illustrative. The ledges allow three dot positions over a 23 mm longitudinal span. Sensor support centers are at +/-11.5 mm.
- Ruler: same 60 by 10 by 3.3 mm PP-C-20A beam, 1.9998 g and 10 N center load. Rotation gives 9.1827 times bending stiffness and 3.0303 times same-stress capacity. These are beam results, not shell results.
- Material graph: 60 mm span, 10 mm fixed width and mass from 1 to 4 g. Flat sections vary thickness. The separate blue method line redistributes the same PP mass into a 10 mm deep I-section with a 0.60 mm web. Quoted tensile values are used only as chosen stress limits, not certified bending allowables. The six rows contain mixed coupon bases and inherited conditional inputs. Buckling, molded anisotropy, joint failure and whole-shell behavior are not solved. Brock's GPX2 versus ULX comparison is explicitly owner judgment.
- Lattice: upper bars are free-hinge teaching mechanisms with a 5 N illustrative input. Lower fixed-depth rib law is a separate normalized stiffness comparison: both start at 5 N/mm, with a 1 mm deflection limit. At half width, the axial case retains 2.50 N versus 0.625 N for in-plane bending, a fourfold relative retention. This is not ultimate failure load.
- Arch: spreading uses a constant-length catenary; foot/rim agreement is computed from actual projected points. The small static comparison is a 200 mm span, 50 mm rise ideal parabolic three-hinge arch under 10 N uniform vertical load. Vertical reactions are 5 N each; horizontal thrust is 5 N. The flat beam's peak moment is 250 N mm. The mouse weave remains a design illustration.
- Fillets: moving fibre marks and wood-grain separation are explanatory. The wood analogy is sourced to the US Forest Service 2021 Wood Handbook, Chapter 5. It is not a numerical analogue for filled PP. Chosen tooling envelope: radius 0.60 +/-0.05 mm, tool radius 0.50 mm and path allowance 0.03 mm, leaving 0.02 mm. This does not claim any supplier's capability or a universal tolerance multiplier. Direct milling versus EDM remains undecided.
- Whole PCB: the exact plan-derived board helper is used when available. Poron is shown at shell/board contacts, with Brock's G-Wolves mod context. Missing personal broken-arm photographs remain explicitly missing; the small-arm failure drawing is a schematic. No whole-board or whole-mouse strength multiplier is claimed.
- Hotswap hardware, sensor clips, tensioner dimensions, actual retention/wear and finished molded performance still need selection and physical validation. These boundaries do not prevent the presentation from demonstrating the requested service mechanism.

## Last fixes after the earlier browser freeze

The exact final source includes the wood-grain analogy and qualitative wear rationale, dynamic material percentages, explicit low-weight fixed-deflection rib loads, the moved rail locator label, and the SPDT arrow moved below its heading. It also replaces the older 2D GT01 housing coordinates with the computed 0.80 mm 3D revision: lower front foot 5.351955 mm, identical rounded triangle, two 0.68 mm-radius round holes and a 2.00 by 0.50 mm slot centered at (0.22, 3.00) mm. The slot now follows the housing tilt; screen coordinates invert its world angle. The local wide-gap, wait and release/grip labels were separated from their dimension lines without modifying the shared renderer. The lead should capture this final source rather than reuse images from `astra-51297997a0b6` for those changed event states.

The read-only reference comparison preceding that final patch inspected all three supplied GT01 images and the frozen direct/bridge/hotswap scenes. `gateron-gt01-vertical-push.jpg` is the F28.1 reference identified as original attachments 8e779cef/4de29879 in `handoff/GT01-PLUNGER.md`; the pair render and exploded view are also available. The exact below-cover plunger flange/nose remain unchanged in the 3D source. The cap-only orientation correction and lower-plunger preservation must not be conflated with the later housing-wall revision.
