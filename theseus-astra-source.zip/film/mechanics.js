/* Independent Astra mechanical film. Pure-time, procedural canvas geometry.
 * The comparisons below are teaching models unless their captions say otherwise.
 * No Sol scene source or rendered asset is imported. */
(() => {
  'use strict';
  const C=D.C, pi=Math.PI, rad=pi/180, co=Math.cos(20*rad), si=Math.sin(20*rad);
  const SOURCES={
    omron:{label:'Omron — basic-switch mechanics',url:'https://www.ia.omron.com/data_pdf/guide/29/microswitch_tg_e_3_2.pdf',note:'COM, NC and NO transfer; operating direction. No Theseus timing measurement.'},
    ruler:{label:'Open University — bending a ruler',url:'https://www.open.edu/openlearn/science-maths-technology/design-innovation/design/content-section-6.5',note:'Classroom demonstration that material placement changes bending stiffness.'},
    mit:{label:'MIT — stresses and deflections in beams',url:'https://ocw.mit.edu/courses/3-11-mechanics-of-materials-fall-1999/resources/mit3_11f99_bdisp/',note:'Euler–Bernoulli classroom calculation, not a mouse-shell test.'},
    straw:{label:'University of Colorado — straw bridges',url:'https://www.teachengineering.org/activities/cub_brid_lesson01_activity2',note:'Triangle-based truss classroom demonstration.'},
    ashby:{label:'Ashby — the properties of foams and lattices',url:'https://doi.org/10.1098/rsta.2005.1678',note:'Stretch-dominated versus bending-dominated structures; buckling and joint limits still apply.'},
    chain:{label:'University of Iowa — catenary demonstration',url:'https://instructional-resources.physics.uiowa.edu/1j3090-catenary',note:'A hanging chain finds an equilibrium curve under its own weight.'},
    fillet:{label:'Envalior — radii and chamfers',url:'https://www.envalior.com/en-us/radii-and-chamfers',note:'Rounded roots reduce stress concentration and improve flow. Exact factors depend on geometry.'},
    fibres:{label:'Envalior — fibre orientation and fatigue',url:'https://assets.envalior.com/document_0qbautli6p42b89pimtu9e7f2n/default/inline/document/Envalior_UseCases_Fatigue.pdf',note:'Flow-induced orientation and directional properties require process and structural models.'},
    wood:{label:'US Forest Service — mechanical properties of wood',url:'https://research.fs.usda.gov/treesearch/62244',note:'Chapter 5 of the 2021 Wood Handbook: orthotropic behavior and parallel/perpendicular grain properties. Wood is an analogy, not PP-C-20A test data.'},
    pp:{label:'Mitsubishi Chemical — PP-C-20A',url:'https://www.m-chemical.co.jp/carbon-fiber/pdf/pellet/pellet.pdf',note:'Typical coupon data: density 1.01 g/cm³, flexural modulus 13.5 GPa, tensile strength 120 MPa.'},
    fr4:{label:'Gund — FR4 glass-epoxy laminate',url:'https://thegundcompany.com/wp-content/uploads/2024/03/NEMA-FR4-Glass-Epoxy-Laminate-by-The-Gund-Co.pdf',note:'Typical directional coupon data, not populated-board strength.'},
    lens:{label:'PixArt — optical lens assembly example',url:'https://www.pixart.com/products-comparison/7/Optical_Mouse_Sensor',note:'Optical navigation compares surface images. Theseus focus range and support deformation here are design illustrations.'}
  };
  const arr=(n,fn)=>Array.from({length:n},(_,i)=>fn(i));
  const mix=D.lerp, p=(t,a,b)=>D.p(t,a,b), lin=(t,a,b)=>D.lin(t,a,b), clamp=D.clamp;
  function path(points,stroke=C.ink,width=3,fill=null,close=false){D.path(points,{stroke,width,fill,close});}
  function titlePair(a,b,y=220){D.text(a,110,y,28,C.mute);D.text(b,855,y,28,C.blue);}
  function rule(){D.line(800,205,800,745,C.line,1);}
  function chip(x,y,w,h){D.rect(x-w/2,y-h/2,w,h,'#252a30',5,C.mute,2);for(let i=0;i<5;i++){let u=(i+.5)/5;D.line(x-w/2-9,y-h/2+u*h,x-w/2,y-h/2+u*h,C.mute,3);D.line(x+w/2,y-h/2+u*h,x+w/2+9,y-h/2+u*h,C.mute,3);}}
  function screw(x,y,s=1){D.circle(x,y,14*s,C.panel,C.mute,2);for(let k=0;k<3;k++){let a=k*pi/3;D.line(x-7*s*Math.cos(a),y-7*s*Math.sin(a),x+7*s*Math.cos(a),y+7*s*Math.sin(a),C.mute,2);}}
  function support(x,y){path([[x-15,y+24],[x,y],[x+15,y+24]],C.mute,2,C.panel,true);D.line(x-24,y+28,x+24,y+28,C.mute,2);}
  function fingertip(x,y,s=1){D.group(x,y,s,0,()=>{D.rect(-23,-66,46,78,C.mute,22);D.rect(-14,-53,28,27,C.panel,11);});}
  function dotRoute(points,progress,color=C.blue,r=5){if(progress<=0)return;let lens=[],sum=0;for(let i=1;i<points.length;i++){sum+=Math.hypot(points[i][0]-points[i-1][0],points[i][1]-points[i-1][1]);lens.push(sum);}for(let k=0;k<5;k++){let d=(progress-k*.09)*sum;if(d<0||d>sum)continue;let i=lens.findIndex(x=>x>=d);let last=i?lens[i-1]:0,q=(d-last)/(lens[i]-last);D.circle(mix(points[i][0],points[i+1][0],q),mix(points[i][1],points[i+1][1],q),r,color);}}
  function smoothCurve(points,color=C.ink,width=4){const c=D.ctx;c.save();c.beginPath();c.moveTo(...points[0]);for(let i=1;i<points.length-1;i++)c.quadraticCurveTo(...points[i],(points[i][0]+points[i+1][0])/2,(points[i][1]+points[i+1][1])/2);c.lineTo(...points[points.length-1]);c.strokeStyle=color;c.lineWidth=width;c.stroke();c.restore();}

  // Side-on GT01 geometry follows the supplied Gateron render, in millimetres.
  // Same declared dimensions and projected housing profile as 3d/parts/gt01.js.
  // The 0.80 mm housing is a design revision, not a measured product dimension.
  function roundedProfile(points,radii,segments){return points.flatMap((b,i)=>{
    const a=points[(i+points.length-1)%points.length],c=points[(i+1)%points.length],unit=v=>{const n=Math.hypot(...v);return v.map(x=>x/n);},u=unit([a[0]-b[0],a[1]-b[1]]),v=unit([c[0]-b[0],c[1]-b[1]]),ang=Math.acos(clamp(u[0]*v[0]+u[1]*v[1],-1,1)),r=radii[i];
    if(r<=0||ang>pi-.001)return [b];const tangent=r/Math.tan(ang/2),bis=unit([u[0]+v[0],u[1]+v[1]]),center=[b[0]+bis[0]*r/Math.sin(ang/2),b[1]+bis[1]*r/Math.sin(ang/2)],a0=Math.atan2(b[1]+u[1]*tangent-center[1],b[0]+u[0]*tangent-center[0]),a1=Math.atan2(b[1]+v[1]*tangent-center[1],b[0]+v[0]*tangent-center[0]);let sweep=a1-a0;while(sweep>pi)sweep-=2*pi;while(sweep<-pi)sweep+=2*pi;return arr(segments+1,j=>[center[0]+r*Math.cos(a0+sweep*j/segments),center[1]+r*Math.sin(a0+sweep*j/segments)]);
  });}
  const GT01_GEOMETRY=(()=>{
    const L=12.8,W=5.8,H=6.5,shoulder=2.5,hMin=-.52,wall=.80,lift=L/2*si+hMin,innerZ=L/2-wall;
    const world=(z,y)=>[y*si+z*co,y*co-z*si+lift],frontBase=world(L/2,0),backBase=world(-L/2,0),innerFrontY=(innerZ*si-lift)/co,outerFrontY=(L/2*si-lift)/co;
    const front=frontBase[1]<=.02?[[world(innerZ,innerFrontY)[0],0]]:[[frontBase[0],0],frontBase];
    const lower=[[backBase[0],0],...front,world(innerZ,shoulder-.004),world(-innerZ,shoulder-.004),world(-innerZ,0),backBase],lowerRadii=front.length===1?[.1,.05,.04,.04,.04,.1]:[.1,.1,.05,.04,.04,.04,.1];
    const triangle=[[.07,wall],[backBase[0]+wall,3.03],[backBase[0]+wall,wall]],triangleRadii=[.35,.25,.25];
    return {L,W,H,shoulder,hMin,wall,lift,tilt:20,outer:[[backBase[0],0],[world(L/2,outerFrontY)[0],0],world(L/2,H),world(-L/2,H),backBase],lower,lowerRadii,lowerRounded:roundedProfile(lower,lowerRadii,6),triangle,triangleRadii,triangleRounded:roundedProfile(triangle,triangleRadii,5),holes:{back:[-2.86,3.81,.68],front:[3.44,1.49,.68],slot:[.22,3.00,2,.50]},slotWorldAngle:-20*rad,cap:{along:1.5,across:2.1,radius:.75,proud:.80,z:2.0}};
  })();
  function switchSide(x,boardY,s,travel=0,gt=true,color=C.blue,drawBoard=true){
    const th=gt?20*rad:0,ct=Math.cos(th),st=Math.sin(th),lift=gt?GT01_GEOMETRY.lift:0;
    const sw=(z,y)=>[z*ct+y*st,y*ct-z*st+lift];
    D.group(x,boardY,s,0,()=>{
      const P=q=>[q[0],-q[1]], poly=(q,fill,stroke=C.mute,w=.10)=>D.path(q.map(P),{close:true,fill,stroke,width:w});
      if(drawBoard){D.rect(-9,-.0,19,.8,'#303a43',0);D.line(-9,.04,10,.04,C.mute,.08);}
      for(const z of [-5.08,0,5.08])D.rect(z-.20,0,.4,1.6,'#b9b7a8',.02);
      if(gt){
        const g=GT01_GEOMETRY;poly(g.outer,'#262b30');poly(g.lowerRounded,'#73797e',C.mute,.10);
        for(const [z,y,r] of [g.holes.front,g.holes.back])D.circle(z,-y,r,C.bg);
        poly(g.triangleRounded,C.bg,null,0);
        const [z,y,length,width]=g.holes.slot;D.group(z,-y,1,-g.slotWorldAngle,()=>D.rect(-length/2,-width/2,length,width,C.bg,width/2));
      }else poly([[-6.4,0],[6.4,0],[6.4,6.5],[-6.4,6.5]],'#434a50');
      const shoulder=gt?2.5:1.6;
      poly([sw(-6.4,shoulder),sw(6.4,shoulder),sw(6.4,6.5),sw(-6.4,6.5)],'#303b45',C.mute,.12);
      // Three fixed contacts and one flat snap leaf, never a loose coil/noodle.
      const com=sw(-4.8,3.1),leafY=travel>.20?2.9:4.0,nc=sw(4.5,4.45),no=sw(4.5,2.50);
      D.line(...P(sw(-4.8,1.8)),...P(com),'#c7b67f',.22);
      D.path([P(com),P(sw(-1.5,3.5)),P(sw(2.7,leafY)),P(sw(4.5,leafY))],{stroke:'#c7b67f',width:.20});
      D.circle(nc[0],-nc[1],.25,'#d3c79f');D.circle(no[0],-no[1],.25,'#d3c79f');
      const q=sw(2,6.5-travel),q2=sw(2,7.3-travel);
      const cap=[sw(1.25,6.45-travel),sw(2.75,6.45-travel),sw(2.75,6.73-travel),sw(2.53,7.12-travel),sw(2,7.3-travel),sw(1.47,7.12-travel),sw(1.25,6.73-travel)];
      poly(cap,color,null,0);D.line(...P(q),...P(sw(2,4.0-travel)),C.mute,.35);
      D.line(...P(sw(-6.2,6.5)),...P(sw(6.2,6.5)),C.ink,.12);
    });
    const q=sw(2,7.3-travel);return [x+s*q[0],boardY-s*q[1]];
  }
  function directState(t){const ms=lin(t,3,11)*4;return {clockMs:ms,angle:20,travel:.35,speed:.1,beforeTravel:Math.min(.35,ms*.1*co),afterTravel:Math.min(.35,ms*.1),beforeCrossed:ms>=.35/(.1*co),afterCrossed:ms>=3.5,pcbY:530,lowerWallMm:GT01_GEOMETRY.wall,gt01Geometry:GT01_GEOMETRY,forceRatio:1/co,timeRatio:co};}
  Film.add({id:'a_direct',title:'DIRECT DRIVE ACTUATION',subtitle:'Make the press follow the switch.',chapter:'Clicks',duration:18,old:['clicks','arc','clk_wedge'],sources:[SOURCES.omron],evidence:'Ideal travel model: equal travel and press-path speed, 20° local angle. Not measured press-to-PC latency.',beats:[{t:0,label:'The PCB stays fixed. Only the trigger and switch plunger move.'},{t:3,label:'One shared press speed. The angled approach loses motion along the switch axis.'},{t:10,label:'The aligned plunger crosses first; the comparison has not crossed yet.'},{t:11,label:'6% sooner for this ideal travel segment. Alignment also removes avoidable side loading.'}],checks:directState,draw(t){
    const q=directState(t);rule();titlePair('ANGLED APPROACH','ALIGNED GT01-STYLE');
    const a=switchSide(390,530,22,q.beforeTravel,false,C.yellow),b=switchSide(1110,530,22,q.afterTravel,true,C.blue);
    for(const [pt,col] of [[a,C.yellow],[b,C.blue]]){const yy=pt[1]-62-30*(1-p(t,0,2));fingertip(pt[0]+24,yy,.85);D.arrow(pt[0]+60,yy+4,pt[0]+18,pt[1]-8,C.ink,3);}
    D.line(a[0],a[1]-45,a[0],a[1]+36,C.mute,2,[6,6]);D.arrow(a[0]-7,a[1]-24,a[0]-46,a[1]-24,C.red,3);
    D.label('side load',190,344,C.red);D.label('PCB',178,570);D.label('PCB',897,570);
    D.text('94.0%',110,640,46,C.yellow);D.text('along the axis',280,638,25,C.mute);D.text('100.0%',855,640,46,C.blue);D.text('along the axis',1052,638,25,C.mute);
    const bars=[[110,q.beforeTravel,C.yellow,q.beforeCrossed],[855,q.afterTravel,C.blue,q.afterCrossed]];
    for(const [x,v,col,on] of bars){D.rect(x,675,540,17,C.panel,2);D.rect(x,675,540*v/.35,17,col,2);D.line(x+540,664,x+540,707,on?col:C.mute,2);D.text(on?'actuated':'travel remaining',x,733,23,on?col:C.mute);}
    if(t>=11){D.text('6% SOONER',1250,734,31,C.blue,'right');D.text('same travel, same press speed',110,253,23,C.mute);}
    else D.text('shared clock  '+q.clockMs.toFixed(2)+' ms',110,253,23,C.mute);
  }});

  const POST={width:24,height:90,pad:4,padLength:72,spacing:152};
  function railAssembly(x,y,s,angle,load,guided,build=1,padThickness=POST.pad){D.group(x,y,s,angle,()=>{
    D.rect(-192,140,384,18,'#303a43',1);
    D.rect(-122,116,92,24,'#59616a',4);D.rect(-87,104+load*12,22,12,C.mute,4);
    for(const k of [-1,1]){let u=k*POST.spacing/2;D.alpha(build,()=>{D.rect(u-29,38,12,102,C.mute,3);D.rect(u+17,38,12,102,C.mute,3);if(guided){D.rect(u-17,48,padThickness,POST.padLength,C.blue,2);D.rect(u+17-padThickness,48,padThickness,POST.padLength,C.blue,2);}});}
    const roll=guided?0:load*.09;
    D.group(0,load*12,1,roll,()=>{D.rect(-175,-4,350,22,guided?C.blue:'#8b9199',8);for(const k of [-1,1])D.rect(k*POST.spacing/2-POST.width/2,14,POST.width,POST.height,C.ink,5);D.line(-150,4,150,4,guided?'#8ebdff':C.mute,2);});
    D.arrow(105,-94,105,-16+load*25,C.ink,4);if(!guided&&load>.05)D.arrow(152,10,181,33,C.red,3);
  });}
  function railState(t){const padThickness=1+3*p(t,8,10);return {beforeLoad:p(t,2,5),afterLoad:p(t,11,13),guideAssembly:p(t,6,8),beforeRoll:p(t,2,5)*.09,afterRoll:0,postWidth:POST.width,postHeight:POST.height,sidePostWidth:POST.width,sidePostHeight:POST.height,padThickness,sidePadThickness:padThickness,padLength:POST.padLength,sidePadLength:POST.padLength,guideClearance:34-2*padThickness-POST.width,padMaterial:'POM',sideHeldBy:'shell',sidePcb:false};}
  Film.add({id:'a_rails',title:'DUAL RAILS. ONE INTENDED MOTION.',subtitle:'A clean downward press should not become a sideways wobble.',chapter:'Clicks',duration:19,old:['anchors','sidebuttons','clk_pomtune'],sources:[SOURCES.omron],evidence:'Illustrated clearances and deformation; rival rail measurements are unavailable. Identical Theseus posts and POM pads.',beats:[{t:0,label:'The same off-center press tests both trigger supports.'},{t:3,label:'Loose guides can feel cheap; repeated rubbing adds a wear mechanism.'},{t:7,label:'Two matched guides constrain the sideways motion.'},{t:12,label:'The same guide and pad geometry turns sideways for full-size, shell-held side switches.'}],checks:railState,draw(t){
    const q=railState(t);rule();titlePair('LOOSE SUPPORT','TWO MATCHED GUIDES');railAssembly(415,365,1,0,q.beforeLoad,false);railAssembly(1160,365,1,0,q.afterLoad,true,q.guideAssembly,q.padThickness);
    D.mouse(720,287,.19,{color:C.mute});D.circle(710,265,13,null,C.blue,2);D.line(697,266,615,324,C.line,2);D.label('main trigger',485,249);
    D.text('roll + rubbing',185,586,30,C.red);D.text('straight travel',931,586,30,C.blue);
    D.text('SAME PARTS',110,674,34,C.ink);D.wrap('Thicker POM pads take up guide clearance. The same geometry serves the side buttons.',110,713,600,25,C.mute,31);
    D.alpha(p(t,11,13),()=>{
      D.group(1255,680,.72,pi/2,()=>switchSide(0,0,15,.25,false,C.blue,false));
      D.rect(1239,603,15,151,C.mute,5);D.rect(1239,603,63,12,C.mute,4);D.rect(1239,742,63,12,C.mute,4);
      const z=.56;for(const sy of [-1,1]){const yy=659.04+sy*POST.spacing*z/2;D.rect(1331,yy-POST.width*z/2,POST.height*z,POST.width*z,C.ink,3);D.rect(1334,yy-17*z,POST.padLength*z,q.sidePadThickness*z,C.blue,2);D.rect(1334,yy+(17-q.sidePadThickness)*z,POST.padLength*z,q.sidePadThickness*z,C.blue,2);}D.rect(1381,602,15,115,C.blue,5);
      D.label('side button',882,655,C.blue);D.label('full-size SPDT',882,692);D.label('shell-held, no side PCB',882,735);
    });
  }});

  function bridgeRow(y,bridge,travel){
    const x0=270,end=1280,d=travel*28;
    D.rect(190,y-34,178,38,'#4b5159',3);D.rect(250,y-56,40,59,C.mute,3);screw(270,y-39,.85);
    D.rect(220,y+118,1120,14,'#303a43',1);D.label('fixed PCB',221,y+150);
    const pts=arr(55,i=>{let f=i/54,x=x0+f*(end-x0),bend=bridge?Math.pow(clamp((f-.24)/.25),2):f*f;return [x,y+d*bend];});
    if(bridge){
      const c=D.ctx;c.save();c.beginPath();c.moveTo(x0,y);c.lineTo(400,y);c.bezierCurveTo(450,y-48,580,y-48+d*.35,670,y+d);c.lineTo(end,y+d);c.lineWidth=17;c.strokeStyle=C.blue;c.lineJoin='miter';c.stroke();c.lineWidth=8;c.strokeStyle=C.bg;c.beginPath();c.moveTo(453,y-20);c.bezierCurveTo(490,y-43,558,y-33+d*.3,605,y-14+d*.6);c.stroke();c.restore();
    }else path(pts,'#858d97',20);
    let cap=switchSide(1155,y+118,9,Math.min(.35,travel*.35),true,bridge?C.blue:C.yellow);D.rect(cap[0]-9,y+d,18,cap[1]-y-d,C.ink,3);
    D.arrow(1215,y-73,1215,y-12+d,C.ink,4);D.label('same trigger travel',1000,y-84);
    if(travel>.1){const bx=bridge?540:374,by=bridge?y-24:y+2;D.circle(bx,by,26*travel,null,bridge?C.blue:C.red,4);}
  }
  function bridgeState(t){return {beforeTravel:p(t,2,5),afterTravel:p(t,9,12),screwsPerTrigger:1,bridgeRootsFilleted:false,bridgeIntegral:true,tallerFulcrum:false,dimensions:'illustrative'};}
  Film.add({id:'a_bridge',title:'STIFF SHELL. DELIBERATE CLICK FLEX.',subtitle:'The bridge decides where the trigger bends.',chapter:'Clicks',duration:18,old:['tensioner','clk_tenmat'],sources:[SOURCES.mit],evidence:'Integral-flexure illustration, not a force solve. Tensioner dimensions remain open; Starlight X feel is Brock’s report.',beats:[{t:0,label:'A stiff unrelieved arm asks more of the trigger itself.'},{t:3,label:'Starlight X: Brock reports stiff clicks with the stiff composite structure.'},{t:8,label:'One screw, one trigger arm and a thin-center bridge create a chosen bending zone.'},{t:12,label:'Keep the body firm while giving the click a deliberate place to flex.'}],checks:bridgeState,draw(t){
    const q=bridgeState(t);D.text('STIFF UNRELIEVED ARM',110,211,27,C.mute);bridgeRow(310,false,q.beforeTravel);D.text('PROPOSED INTEGRAL BRIDGE',110,505,27,C.blue);bridgeRow(600,true,q.afterTravel);
  }});

  function frontGeometry(x,y,good,load,side){
    const w=470,h=130,roll=good?0:side*load*18,stopCenter=y+h+64,edgeRadius=7,stopRadius=5;
    const shift=load*(64-edgeRadius-stopRadius-Math.abs(roll));
    const front=arr(81,i=>{const f=i/80;return [x-w/2-30+f*(w+60),y+h+shift+(good?0:-26*Math.sin(pi*f))+roll*(2*f-1)];});
    return {x,y,w,h,roll,shift,front,stopCenter,stopRadius,edgeRadius,leftGap:stopCenter-stopRadius-front[0][1]-edgeRadius,rightGap:stopCenter-stopRadius-front[80][1]-edgeRadius};
  }
  function frontPlate(g,good,load,side){
    const {x,y,w,front,stopCenter}=g;
    path([[x-w/2,y],[x+w/2,y],...front.slice().reverse()],C.mute,2,good?'#223a57':'#30353c',true);
    // Groove strokes become visibly shallower and narrower toward the straight front.
    for(const u of [-.45,0,.45])for(let k=0;k<16;k++){
      const v=k/16,v2=(k+1)/16,xx=x+u*w*.7,fi=Math.round((xx-x+w/2+30)/(w+60)*80),end=front[clamp(fi,0,80)][1];
      D.line(xx-14*Math.sin(v*pi),mix(y+8,end-9,v),xx-14*Math.sin(v2*pi),mix(y+8,end-9,v2),good?'#6c94be':'#535c68',good?mix(8,1.2,v):8);
    }
    path(front,good?C.blue:C.yellow,14);D.line(x-w/2-38,stopCenter,x+w/2+38,stopCenter,C.mute,10);
    const fx=x+side*145,fy=y+47+load*13;
    D.ctx.save();D.ctx.beginPath();D.ctx.ellipse(fx,fy+29,good?55:33,good?25:18,0,0,pi*2);D.ctx.fillStyle=good?'#4f82ba':'#626974';D.ctx.fill();D.ctx.restore();
    fingertip(fx,fy,.9);D.arrow(fx,y-70,fx,y-12+load*18,C.ink,3);
    if(good){D.arrow(fx-91,fy+23,fx-58,fy+23,C.blue,2);D.arrow(fx+91,fy+23,fx+58,fy+23,C.blue,2);}
    const contact=[front[0],front[80]].filter(a=>Math.abs(stopCenter-5-a[1]-7)<.05);contact.forEach(a=>D.circle(a[0],a[1]+7,5,good?C.blue:C.red));
  }
  function frontState(t){const side=t<6?mix(-1,1,p(t,4,6)):1,beforeLoad=p(t,2,4),afterLoad=p(t,9,12);return {pressSide:side,beforeLoad,afterLoad,before:frontGeometry(412,339,false,beforeLoad,side),after:frontGeometry(1160,339,true,afterLoad,side),beforeRoll:side*beforeLoad*18,afterRoll:0,straightStop:true,groovesShallowAtFront:true};}
  Film.add({id:'a_front',title:'A STRAIGHT STOP FEELS CONSISTENT',subtitle:'Comfort grooves guide the finger. The front edge controls the landing.',chapter:'Clicks',duration:18,old:['clk_front'],sources:[SOURCES.omron],evidence:'Exaggerated geometry demonstration under equal press travel; no rival wear-life or tolerance measurements.',beats:[{t:0,label:'The front of a trigger is both a finger surface and a mechanical stop.'},{t:3,label:'A curved edge lands on one side first. The first contact changes with finger position.'},{t:6,label:'Repeated rocking can feel cheap and adds local rubbing that can cause wear.'},{t:9,label:'Keep the front stop straight and let the comfort grooves fade before it.'},{t:12,label:'Two sides land together, reducing rocking and repeated local rubbing.'}],checks:frontState,draw(t){
    const q=frontState(t);rule();titlePair('CURVED LANDING EDGE','STRAIGHT LANDING EDGE');frontPlate(q.before,false,q.beforeLoad,q.pressSide);frontPlate(q.after,true,q.afterLoad,q.pressSide);
    D.text('one side first',190,640,34,C.red);D.text('both sides together',915,640,34,C.blue);D.wrap('The first contact changes with finger position.',110,700,610,26,C.mute,33);D.wrap('Shallow grooves retain finger contact without curving the stop.',855,700,610,26,C.mute,33);
  }});

  function seamState(t){return {sweep:p(t,2,6),correctedSweep:p(t,9,13),centerSplits:1,centerStrip:false,rearCutoutStraight:true,sideSeamApproval:'deferred'};}
  Film.add({id:'a_seams',title:'KEEP SEAMS OUT OF THE FINGER PATH',subtitle:'The whole trigger stays in view before the cutout is enlarged.',chapter:'Clicks',duration:19,old:['cutouts','shlsheet1'],sources:[],evidence:'Design illustration. One center split and straight rear cutouts; final side-seam placement remains deferred.',beats:[{t:0,label:'A seam near the grip edge sits directly in the finger’s path.'},{t:3,label:'The same outward finger sweep crosses an exposed opening.'},{t:8,label:'Bring the split inward, and face the cutout toward the wall or ceiling.'},{t:13,label:'A cleaner contact surface keeps the finger free to move.'}],checks:seamState,draw(t){
    const q=seamState(t);rule();titlePair('EXPOSED OUTER OPENING','CENTERED SPLIT');
    for(const [cx,good,sweep] of [[410,false,q.sweep],[1160,true,q.correctedSweep]]){
      D.mouse(cx,445,.93,{color:good?C.blue:C.mute,fill:C.panel,seam:true});
      if(!good){D.line(cx+67,285,cx+85,420,C.red,8);D.line(cx+67,285,cx+85,420,C.bg,3);}
      const fx=cx+mix(38,124,sweep),fy=390;D.group(fx,fy,1,pi/2,()=>fingertip(0,0,.78));D.arrow(cx+30,487,cx+137,487,C.mute,2);
      if(!good&&sweep>.35){path([[cx+73,374],[cx+92,380],[cx+84,390],[cx+102,396]],C.red,3);D.label('catches an edge',cx-240,573,C.red);}
      if(good){D.label('one split, no center strip',cx-205,573,C.blue);}
    }
    // The marked openings connect to their sections; the gap comparison is explicitly schematic.
    D.circle(489,396,23,null,C.red,2);D.path([[509,406],[675,540],[675,620],[613,652]],{stroke:C.line,width:2});
    D.circle(1160,354,23,null,C.blue,2);D.path([[1182,354],[1465,512],[1465,619],[1280,653]],{stroke:C.line,width:2});
    D.text('OPENING, ENLARGED',110,627,25,C.mute);
    path([[285,652],[285,711],[434,711],[434,664]],C.mute,10);path([[478,664],[600,664]],C.mute,10);D.arrow(456,624,456,662,C.red,3);D.dim(439,696,473,696,'',C.red);D.text('wide gap',530,711,23,C.red);D.label('finger-facing edge',280,754,C.red);
    path([[1020,652],[1020,711],[1215,711],[1215,664],[1287,664]],C.blue,10);D.rect(1205,680,20,14,C.bg,0);D.arrow(1300,723,1230,686,C.blue,3);D.label('tight, wall-facing opening',1000,754,C.blue);
  }});

  const bounceNO=u=>(u>=2&&u<2.18)||(u>=2.34&&u<2.56)||(u>=2.72&&u<7.2)||u>=8.6;
  const bounceNC=u=>u<1.7||(u>=7.5&&u<8.2);
  function bounceModel(t){
    const nowMs=10*p(t,12,19),events=[],edges=[0,1.7,2,2.18,2.34,2.56,2.72,7.2,7.5,8.2,8.6];let armed=true,held=false,lastNO=false,lastNC=true;
    for(const ms of edges){const no=bounceNO(ms),nc=bounceNC(ms);if(no&&!lastNO){const accepted=armed&&!nc;events.push({ms,type:'press',accepted,reason:accepted?'armed after NC':'already pressed'});if(accepted){held=true;armed=false;}}if(nc&&!lastNC){if(held)events.push({ms,type:'release',accepted:true,reason:'NC confirms return'});held=false;armed=true;}lastNO=no;lastNC=nc;}
    return {nowMs,events,acceptedPresses:events.filter(e=>e.ms<=nowMs&&e.type==='press'&&e.accepted).length,rejectedBounceEdges:events.filter(e=>e.ms<=nowMs&&e.type==='press'&&!e.accepted).length,quietWaitMs:2,lastBounceMs:2.72,waitAcceptedMs:4.72,measured:false};
  }
  function spdtState(t){
    const press1=p(t,2.4,4.9),release=p(t,6.6,8.0),press2=p(t,9.4,11.6),travel=clamp(press1-release+press2);
    let nc=true,no=false,transfer=0;
    if(t>=4.2&&t<4.7){nc=false;transfer=.002+.996*lin(t,4.2,4.7);}else if(t>=4.7&&t<7.2){nc=false;no=true;transfer=1;}
    else if(t>=7.2&&t<7.6){nc=false;transfer=.998-.996*lin(t,7.2,7.6);}else if(t>=10.9&&t<11.4){nc=false;transfer=.002+.996*lin(t,10.9,11.4);}else if(t>=11.4){nc=false;no=true;transfer=1;}
    const fixedNC=[646,380],fixedNO=[646,570],moving=[646,mix(396,554,transfer)],radii=16;
    return {travel,nc,no,transfer,com:true,electricalTargetUs:70,simultaneousContacts:nc&&no,fixedNC,fixedNO,moving,ncGap:Math.hypot(moving[0]-fixedNC[0],moving[1]-fixedNC[1])-radii,noGap:Math.hypot(moving[0]-fixedNO[0],moving[1]-fixedNO[1])-radii,bouncePhase:p(t,11.7,12.3),bounce:bounceModel(t)};
  }
  function stateTrace(x,y,w,which,t,col){let pts=[];for(let i=0;i<=240;i++){let tt=i/240*14,v=spdtState(tt)[which];pts.push([x+w*i/240,y-(v?30:0)]);}path(pts,col,3);D.line(x+w*clamp(t/14),y-42,x+w*clamp(t/14),y+8,C.ink,2);}
  function bounceTrace(x,y,w,fn){const pts=[];for(let i=0;i<=600;i++){const u=i/60;pts.push([x+w*u/10,y-(fn(u)?27:0)]);}path(pts,C.mute,3);}
  Film.add({id:'a_spdt',title:'SINGLE POLE, DOUBLE THROW',subtitle:'SPDT gives the controller a rest contact and a press contact.',chapter:'Clicks',duration:24,old:['clk_spdt','latency','clk_debounce','clk_wait','clk_methods'],sources:[SOURCES.omron],evidence:'Illustrative bounce and state logic, not validated firmware. 70 µs electrical target starts after physical travel.',beats:[{t:0,label:'At rest, COM touches NC: normally closed.'},{t:4.2,label:'The press opens NC before the moving contact reaches NO.'},{t:4.7,label:'Now COM touches NO: normally open. The controller can distinguish the two states.'},{t:7.2,label:'Release reverses the transfer; contact bounce still needs sound firmware handling.'},{t:12,label:'Time expanded: one press makes several NO edges. An ordinary quiet-time filter waits for them to settle.'},{t:16,label:'The illustrated SPDT logic accepts the first press and waits for NC before arming another.'},{t:20,label:'Low debounce by default; adjustable double-click behavior also serves Minecraft preferences.'}],checks:spdtState,draw(t){
    const q=spdtState(t);D.text('ONE MOVING CONTACT',110,225,28,C.mute);D.rect(150,302,590,350,C.panel,14,C.line,2);
    D.line(236,597,236,675,C.mute,12);D.circle(236,497,12,C.ink);D.line(236,497,236,597,C.ink,10);
    D.line(646,380,700,380,q.nc?C.blue:C.mute,14);D.line(646,570,700,570,q.no?C.blue:C.mute,14);
    const cy=q.moving[1];D.path([[236,497],[350,480],[510,cy+10],q.moving],{stroke:C.ink,width:11});D.circle(...q.moving,9,C.ink);
    D.rect(414,269+q.travel*39,34,135,C.mute,12);D.rect(403,255+q.travel*39,56,25,C.blue,12);D.arrow(431,238,431,249+q.travel*39,C.ink,4);
    D.text('COM',195,723,26,C.ink);D.text('NC',672,351,27,q.nc?C.blue:C.mute);D.text('NO',672,615,27,q.no?C.blue:C.mute);
    D.alpha(1-q.bouncePhase,()=>{D.text(q.nc?'REST':q.no?'PRESSED':'TRANSFERRING',873,260,43,q.nc||q.no?C.blue:C.mute);
    D.text('NC',870,340,26,C.mute);D.text(q.nc?'closed':'open',960,340,29,q.nc?C.blue:C.mute);D.text('NO',1190,340,26,C.mute);D.text(q.no?'closed':'open',1280,340,29,q.no?C.blue:C.mute);
    D.label('contact state over this demonstration',873,416);stateTrace(880,487,600,'nc',t,C.blue);D.label('NC',873,451,C.blue);stateTrace(880,589,600,'no',t,C.yellow);D.label('NO',873,554,C.yellow);
    D.text('70 µs',873,691,47,C.blue);D.wrap('electrical target after the edge',1065,668,410,25,C.mute,32);
    D.label('physical travel happens before that clock starts',873,745);});
    D.alpha(q.bouncePhase,()=>{
      const b=q.bounce,X=u=>900+56*u;D.text('BOUNCE, TIME EXPANDED',873,260,31,C.ink);D.text('One press can make several electrical edges.',873,309,23,C.mute);
      D.label('raw NO',873,350);bounceTrace(900,394,560,bounceNO);D.label('NC return arms the next press',873,433);bounceTrace(900,477,560,bounceNC);
      D.label('accepted presses: '+b.acceptedPresses+'   rejected bounce: '+b.rejectedBounceEdges,873,517,C.blue);
      const accepted=u=>{let held=false;for(const e of b.events)if(e.ms<=u&&e.accepted)held=e.type==='press';return held;};bounceTrace(900,563,560,accepted);
      for(const e of b.events)if(e.type==='press'&&e.ms<=b.nowMs){const x=X(e.ms);if(e.accepted){D.circle(x,536,6,C.blue);D.line(x,525,x,550,C.blue,2);}else{D.line(x-4,380,x+4,388,C.red,2);D.line(x-4,388,x+4,380,C.red,2);}}
      D.line(X(b.nowMs),335,X(b.nowMs),577,C.ink,1.5);D.dim(X(2),618,X(b.waitAcceptedMs),618,'',C.yellow);D.text('wait',(X(2)+X(b.waitAcceptedMs))/2,604,23,C.yellow,'center');D.text('One-contact filter: 2 ms quiet-time example',873,651,23,C.mute);
      D.text('70 µs',873,710,43,C.blue);D.wrap('electrical target after the edge',1045,691,430,24,C.mute,30);D.text('Low default; adjustable for double-click / Minecraft',873,754,23,C.mute);
    });
  }});

  const weave=arr(24,y=>arr(24,x=>{const v=Math.sin(x*12.9898+y*78.233)*43758.5453;return .18+.7*(v-Math.floor(v))+.1*((x+y)%2);})),textureCache=new Map();
  function textureField(sigma=0,shift=0){
    sigma=Math.round(sigma*100)/100;const key=sigma+':'+shift;if(textureCache.has(key))return textureCache.get(key);const n=24,r=sigma>.03?Math.ceil(sigma*2):0;
    const field=arr(n,j=>arr(n,i=>{let v=0,w=0;for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){let k=r?Math.exp(-(dx*dx+dy*dy)/(2*sigma*sigma)):1;v+=weave[clamp(j+dy,0,n-1)][((i+dx+shift)%n+n)%n]*k;w+=k;}return v/w;}));textureCache.set(key,field);return field;
  }
  function texture(x,y,size,sigma=0,shift=0){const n=24,step=size/n,field=textureField(sigma,shift);for(let j=0;j<n;j++)for(let i=0;i<n;i++){const c=Math.round(45+145*field[j][i]);D.rect(x+i*step,y+j*step,step+.5,step+.5,`rgb(${c},${c},${c})`,0);}}
  function focusState(t){
    const drift=.20*p(t,4,7)*(1-p(t,10,13)),blurSigma=Math.abs(drift)*9,frameShift=Math.round(3*p(t,0,2)),second=textureField(blurSigma,frameShift);
    const candidates=arr(7,offset=>{let error=0;for(let y=0;y<24;y++)for(let x=0;x<24;x++)error+=(weave[y][(x+offset)%24]-second[y][x])**2;return {offset,error:error/(24*24),score:Math.max(0,1-error/(24*24)/.08)};});
    const best=candidates.reduce((a,b)=>a.error<b.error?a:b);return {heightErrorMm:drift,blurSigma,targetBandMm:.20,comparisonBandMm:.40,frameShift,recoveredOffset:best.offset,candidates,measured:false};
  }
  Film.add({id:'a_focus',title:'THE SENSOR IS A CAMERA',subtitle:'A frame moves. Correlation recovers motion. Focus preserves the detail.',chapter:'Glide',duration:20,old:['gld_camera','gld_corr','gld_blur','focus','sensor'],sources:[SOURCES.lens],evidence:'PAW3970 / Viper V4 identity: Brock’s suspicion; access after exclusivity is conditional. Focus band and blur are design models.',beats:[{t:0,label:'The sensor compares two small pictures of the same surface.'},{t:2,label:'Try several image offsets. The strongest match recovers the three-step displacement.'},{t:5,label:'Change the lens height: blurred texture weakens the matching signal.'},{t:10,label:'Return to the design height; the same translated pattern becomes distinct again.'},{t:13,label:'Support the lens and board together to preserve the intended focus.'}],checks:focusState,draw(t){
    const q=focusState(t),dy=q.heightErrorMm*300;D.text('LENS + SENSOR ASSEMBLY',110,221,27,C.mute);
    chip(418,306+dy,170,68);D.rect(280,350+dy,278,16,'#303a43',2);D.rect(369,367+dy,100,70,'#465563',18,C.mute,2);D.line(376,418+dy,462,418+dy,C.blue,5);
    D.ctx.save();D.ctx.beginPath();D.ctx.rect(135,582,580,90);D.ctx.clip();texture(135,582,580,0,0);D.ctx.restore();D.line(135,582,715,582,C.mute,2);
    for(const x of [323,419,515]){D.line(x,582,419,421+dy,C.blue,1.5);D.line(419,421+dy,419+(x-419)*(.13+q.blurSigma*.08),336+dy,C.blue,1.5);}
    D.dim(657,421+dy,657,582,'height');D.label('drawn mousepad weave',145,716);
    D.text('TWO FRAMES OF THE SAME TEXTURE',850,221,26,C.mute);texture(860,270,275,0,0);texture(1205,270,275,q.blurSigma,q.frameShift);
    D.text('frame A',860,581,25,C.mute);D.text('frame B: '+q.frameShift+' steps left',1205,581,25,q.heightErrorMm>.02?C.red:C.blue);
    if(q.frameShift>0){D.arrow(1325,554,1285,554,C.blue,3);}D.text('offset candidates',855,628,23,C.mute);
    q.candidates.forEach((v,i)=>{let x=856+i*88,good=v.offset===q.recoveredOffset;D.rect(x,707-v.score*60,65,v.score*60,good?C.blue:C.line,2);D.text(String(v.offset),x+32,739,23,good?C.blue:C.mute,'center');});
    D.text('best match: '+q.recoveredOffset,1195,628,27,C.blue);
    D.text('0.2 mm design band',145,752,26,C.blue);D.label('height error: '+q.heightErrorMm.toFixed(2)+' mm',430,752,q.heightErrorMm>.1?C.red:C.mute);
  }});

  function supportState(t){const areaRemote=2*30*12,areaDots=2*pi*3*3;return {load:p(t,2,5),supportAssembly:p(t,7,10),clipOffset:74*(1-p(t,7,10))+74*p(t,14.5,15.7)*(1-p(t,16.5,18)),clipFlex:5*(p(t,7,8)*(1-p(t,9,10))+p(t,14,15)*(1-p(t,17.7,18.5))),afterLoad:p(t,11,13),sensorDotXmm:[-11.5,11.5],sensorMouseZmm:16.57,ledgeLengthMm:23,ledgeCapacity:3,beforeSag:p(t,2,5)*40,afterSag:p(t,11,13)*9,sagIsIllustrative:true,areaRemoteMm2:areaRemote,areaDotsMm2:areaDots,relativeAddedSkateMass:areaDots/areaRemote};}
  function rimXAtY(y){const pts=FILM_GEOMETRY.sora.map(([x,yy])=>[x*3,yy*3]),xs=[];for(let i=0;i<pts.length;i++){const a=pts[i],b=pts[(i+1)%pts.length];if((a[1]<=y&&b[1]>y)||(b[1]<=y&&a[1]>y))xs.push(a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]));}return xs.length?Math.max(...xs.map(Math.abs)):75;}
  function underside(cx,y,good,assembly,clipOffset,clipFlex=0){D.group(cx,y,.76,0,()=>{
    D.mouse(0,0,1,{color:good?C.blue:C.mute,fill:C.panel,seam:false});D.rect(-22,-76.7,44,54,C.bg,8,C.mute,2);
    // Equal 23 mm ledges follow the actual outline, with rounded roots and three dot positions.
    for(const sx of [-1,1])for(const sy of [-1,1]){
      const cy=sy*105,outer=arr(15,i=>{const yy=cy-34.5+i/14*69;return [sx*rimXAtY(yy),yy];}),inner=outer.map(([xx,yy])=>[xx-sx*21,yy]).reverse();
      D.path([...outer,...inner],{close:true,fill:'#56616e',stroke:'#56616e',width:8});
      for(const k of [-1,0,1]){const yy=cy+k*21,xx=sx*(rimXAtY(yy)-10);D.circle(xx,yy,8.8,k===0?C.panel:C.ink,k===0?C.mute:null,1.5);}
    }
    if(!good){D.rect(-45,-134,90,36,C.yellow,8);D.rect(-45,99,90,36,C.yellow,8);}
    else D.group(0,clipOffset,1,0,()=>{
      path([[-44,-64],[-20,-64],[-20,-80],[20,-80],[20,-64],[44,-64],[44,-36],[20,-36],[20,-20],[-20,-20],[-20,-36],[-44,-36]],C.mute,3,'#3f4c59',true);
      D.rect(-17,-72,34,45,C.bg,8,C.mute,2);for(const sx of [-1,1]){D.circle(sx*34.5,-49.71,9,C.blue);D.line(sx*(19+clipFlex),-79,sx*(13+clipFlex),-84,C.blue,4);}D.circle(0,-49.71,8,C.bg,C.mute,2);
    });
    if(good&&clipOffset>1)D.arrow(0,15,0,-5,C.blue,3);
  });}
  function sagBeam(x,y,w,sag,near,col){support(x,y);support(x+w,y);const pts=arr(41,i=>{let u=i/40;return [x+u*w,y+sag*Math.sin(pi*u)];});path(pts,col,12);if(near){support(x+w*.43,y+sag*.6);support(x+w*.57,y+sag*.6);}const ly=y+sag;D.rect(x+w/2-22,ly-18,44,42,C.mute,7);D.circle(x+w/2,ly+26,9,col);D.force(x+w/2,y-90,60,'10 N example',C.ink);}
  Film.add({id:'a_support',title:'SUPPORT THE LENS WHERE IT SITS',subtitle:'A small support in the right place can do more than a large remote pad.',chapter:'Glide',duration:22,old:['dots','gld_sag','gld_under','gld_module'],sources:[SOURCES.mit],evidence:'10 N illustrative load, enlarged sag. Added-pad model: same material/thickness; two 30×12 mm pads versus two Ø6 mm dots.',beats:[{t:0,label:'The corner ledges are continuous with the rim; each has room for three dots.'},{t:3,label:'Adding large remote pads still leaves a free span under the lens.'},{t:8,label:'Snap the lens mount into place with its two support dots at ±11.5 mm.'},{t:13,label:'This geometric example uses 92% less added skate material beside the lens.'},{t:14.5,label:'Release the clip to remove the mount, then snap it back into the same supports.'},{t:18.5,label:'The replaceable module puts its support directly beside the optical assembly.'}],checks:supportState,draw(t){
    const q=supportState(t);rule();titlePair('EXTRA REMOTE PADS','TWO TARGETED DOTS');underside(414,400,false,1,0);underside(1160,400,true,q.supportAssembly,q.clipOffset,q.clipFlex);
    D.label('lens',548,377);D.line(532,371,432,364,C.mute,2);D.label('clip-on lens mount',1270,377,C.blue);D.line(1260,369,1186,364+q.clipOffset*.76,C.blue,2);
    D.text('720.0 mm² added',110,572,27,C.yellow);D.text('56.5 mm² added',855,572,27,C.blue);
    sagBeam(190,657,440,q.beforeSag,false,C.yellow);sagBeam(940,657,440,q.afterSag,true,C.blue);D.text('long free span',219,759,26,C.red);D.text('92% less added skate weight*',855,759,26,C.blue);
  }});

  function beamDelta(x,L,P,E,I){const a=Math.min(x,L-x);return P*a*(3*L*L-4*a*a)/(48*E*I);}
  function rulerState(t){const load=p(t,2,5),turn=p(t,7,10),second=p(t,11,13),E=13500,L=60,b=10,h=3.3,I=b*h*h*h/12,J=h*b*b*b/12;return {massG:1.01*L*b*h/1000,forceN:10,load,turn,second,I,J,beforeDeflectionMm:beamDelta(30,L,10,E,I),afterDeflectionMm:beamDelta(30,L,10,E,J),stiffnessRatio:J/I,capacityRatio:b/h};}
  function ruler(x,y,w,h,deflection,col){const top=arr(51,i=>{let f=i/50,u=f<=.5?f:1-f,shape=u*(3-4*u*u);return [x+w*f,y+deflection*shape-h/2];});const bottom=top.map(z=>[z[0],z[1]+h]).reverse();path([...top,...bottom],col,2,col,true);support(x,y+h/2);support(x+w,y+h/2);for(let i=1;i<12;i++)D.line(x+w*i/12,y-h/2+deflection*Math.sin(pi*i/12),x+w*i/12,y-h/2+8+deflection*Math.sin(pi*i/12),'#151b21',1.5);}
  Film.add({id:'a_ruler',title:'PUT THE SAME WEIGHT TO WORK',subtitle:'Try bending a ruler flat, then turn it on its edge.',chapter:'Structure',duration:19,old:['materials','thinwall','shlHotspot','shlMargin'],sources:[SOURCES.ruler,SOURCES.mit,SOURCES.pp],evidence:'60 ×10 ×3.3 mm PP-C-20A beam; 10 N classroom load. Euler–Bernoulli bending, displacement enlarged; not a shell test.',beats:[{t:0,label:'The same 2.0 g beam starts in both positions.'},{t:3,label:'A 10 N example load bends the flat beam.'},{t:7,label:'Rotate the second beam. The weight and material stay exactly the same.'},{t:13,label:'9.2× calculated bending stiffness comes from geometry, not extra weight.'}],checks:rulerState,draw(t){
    const q=rulerState(t);rule();titlePair('FLAT','TURNED ON EDGE');
    ruler(125,450,600,26,q.beforeDeflectionMm*550*q.load,C.yellow);ruler(870,450,600,mix(26,79,q.turn),q.afterDeflectionMm*550*q.second,C.blue);
    D.force(425,280,125,'10 N example');D.force(1170,280,125,'10 N example');D.text('2.0 g',125,592,42,C.ink);D.text('2.0 g',870,592,42,C.ink);
    D.text(q.beforeDeflectionMm.toFixed(3)+' mm',125,652,33,C.yellow);D.text(q.afterDeflectionMm.toFixed(3)+' mm',870,652,33,C.blue);D.label('calculated deflection',125,690);D.label('calculated deflection',870,690);
    D.text('9.2× BENDING STIFFNESS',110,756,38,C.blue);D.text('3.0× load at the same stress limit',920,755,25,C.mute);
  }});

  const MAT=[['PP-C-20A',13.5,1.01,120],['Magnesium AZ91D',44.8,1.81,230],['Aluminium 6061',68.9,2.70,310],['FR4, lengthwise',20,1.85,430],['ABS GR-2000',2.55,1.05,50],['PC Makrolon 2405',2.35,1.20,65]];
  function sectionCapacity(massG,rho,stressLimitMPa,redistributed=false){
    const span=60,width=10,area=1000*massG/(rho*span);let height=area/width,I=width*height**3/12,flange=0;
    if(redistributed){height=10;const web=.60;flange=(area-web*height)/(2*(width-web));I=(width*height**3-(width-web)*(height-2*flange)**3)/12;}
    const Z=I/(height/2);return {massG,areaMm2:area,heightMm:height,I,Z,flangeMm:flange,loadLimitN:4*stressLimitMPa*Z/span,stressLimitMPa,spanMm:span,widthMm:width};
  }
  function materialState(t){const cut=p(t,2,5),place=p(t,7,11),graphMass=1+3*p(t,21,27),thicknessRatio=1-.5*cut;return {cut,place,structuralMethod:p(t,12,14),graph:p(t,19,21),graphMass,thicknessRatio,massRatio:thicknessRatio,bendingRatio:thicknessRatio**3,capacityRatio:thicknessRatio**2,halfThicknessMass:.5,halfThicknessBending:.125,halfThicknessStrength:.25,job:'fixed footprint; thickness free; equal mass',rows:MAT.map(([name,E,rho,tensileMPa])=>({name,E,rho,tensileMPa,specificTensile:tensileMPa/rho,thickness:2e3/(rho*60*10),relativeBending:(E/(rho**3))/(13.5/1.01**3),capacity:sectionCapacity(graphMass,rho,tensileMPa),curve:arr(41,i=>sectionCapacity(1+3*i/40,rho,tensileMPa))})),theseusMethod:sectionCapacity(graphMass,1.01,120,true),methodCurve:arr(41,i=>sectionCapacity(1+3*i/40,1.01,120,true)),capacityModel:'coupon tensile numbers used as chosen stress limits, not bending allowables or whole-shell strengths'};}
  Film.add({id:'a_material',title:'THE STRENGTH–WEIGHT FALLACY',subtitle:'Weight alone cannot tell you how a mouse will feel or carry a load.',chapter:'Structure',duration:32,old:['shlSpecific','shlScatter','shlPick','shlNoPick','shlWork'],sources:[SOURCES.mit,SOURCES.pp,SOURCES.fr4,{label:'Conditional six-material input table',url:'https://www.tekogehause.de/uploads/manuali/materiali/AZ91D.pdf',note:'Inherited metal/ABS/PC scalar inputs; mixed yield/ultimate and modulus test bases. Tensile numbers become chosen stress limits only in the conditional beam graph, not engineering bending allowables. The GPX2 versus ULX build-quality comparison is Brock’s owner judgment.'}],evidence:'Conditional coupon/beam model, not a shell ranking. Tensile numbers are chosen stress limits, not bending allowables.',beats:[{t:0,label:'Brock found the heavier GPX2 worse in build feel than the lighter ULX.'},{t:3,label:'Half the wall thickness leaves 50% of the weight, 12.5% stiffness and 25% same-stress load capacity.'},{t:8,label:'Material choice depends on the job. Bending stiffness and tensile strength are different columns.'},{t:13,label:'Theseus combines low-density walls, continuous arches and the whole PCB as a tie.'},{t:20,label:'Higher strength per density helps a straight tie carry more load for each gram.'},{t:23,label:'For this fixed-width bending job, capacity instead follows strength divided by density squared.'},{t:27,label:'The blue line adds section redistribution at the same mass: a Theseus method model, not a finished-shell result.'}],checks:materialState,draw(t){
    const q=materialState(t);D.alpha(1-q.graph,()=>{D.text(q.structuralMethod<.5?'THICKNESS IS A TRADEOFF':'THESEUS: A STRUCTURAL METHOD',110,220,29,q.structuralMethod<.5?C.mute:C.blue);
    D.alpha(1-q.structuralMethod,()=>{D.rect(120,285,565,80,C.mute,2);D.rect(120,411,565,mix(80,40,q.cut),C.blue,2);});
    D.alpha(q.structuralMethod,()=>{for(const h of [115,82,50])path(arr(41,i=>{const u=i/40;return [125+560*u,451-h*Math.sin(pi*u)*q.structuralMethod];}),C.blue,5);D.line(125,473,685,473,C.blue,13);support(125,479);support(685,479);D.force(405,270,51,'same design load');D.label('arches into the board tie',235,518,C.blue);});
    const pct=v=>(100*v).toFixed(Number.isInteger(100*v)?0:1)+'%';D.text('wall weight',125,569,25,C.mute);D.text(pct(q.massRatio),465,569,32,C.ink);D.text('bending stiffness',125,614,25,C.mute);D.text(pct(q.bendingRatio),465,614,32,C.red);D.text('same-stress load',125,659,25,C.mute);D.text(pct(q.capacityRatio),465,659,32,C.yellow);
    D.text('SAME WEIGHT, SAME FOOTPRINT',835,220,28,C.ink);D.text('bending',1140,257,23,C.mute);D.text('tensile MPa*',1367,257,23,C.mute);
    q.rows.forEach((m,i)=>{const y=304+i*66,col=i===0?C.blue:C.mute;D.text(m.name,835,y,24,col);D.rect(1137,y-20,151,17,C.panel,1);D.rect(1137,y-20,151*m.relativeBending*q.place,17,col,1);D.text(m.relativeBending.toFixed(2)+'×',1348,y,23,col,'right');D.text(String(m.tensileMPa),1490,y,24,C.mute,'right');});
    D.text('GPX2: heavier, worse feel than ULX',110,718,26,C.ink);D.text('Brock’s owner comparison, not a strength test',110,753,23,C.mute);
    D.text('Bending: E / density³',835,712,26,C.blue);D.text('*Mixed coupon test bases; compare the stated job.',835,752,23,C.mute);});
    D.alpha(q.graph,()=>{
      const X=m=>160+(m-1)/3*890,Y=f=>688-f/1400*355,colors=[C.mute,C.yellow,'#8c949f','#b9c2ce','#677583','#e0e3e7'];
      D.text('SAME SPAN. SAME MASS. A DIFFERENT LOAD PATH.',110,220,30,C.ink);D.text('load at chosen stress limit (N)',110,283,25,C.mute);D.text('CONDITIONAL BEAM MODEL',1120,283,25,C.mute);
      for(const f of [0,400,800,1200]){D.line(160,Y(f),1050,Y(f),C.line,1);D.text(String(f),143,Y(f)+8,23,C.mute,'right');}D.line(160,327,160,688,C.mute,2);D.line(160,688,1050,688,C.mute,2);
      const drawCurve=(curve,col,width)=>{const points=curve.filter(v=>v.massG<=q.graphMass).map(v=>[X(v.massG),Y(v.loadLimitN)]);if(points.length>1)path(points,col,width);};
      q.rows.forEach((r,i)=>{drawCurve(r.curve,colors[i],2.5);D.line(1120,381+i*44,1152,381+i*44,colors[i],3);D.text(r.name,1167,390+i*44,23,colors[i]);});drawCurve(q.methodCurve,C.blue,5);
      D.line(X(q.graphMass),326,X(q.graphMass),698,C.ink,1.5,[4,5]);D.circle(X(q.graphMass),Y(q.theseusMethod.loadLimitN),6,C.blue);D.text('THESEUS METHOD',1120,330,27,C.blue);D.text('PP section redistribution',1120,359,22,C.blue);
      for(const m of [1,2,3,4])D.text(m+' g',X(m),726,24,C.mute,'center');D.text('material in the same 60 mm beam',290,764,24,C.mute);D.wrap('10 mm width. Flat sections change thickness; blue redistributes the same PP into a 10 mm deep I-section.',1120,679,390,23,C.mute,29);
    });
  }});

  function latticeState(t){
    const load=p(t,2,5),thin=1-.5*p(t,8,12),rack=load*50/thin,L=215,W=180,y=550,topY=y-Math.sqrt(L*L-rack*rack);
    const square=[[155,y],[155+W,y],[155+W+rack,topY],[155+rack,topY]],hexR=105,theta=(60+18*load/thin/2)*rad,h=hexR*Math.cos(theta),v=hexR*Math.sin(theta),cx=770,cy=550-v;
    const hex=[[cx-hexR/2-h,cy],[cx-hexR/2,cy-v],[cx+hexR/2,cy-v],[cx+hexR/2+h,cy],[cx+hexR/2,cy+v],[cx-hexR/2,cy+v]],tri=[[1125,y],[1410,y],[1410,335],[1125,335]];
    const lengths=pts=>pts.map((a,i)=>Math.hypot(a[0]-pts[(i+1)%pts.length][0],a[1]-pts[(i+1)%pts.length][1]));
    return {load,teachingForceN:5,widthRatio:thin,axialStiffness:thin,bendingStiffness:thin**3,relativeAxialAdvantage:1/(thin**2),ribDeflectionLimitMm:1,ribInitialStiffnessNPerMm:5,axialLoadAtDeflectionLimitN:5*thin,bendingLoadAtDeflectionLimitN:5*thin**3,beforeRack:rack,afterRack:0,square,hex,tri,squareMemberLengths:lengths(square),hexMemberLengths:lengths(hex),triMemberLengths:lengths(tri),diagonalLength:Math.hypot(285,215),deformationIllustrative:true};
  }
  function frame(pts,edges,width,color){edges.forEach(([a,b])=>D.line(...pts[a],...pts[b],color,width));pts.forEach(([x,y])=>D.circle(x,y,width*.7,C.bg,color,2));}
  Film.add({id:'a_lattice',title:'TRIANGLES MAKE RACKING COST ENERGY',subtitle:'A square and a hexagon can change shape without stretching their bars.',chapter:'Structure',duration:19,old:['lattice','shlDeterminate','shlThin','shlShell3d'],sources:[SOURCES.straw,SOURCES.ashby],evidence:'Hinges: illustrative 5 N input. Separate rib law: equal initial 5 N/mm, fixed depth; deflection limit, not failure load.',beats:[{t:0,label:'The square and hexagon have hinges; every bar keeps its original length.'},{t:3,label:'Close the load path with a diagonal. Racking now requires material strain.'},{t:8,label:'At lower rib weight, axial stiffness falls with width; in-plane bending falls with width cubed.'},{t:12,label:'At the same deflection limit, the half-width axial rib retains four times the relative load.'}],checks:latticeState,draw(t){
    const q=latticeState(t),w=18*q.widthRatio;D.text('FOUR BARS',110,220,28,C.mute);D.text('SIX BARS',605,220,28,C.mute);D.text('CLOSED TRIANGLES',1085,220,28,C.blue);
    frame(q.square,[[0,1],[1,2],[2,3],[3,0]],w,C.yellow);frame(q.hex,[[0,1],[1,2],[2,3],[3,4],[4,5],[5,0]],w,C.yellow);frame(q.tri,[[0,1],[1,2],[2,3],[3,0]],w,C.mute);frame(q.tri,[[0,2]],w,C.blue);
    for(const x of [155,335,1125,1410])support(x,551);support(q.hex[4][0],q.hex[4][1]);support(q.hex[5][0],q.hex[5][1]);
    for(const x of [155,635,1125]){D.arrow(x-15,278,x+85,278,C.ink,3);D.text('5 N example',x-8,306,22,C.mute);}
    D.text('RIB MODEL: BOTH START AT 5 N PER 1 MM',110,655,25,C.mute);D.text('width  '+(q.widthRatio*100).toFixed(0)+'%',110,704,33,C.ink);D.text('same 1 mm deflection limit',110,749,23,C.mute);D.text('axial  '+q.axialLoadAtDeflectionLimitN.toFixed(2)+' N',570,700,30,C.blue);D.text('bending  '+q.bendingLoadAtDeflectionLimitN.toFixed(3)+' N',570,744,30,C.yellow);D.text(q.relativeAxialAdvantage.toFixed(1)+'×',1320,713,59,C.blue,'right');D.text('relative load at that limit',1030,754,24,C.mute);
  }});

  function domeGeometry(cx,cy,s){
    const curves=[],feet=[],angles=arr(97,i=>i*pi/48),project=(x,z,h)=>[cx+s*(x*235+z*56),cy+s*(z*74-h*192)];
    for(let a=0;a<3;a++)for(let off of [-.55,0,.55]){let ang=a*pi/3,v=[Math.cos(ang),Math.sin(ang)],n=[-v[1],v[0]],ext=Math.sqrt(1-off*off);let pts=arr(61,i=>{let u=mix(-ext,ext,i/60),xx=v[0]*u+n[0]*off,zz=v[1]*u+n[1]*off,h=(i===0||i===60)?0:Math.sqrt(Math.max(0,1-xx*xx-zz*zz));if(i===0||i===60){angles.push((Math.atan2(zz,xx)+pi*2)%(pi*2));feet.push(project(xx,zz,0));}return project(xx,zz,h);});curves.push(pts);}
    angles.sort((a,b)=>a-b);const rim=angles.map(a=>project(Math.cos(a),Math.sin(a),0));
    const maxFootToRimError=Math.max(...feet.map(f=>Math.min(...rim.map(r=>Math.hypot(f[0]-r[0],f[1]-r[1])))));
    return {curves,rim,feet,maxFootToRimError};
  }
  function catenaryForSpan(halfSpan,arcLength){let lo=.000001,hi=3;for(let i=0;i<50;i++){const a=(lo+hi)/2;if(Math.sinh(a)/a>arcLength/(2*halfSpan))hi=a;else lo=a;}const a=(lo+hi)/2,k=halfSpan/a;return {a,k,rise:k*(Math.cosh(a)-1),arcLength:2*k*Math.sinh(a)};}
  function archState(t){
    const dome=domeGeometry(1180,581,1.13),spread=25*p(t,8,10)*(1-p(t,12,14)),chainLength=2*285/.88*Math.sinh(.88),cat=catenaryForSpan(285+spread,chainLength),settle=p(t,0,2),flip=p(t,4,7);
    const chain=arr(61,i=>{const u=mix(-1,1,i/60);return [435+(285+spread)*u,400+settle*cat.k*(Math.cosh(cat.a)-Math.cosh(cat.a*u))*(1-2*flip)];});
    const totalLoadN=10,spanMm=200,riseMm=50;return {settle,flip,weave:p(t,7,12),flow:p(t,15,18),spread,tie:p(t,12,14),comparison:p(t,14,17),chain,chainLength:cat.arcLength,chainRise:cat.rise,feet:[chain[0],chain[60]],uniformExample:{totalLoadN,spanMm,riseMm,verticalReactionN:totalLoadN/2,flatPeakMomentNmm:totalLoadN*spanMm/8,archHorizontalThrustN:totalLoadN*spanMm/(8*riseMm),idealArchMomentNmm:0,model:'three-hinged parabolic arch, uniform vertical load'},continuousArchFamilies:3,archesPerFamily:3,dome,feetAtRim:dome.maxFootToRimError<1e-9};
  }
  Film.add({id:'a_arches',title:'CONTINUOUS ARCHES, SHARED LOAD PATHS',subtitle:'Hang a chain. Turn its load path into an arch. Then weave the arches.',chapter:'Structure',duration:24,old:['shbArches','shbPress','shbThrust','shbBend'],sources:[SOURCES.chain,SOURCES.ashby,SOURCES.mit],evidence:'Chain: self-weight. Small comparison: ideal 200 mm span / 50 mm rise, 10 N uniform load. Shell weave is a design illustration.',beats:[{t:0,label:'A hanging chain carries its weight in tension along one continuous path.'},{t:4,label:'Invert the same curve: an arch carries the matching load mainly in compression.'},{t:8,label:'Compression pushes the feet outward. If the feet spread, the arch loses height.'},{t:12,label:'A tie or stiff rim resists that outward thrust. The load path must include its supports.'},{t:16,label:'Under the same 10 N uniform load, the flat member bends; the ideal parabolic arch trades bending for thrust.'},{t:20,label:'Weave continuous arches into triangles and carry every foot into the lower rim.'}],checks:archState,draw(t){
    const q=archState(t);D.text('THE HANGING-CHAIN LESSON',110,220,28,C.mute);D.text('THE SAME IDEA IN THE SHELL',855,220,28,C.blue);
    const left=q.chain;path(left,q.flip>.7?C.blue:C.yellow,9);
    D.line(105,430,765,430,C.line,2);for(const [x,y] of q.feet){D.rect(x-14,y,28,16,C.mute,2);D.circle(x-8,y+23,5,C.bg,C.mute,2);D.circle(x+8,y+23,5,C.bg,C.mute,2);}
    for(const i of [8,20,30,40,52])D.arrow(left[i][0],left[i][1]-51,left[i][0],left[i][1]-13,C.mute,2);
    if(q.flip>.7){const a=q.feet[0][0],b=q.feet[1][0];D.arrow(a+24,458,a-22,458,C.red,3);D.arrow(b-24,458,b+22,458,C.red,3);D.alpha(q.tie,()=>D.line(a,400,b,400,C.blue,7));}
    D.text(q.flip<.5?'tension follows the curve':q.tie>.8?'the tie holds the feet together':'unrestrained feet spread outward',110,497,25,q.flip<.5?C.yellow:q.tie>.8?C.blue:C.red);
    D.alpha(q.comparison,()=>{
      const e=q.uniformExample;D.text('10 N TOTAL ON EACH, UNIFORM LOAD',110,551,24,C.ink);
      for(const [x,arch] of [[150,false],[500,true]]){const pts=arr(31,i=>{const u=i/30;return [x+230*u,686-(arch?52*4*u*(1-u):0)];});path(pts,arch?C.blue:C.yellow,9);support(x,686);support(x+230,686);for(const i of [4,11,19,26])D.arrow(pts[i][0],585,pts[i][0],pts[i][1]-13,C.mute,2);if(arch){D.arrow(x+29,719,x-11,719,C.red,2);D.arrow(x+201,719,x+241,719,C.red,2);}else{D.path([[x+84,691],[x+115,707],[x+146,691]],{stroke:C.red,width:3});}}
      D.text('bending: '+e.flatPeakMomentNmm+' N·mm',110,759,23,C.yellow);D.text('thrust: '+e.archHorizontalThrustN+' N',505,759,23,C.blue);
    });
    const {curves,rim}=q.dome;path(rim,C.mute,5);
    curves.forEach((curve,i)=>{const amount=clamp(q.weave*9-i);if(amount>0)path(curve.slice(0,Math.max(2,Math.round(61*amount))),i%3===1?C.blue:'#6995c9',4);if(q.flow>0){dotRoute(curve.slice(30),q.flow,C.blue,4);dotRoute(curve.slice(0,31).reverse(),q.flow,C.blue,4);}});
    D.text('arches first',910,704,32,C.blue);D.text('triangles at their intersections',910,747,26,C.mute);
  }});

  function cornerPath(x,y,r){const pts=[[x,y],[x+250-r,y]];for(let i=0;i<=20;i++){const a=-pi/2+i/20*pi/2;pts.push([x+250-r+r*Math.cos(a),y+r+r*Math.sin(a)]);}pts.push([x+250,y+230]);return pts;}
  function filletState(t){const radiusMm=.60,shapeToleranceMm=.05,toolRadiusMm=.50,pathAllowanceMm=.03;return {load:p(t,2,4),flow:p(t,5,10),tool:p(t,11,14),detail:p(t,15,17),grain:p(t,26,28),grainSeparationPx:12*p(t,28,31),widthsMm:[2,4],sameThicknessAreaRatio:2,sharpRatio:12/104,roundRatio:86/104,illustrativeFibres:true,manufacturingMethod:'not selected',radiusMm,shapeToleranceMm,toolRadiusMm,pathAllowanceMm,minRadiusMm:radiusMm-shapeToleranceMm,remainingAllowanceMm:radiusMm-shapeToleranceMm-toolRadiusMm-pathAllowanceMm,toolCenterOffsetMm:pathAllowanceMm*Math.sin(t*1.3)};}
  Film.add({id:'a_fillets',title:'ROUND THE JUNCTION, KEEP THE LOAD MOVING',subtitle:'One fillet connects stress, fibre flow and tool access.',chapter:'Structure',duration:36,old:['fillet','filletsize','shbFibres','shbWidth','shbMill','shbMillDirect','shbTol'],sources:[SOURCES.fillet,SOURCES.fibres,SOURCES.wood],evidence:'Illustrated flow and wood analogy; chosen tooling bounds. Neither wood nor coupon data establish molded-shell strength.',beats:[{t:0,label:'A sharp internal corner gives load and material flow an abrupt turn.'},{t:3,label:'The stress peak concentrates at the corner. A rounded root spreads the transition.'},{t:6,label:'Fibre direction matters; guide the flow, then validate the molded orientation.'},{t:12,label:'The same rounded root also admits a finite-radius cutter or electrode.'},{t:17,label:'Width adds section area. Fibre alignment depends on flow, so wider is not automatically better.'},{t:22,label:'A 0.50 mm tool plus 0.03 mm path allowance fits inside the chosen 0.55 mm minimum radius.'},{t:25,label:'Direct-milled core or EDM electrode: both need access. The process remains undecided.'},{t:28,label:'Think of wood grain: the same pull along the fibres differs from pulling them apart.'},{t:32,label:'Guide the fibres along the load path, then validate the actual molded orientation.'}],checks:filletState,draw(t){
    const q=filletState(t);rule();titlePair(q.detail<.5?'ABRUPT JUNCTION':q.grain<.5?'WIDTH AND FIBRE DIRECTION':'THINK OF WOOD GRAIN',q.detail<.5?'ROUNDED JUNCTION':'A TOOL NEEDS ROOM');
    D.alpha(1-q.detail,()=>{
    for(const [x,r,col] of [[215,12,C.yellow],[960,86,C.blue]]){const pts=cornerPath(x,350,r);path(pts,'#3c434c',104);path(pts,C.panel,72);path(pts,col,2);D.arrow(x-55,350,x+45,350,C.ink,3);D.arrow(x+250,504,x+250,588,C.ink,3);
      if(q.load>.1)D.circle(x+250-r*.45,350+r*.45,24*q.load,null,r===12?C.red:C.blue,5);
      for(let k=0;k<13;k++){let f=clamp(q.flow*1.45-k*.065);if(f<=0||f>=1)continue;const j=Math.min(pts.length-2,Math.floor(f*(pts.length-1))),a=pts[j],b=pts[j+1],ang=Math.atan2(b[1]-a[1],b[0]-a[0]);D.line(a[0]-10*Math.cos(ang),a[1]-10*Math.sin(ang),a[0]+10*Math.cos(ang),a[1]+10*Math.sin(ang),col,3);}
      if(r>20&&q.tool>0){const a=-pi/2+q.tool*pi/2,tx=x+250-r+r*Math.cos(a),ty=350+r+r*Math.sin(a);D.circle(tx,ty,30,C.bg,C.ink,3);for(let k=0;k<8;k++){let z=k*pi/4+q.tool*pi;D.line(tx+22*Math.cos(z),ty+22*Math.sin(z),tx+29*Math.cos(z),ty+29*Math.sin(z),C.mute,2);}}
    }
    D.text('local stress raiser',110,660,31,C.red);D.text('gentler transition',855,660,31,C.blue);D.wrap('Sharp corners do not help the fibres or the tool turn.',110,714,610,26,C.mute,32);D.wrap('A continuous member still needs good junctions, gates and supports.',855,714,610,26,C.mute,32);
    });
    D.alpha(q.detail,()=>{
      D.alpha(1-q.grain,()=>{for(const [y,w,i] of [[329,30,0],[466,60,1]]){D.rect(140,y-w/2,555,w,'#34414f',w/2,C.mute,2);for(let k=0;k<15;k++){const u=((t*.10+k/15)%1),x=150+535*u,yy=y+(i?Math.sin(k*2.7)*18:Math.sin(k*2.7)*5),a=i?.6*Math.sin(k*1.9):.12*Math.sin(k);D.line(x-8*Math.cos(a),yy-8*Math.sin(a),x+8*Math.cos(a),yy+8*Math.sin(a),i?C.mute:C.blue,3);}D.arrow(102,y,132,y,C.blue,3);D.label(q.widthsMm[i]+' mm passage',140,y-43);D.label(i?'wider: more section area':'narrower: less section area',140,y+54);}
      D.text('2× area at the same thickness',110,587,29,C.blue);D.wrap('That is a geometry gain. Fibre direction still follows the flow, gate and local turn.',110,635,610,26,C.mute,33);D.text('Wider does not automatically mean better aligned.',110,751,23,C.ink);});
      D.alpha(q.grain,()=>{
        D.label('pull along the grain',110,276,C.blue);D.rect(190,306,440,78,'#5b5951',2,C.mute,2);for(let j=0;j<7;j++)D.line(197,314+j*10,623,314+j*10,'#99988d',2);D.arrow(181,345,122,345,C.ink,3);D.arrow(639,345,698,345,C.ink,3);D.text('fibres carry the tension',110,425,28,C.blue);
        D.label('pull across the grain',110,477,C.mute);const split=q.grainSeparationPx;for(const side of [-1,1]){const x=side<0?190-split:410+split;D.rect(x,506,220,78,'#5b5951',2,C.mute,2);for(let j=0;j<18;j++)D.line(x+8+j*12,513,x+8+j*12,577,'#99988d',2);}D.arrow(181-split,545,122-split,545,C.ink,3);D.arrow(639+split,545,698+split,545,C.ink,3);if(split>.1)path([[410-split,506],[404-split,522],[413-split,542],[406-split,565],[410-split,584]],C.red,3);D.text('separation follows the grain',110,625,28,C.red);
        D.wrap('Wood makes the direction visible. Filled PP still needs its own molded-orientation data.',110,683,610,25,C.mute,32);
      });
      const sx=200,cx=1175,cy=425,nom=q.radiusMm*sx,min=q.minRadiusMm*sx,tr=q.toolRadiusMm*sx,dx=q.toolCenterOffsetMm*sx;
      D.circle(cx,cy,nom,null,C.line,2);D.circle(cx,cy,min,null,C.blue,3);D.circle(cx+dx,cy,tr,C.panel,C.ink,3);for(let k=0;k<12;k++){const a=k*pi/6+t*.25;D.line(cx+dx+(tr-10)*Math.cos(a),cy+(tr-10)*Math.sin(a),cx+dx+tr*Math.cos(a),cy+tr*Math.sin(a),C.mute,2);}D.line(cx-7,cy,cx+7,cy,C.blue,2);D.line(cx,cy-7,cx,cy+7,C.blue,2);
      D.text('0.60 ± 0.05 mm radius',855,282,29,C.blue);D.label('minimum boundary: 0.55 mm',855,579,C.blue);D.label('tool 0.50 + path allowance 0.03 mm',855,624);D.text(q.remainingAllowanceMm.toFixed(2)+' mm remaining',855,674,34,C.ink);D.text('Direct-milled core or EDM electrode',855,720,25,C.mute);D.text('chosen example, process not yet selected',855,756,23,C.mute);
    });
  }});

  function boardFallback(x,y,s=1){D.group(x,y,s,0,()=>{const half=[[0,-228],[32,-228],[70,-203],[115,-203],[115,-105],[91,-75],[91,25],[115,55],[115,160],[45,160],[33,139],[0,139]],all=[...half,...half.slice(1,-1).reverse().map(a=>[-a[0],a[1]])];path(all,C.mute,3,'#242b32',true);D.rect(-43,-169,86,109,C.bg,10,C.mute,2);chip(0,-10,54,68);chip(0,88,58,62);for(const xx of [-60,60])for(const yy of [-50,128]){D.circle(xx,yy,10,C.bg,C.mute,3);}for(let i=0;i<7;i++){D.line(-90+i*27,40,-70+i*24,117,C.line,1);}D.rect(-22,-243,44,40,C.mute,5);});}
  function pcbState(t){return {beforeLoad:p(t,2,5),boardAssembly:p(t,7,10),afterLoad:p(t,11,14),wholeBoardTie:true,personalArmPhotoAvailable:false,fr4TypicalTensileMPa:430,fr4TypicalFlexuralGPa:20,poronAtContact:true,padCompression:p(t,11,14)*3};}
  Film.add({id:'a_pcb',title:'USE THE WHOLE BOARD AS STRUCTURE',subtitle:'FR4 is woven glass and epoxy. It can do more than carry traces.',chapter:'Structure',duration:20,old:['shlPcbRib','shcCarry','shcArms','shlStructs','grind'],sources:[SOURCES.fr4],evidence:'Attachment/load-path illustration. Personal broken-arm photos are unavailable; no claimed whole-board strength multiplier.',beats:[{t:0,label:'A tiny reinforcing arm concentrates the load at a narrow root.'},{t:3,label:'Brock reports an HTS Ultra arm breaking in shipping; the original photo is unavailable.'},{t:8,label:'Connect broad shell supports through the board that is already there.'},{t:13,label:'Use the woven composite as a tie, with contact pads where board and shell meet.'}],checks:pcbState,draw(t){
    const q=pcbState(t);rule();titlePair('SMALL ATTACHMENT ARMS','THE WHOLE PCB AS A TIE');
    boardFallback(410,460,.84);
    D.rect(285,394,37,124,C.yellow,3);D.rect(498,394,37,124,C.yellow,3);D.arrow(195,433,295,433,C.ink,4);D.arrow(625,433,525,433,C.ink,4);
    const crack=q.beforeLoad;path([[307,411],[318,420],[307,432],[320,443],[311,456]],C.red,4*crack);D.line(285,396,285-crack*29,352,C.yellow,11);D.line(535,396,535+crack*29,352,C.yellow,11);
    if(typeof window.AstraDrawBoard==='function')window.AstraDrawBoard(1160,450,6.3,{placed:1,under:false,variant:'window'});else boardFallback(1160,460,.84);
    const a=q.boardAssembly;D.alpha(a,()=>{for(const xx of [1047,1273]){D.rect(xx-12,342,24,243,'#5e6974',5);D.rect(xx-13,392,26,70,C.blue,5);for(const yy of [363,558]){D.rect(xx-16,yy,32,12-q.padCompression,'#adb6c1',3);for(let i=0;i<4;i++)D.circle(xx-10+i*7,yy+4,1.3,C.bg);}}D.arrow(930,429,1040,429,C.ink,4);D.arrow(1390,429,1280,429,C.ink,4);D.line(1064,429,1256,429,C.blue,8);});
    if(q.afterLoad>0){dotRoute([[1047,429],[1130,420],[1258,429]],q.afterLoad,C.blue,7);dotRoute([[1273,455],[1160,520],[1060,500]],q.afterLoad,C.blue,7);}
    D.text('narrow root',110,664,33,C.red);D.text('broad load path',855,664,33,C.blue);D.wrap('A schematic explains the failure mode; it is not a trace of the missing photo.',110,714,610,25,C.mute,31);D.wrap('Factory Poron at the contact sites. Brock cites G-Wolves anti-creak pad mods.',855,714,610,25,C.mute,31);
  }});

  function hotSwapState(t){
    const release=p(t,2,4)*(1-p(t,17,18.2)),oldLift=185*p(t,5,8.5),newLift=185*(1-p(t,13.5,17)),oldAlpha=1-p(t,9,11),newAlpha=p(t,11,12.5);
    return {boardY:650,socketY:650,pinSpacingMm:5.08,clawOpen:release,clawTipGap:36+release*50,oldLift,newLift,oldAlpha,newAlpha,oldX:450-190*p(t,9,11),newX:450+200*(1-p(t,11.5,13.5)),activeLift:t<11?oldLift:newLift,seated:t<5||t>=17,retained:t<2||t>=18.2};
  }
  Film.add({id:'a_hotswap',title:'CHANGE THE SWITCH, KEEP THE MOUSE',subtitle:'Claw retention keeps the switch secure and makes service possible.',chapter:'Ownership',duration:21,old:['clk_hotswap','ownsheet1','repair'],sources:[],evidence:'Proposed removable-switch assembly. Socket/claw dimensions are illustrative; selected hardware and retention testing remain open.',beats:[{t:0,label:'Three pins sit in sockets. The board stays fixed.'},{t:2,label:'Flex the retaining claws away from the switch before lifting it.'},{t:5,label:'Lift the switch straight out; the sockets remain attached to the board.'},{t:11,label:'Insert a replacement with the same footprint, then let the claws grip again.'},{t:18.2,label:'Replace a worn switch or choose a different click feel without replacing the mouse.'}],checks:hotSwapState,draw(t){
    const q=hotSwapState(t);D.text('REMOVE AND REPLACE',110,220,28,C.mute);D.text('CLAW + SOCKET, ENLARGED',890,220,28,C.blue);
    D.rect(190,650,550,24,'#303a43',2);D.line(190,650,740,650,C.mute,3);
    for(const z of [-5.08,0,5.08]){let x=450+22*z;D.rect(x-10,643,20,43,'#ad9d73',5);D.rect(x-4,640,8,38,C.bg,3);}
    for(const sx of [-1,1]){const root=[450+sx*160,648],tip=[450+sx*(159+q.clawOpen*32),520];D.path([root,[root[0]+sx*17,592],tip,[tip[0]-sx*18,522]],{stroke:C.mute,width:10});}
    D.alpha(q.oldAlpha,()=>switchSide(q.oldX,650-q.oldLift,22,0,true,C.mute,false));D.alpha(q.newAlpha,()=>switchSide(q.newX,650-q.newLift,22,0,true,C.blue,false));
    D.label('fixed PCB and sockets',200,727);if(t>2&&t<9){D.arrow(683,560,710,520,C.blue,3);D.label('release',638,493,C.blue);}
    // The same opening and extraction state drives the contact close-up.
    const zx=1170,tipLeft=zx-q.clawTipGap/2,tipRight=zx+q.clawTipGap/2,pinBottom=554-q.activeLift*1.30;
    D.rect(992,610,360,24,'#303a43',2);D.rect(1060,418,220,192,'#424950',14,C.mute,2);D.rect(1100,418,140,161,C.bg,8);
    D.path([[1110,601],[1088,535],[1101,470],[tipLeft,460]],{stroke:'#c7b67f',width:11});D.path([[1230,601],[1252,535],[1239,470],[tipRight,460]],{stroke:'#c7b67f',width:11});
    D.ctx.save();D.ctx.beginPath();D.ctx.rect(1090,255,160,350);D.ctx.clip();D.rect(zx-18,pinBottom-185,36,185,C.ink,4);D.line(zx-15,pinBottom-178,zx-15,pinBottom-8,C.mute,2);D.ctx.restore();
    D.dim(tipLeft,665,tipRight,665,'',q.clawOpen>.5?C.mute:C.blue);D.text(q.clawOpen>.5?'released':'gripping',zx,705,23,q.clawOpen>.5?C.mute:C.blue,'center');
    D.label('flexing claw tips',890,367,C.blue);D.line(1093,360,tipLeft-8,452,C.blue,2);D.label('socket stays in the PCB',902,739);
  }});

  window.AstraMechanics={sceneIds:Film.scenes.filter(s=>['a_direct','a_rails','a_bridge','a_front','a_seams','a_spdt','a_hotswap','a_focus','a_support','a_ruler','a_material','a_lattice','a_arches','a_fillets','a_pcb'].includes(s.id)).map(s=>s.id),switchSide,beamDelta,POST,GT01_GEOMETRY,model:{cos20:co,sin20:si,gtLowerWallMm:GT01_GEOMETRY.wall},sources:SOURCES};
})();
