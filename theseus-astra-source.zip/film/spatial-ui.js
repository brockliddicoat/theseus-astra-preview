(() => {
let handle=null,lastPoint=null,rotation={yaw:.6,pitch:.35},kind='gt01';
const $=s=>document.querySelector(s);
function dispose(){if(handle){AstraSpatial.dispose(handle);handle=null;}}
function draw(){if(!handle)return;AstraSpatial.render(handle,{...rotation,press:Number($('#partPress').value),explode:Number($('#partExplode').value)});}
function create(){dispose();const canvas=$('#spatialCanvas');kind=$('#partKind').value;try{handle=AstraSpatial.create(canvas,kind);$('#spatialError').hidden=true;draw();}catch(e){$('#spatialError').textContent='This browser could not start the 3D view: '+e.message;$('#spatialError').hidden=false;}}
function open(){if(!window.AstraSpatial)return;window.FilmAPI?.pause?.();$('#spatialDrawer').showModal();create();}
function close(){dispose();$('#spatialDrawer').close();}
$('#spatialBtn').onclick=open;$('#closeSpatial').onclick=close;$('#spatialDrawer').addEventListener('cancel',dispose);$('#partKind').onchange=()=>{rotation={yaw:.6,pitch:.35};$('#partPress').value=0;$('#partExplode').value=0;create();};$('#partPress').oninput=draw;$('#partExplode').oninput=draw;$('#partReset').onclick=()=>{rotation={yaw:.6,pitch:.35};$('#partPress').value=0;$('#partExplode').value=0;draw();};
const canvas=$('#spatialCanvas');canvas.onpointerdown=e=>{lastPoint={x:e.clientX,y:e.clientY};canvas.setPointerCapture(e.pointerId);};canvas.onpointermove=e=>{if(!lastPoint)return;rotation.yaw+=(e.clientX-lastPoint.x)*.01;rotation.pitch=Math.max(-1.3,Math.min(1.3,rotation.pitch+(e.clientY-lastPoint.y)*.01));lastPoint={x:e.clientX,y:e.clientY};draw();};canvas.onpointerup=()=>lastPoint=null;canvas.onpointercancel=()=>lastPoint=null;addEventListener('resize',()=>{if(handle)draw();});
window.AstraSpatialUI={open,close,draw,state(){return{kind,...rotation,press:Number($('#partPress').value),explode:Number($('#partExplode').value),ready:Boolean(handle),geometry:handle?.model?.getState?.()||null};}};
})();
