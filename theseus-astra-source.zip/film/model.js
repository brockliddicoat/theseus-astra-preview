const AstraSpec=FILM_SPEC;
function AstraBudget(spec=AstraSpec){
 const p=spec.parts,grams=x=>x.massG??((x.count??1)*(x.volumeEachMM3??x.volumeMM3)*x.densityGCM3/1000);
 const parts=Object.fromEntries(Object.entries(p).map(([k,v])=>[k,k==='wires'?v.lengthMM*v.massMGPerMM/1000:grams(v)]));
 const committed=Object.values(parts).reduce((a,b)=>a+b,0),shell=spec.massTargetG-committed;
 return{parts,committed,shell,total:committed+shell,target:spec.massTargetG,volumeCM3:spec.dimensionsMM.reduce((a,b)=>a*b,1)/1000};
}
