from pathlib import Path
import re,json,hashlib,datetime,argparse
ROOT=Path(__file__).resolve().parents[1]
FILM=ROOT/'film'
ap=argparse.ArgumentParser();ap.add_argument('--out',default=str(ROOT/'film'/'dist'));args=ap.parse_args()
out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
head=(ROOT/'deck/src/00-head.html').read_text(encoding='utf-8')
fonts='\n'.join(re.findall(r'@font-face\s*\{[^}]+\}',head))
parts=(ROOT/'deck/src/03-parts.js').read_text(encoding='utf-8')
half=json.loads(re.search(r'const SORA_HALF = (\[.*?\]);',parts).group(1))
sora=[[x,-z] for x,z in half]+[[-x,-z] for x,z in half[1:-1][::-1]]
geo=json.loads((FILM/'data/x2f.json').read_text(encoding='utf-8'))
data=json.loads((FILM/'data/verified.json').read_text(encoding='utf-8'))
ledger=json.loads((FILM/'ledger.json').read_text(encoding='utf-8')) if (FILM/'ledger.json').exists() else {'schemaVersion':1,'clauses':[],'ratings':[]}
spec=json.loads((FILM/'data/spec.json').read_text(encoding='utf-8'))
board=json.loads((FILM/'data/board-spec.json').read_text(encoding='utf-8'))
order=['a_cover','a_inertia','a_density','a_rank','a_weight','a_market','a_price','a_direct','a_rails','a_bridge','a_front','a_seams','a_spdt','a_hotswap','a_focus','a_support','a_ruler','a_material','a_lattice','a_arches','a_fillets','a_pcb','a_loadpaths','a_tolerance','a_surface','a_grip','a_wheel','a_power','a_software','a_timing','a_board','a_reflow','a_battery','a_wiring','a_shape','a_repair','a_close']
order.insert(order.index('a_direct'),'a_budget')
order.insert(order.index('a_surface'),'a_cure')
order.insert(order.index('a_surface')+1,'a_finish_tests')
order.insert(order.index('a_shape')+1,'a_balance')
order.insert(order.index('a_focus'),'a_binning')
files=[FILM/x for x in ['engine.js','model.js','intro.js','budget.js','mechanics.js','loadpaths.js','systems.js','spatial.bundle.js','player.js','spatial-ui.js'] if (FILM/x).exists()]
code='\n'.join(p.read_text(encoding='utf-8') for p in files)
template=(FILM/'index.html').read_text(encoding='utf-8')
inputs=[*files,FILM/'index.html',FILM/'build.py',FILM/'ledger.json',FILM/'data/verified.json',FILM/'data/x2f.json',FILM/'data/spec.json',FILM/'data/board-spec.json',ROOT/'deck/src/00-head.html',ROOT/'deck/src/03-parts.js']
hashes={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
if (FILM/'spatial.inputs.json').exists():
    spatial=json.loads((FILM/'spatial.inputs.json').read_text(encoding='utf-8'))
    for name,expected in spatial['inputs'].items():
        actual=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
        if actual!=expected: raise RuntimeError('Stale 3D bundle: rerun node film/tools/build_spatial.cjs after changing '+name)
        hashes[name]=actual
identity=hashlib.sha256(json.dumps({'inputs':hashes,'order':order},sort_keys=True).encode()).hexdigest()[:12]
meta={'id':'astra-'+identity,'baseline':'7d8f926ebb8fca1653b3d30509ef6f8f60ac093e','sourceFiles':hashes}
defs={'FILM_META':meta,'FILM_ORDER':order,'FILM_LEDGER':ledger,'FILM_DATA':data,'FILM_SPEC':spec,'FILM_BOARD':board,'FILM_GEOMETRY':{'sora':sora,'x2f':geo['views']['top']['normalized_d']}}
js='\n'.join('const '+k+'='+json.dumps(v,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')+';' for k,v in defs.items())
html=template.replace('/*FONTS*/',fonts).replace('/*DATA*/',js).replace('/*CODE*/',code)
(out/'index.html').write_text(html,encoding='utf-8',newline='\n')
meta['htmlSHA256']=hashlib.sha256((out/'index.html').read_bytes()).hexdigest()
(out/'version.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
(out/'.nojekyll').write_text('')
print(json.dumps({'build':meta['id'],'bytes':len(html.encode()),'sha256':meta['htmlSHA256'],'files':[p.name for p in files]}))
