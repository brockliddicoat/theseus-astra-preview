import * as THREE from 'three';
import {buildGT01} from '../3d/parts/gt01.js';
import {buildScrollWheel} from '../3d/parts/scrollwheel.js';
import {filletPolygon,roundedRectPath} from '../3d/parts/lib/geom.js';
import {buildReferenceShell} from './spatial-shell.js';

const mat=(color,metalness=0,roughness=.65)=>new THREE.MeshStandardMaterial({color,metalness,roughness});
function buildBoard(variant){
 const B=window.AstraBoardSpec;if(!B)throw Error('Board specification was not loaded.');
 const root=new THREE.Group(),components=[],switches=[];
 const shape=filletPolygon(B.outline.map(([x,z])=>[x,-z]),B.radius??1,false,12),[x0,z0,x1,z1]=B.bay,d=2.1,dy=d*B.chamferSlope;
 shape.holes.push(filletPolygon([[x0+d,-z1],[x1-d,-z1],[x1,-z1+dy],[x1,-z0-dy],[x1-d,-z0],[x0+d,-z0],[x0,-z0-dy],[x0,-z1+dy]],1,true,12));
 for(const [x,z] of B.holes){const hole=new THREE.Path();hole.absarc(x,-z,1.45,0,Math.PI*2,true);shape.holes.push(hole);}
 if(variant==='A'){const hole=roundedRectPath(3.83,4.29,1,10,-19.45);shape.holes.push(hole);}
 const geo=new THREE.ExtrudeGeometry(shape,{depth:1,steps:1,bevelEnabled:false,curveSegments:20});geo.rotateX(-Math.PI/2);const board=new THREE.Mesh(geo,[mat(0x20262f),mat(0x807858,.2)]);board.name='1 mm PCB';root.add(board);
 const box=(name,x,z,w,l,h,color=0x252b33,y=1)=>{const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,l),mat(color,name==='USB-C'?.65:0));mesh.position.set(x,y+h/2,z);mesh.name=name;root.add(mesh);components.push({mesh,y:mesh.position.y});return mesh;};
 const line=(points,color=0xb5a372)=>{const g=new THREE.BufferGeometry().setFromPoints(points.map(p=>new THREE.Vector3(...p)));root.add(new THREE.Line(g,new THREE.LineBasicMaterial({color})));};
 box('USB-C',0,B.usbZ,8.94,7.35,3.16,0xb5bdc7);box('USB-C opening',0,B.usbZ+3.69,6.9,.12,1.4,0x101214,1.65);
 for(const x of [-16,16]){const sw=buildGT01({cover:'clear'});sw.position.set(x,1,39.6);root.add(sw);switches.push(sw);components.push({mesh:sw,y:1});}
 box('Sensor',0,B.sensorZ,9,12.8,3.1,0x171b22);box('Sensor optical assembly',0,B.sensorZ,5.8,5.8,1.1,0x323a45,4.1);
 box('Raytac module',0,B.moduleZ,9.9,13.3,1.7,0x080a0d);box('MCU shield',0,B.moduleZ+2,7.8,7.8,.7,0x5c6471,2.7);
 const az=B.moduleZ-6.4;const antenna=[];for(let i=0;i<7;i++){antenna.push([-4.3+i*1.35,2.76,az]);antenna.push([-4.3+i*1.35,2.76,az+(i%2?1.6:0)]);}line(antenna);
 box('PMIC',...B.pmic,5,5,1.1);for(let i=0;i<4;i++)box('Power passives',-14.2+(i%2)*2.7,14.4+Math.floor(i/2)*3,1.7,1.1,.8,0xa6a9ad);
 box('Battery connector',...B.batteryConnector,6.8,5.7,3,0xbac0c7);box('Side connector',-14.5,8.5,5.7,6.8,3,0x9fa6ae);
 if(variant==='B'){box('Edge power switch',15.85,19.45,3.2,4.3,2.1,0x818c9b);box('Edge actuator',18,19.45,1.2,1.8,1.4,0xe3e5e8,1.4);}else{box('Window power switch',10,19.45,3.1,3.8,1.6,0x818c9b,1);box('Underside actuator',...B.variants.A.actuator.center,...B.variants.A.actuator.size,2,0xe3e5e8,-1.4);}
 for(const [x,z] of B.holes){const g=new THREE.RingGeometry(1.45,1.85,36);g.rotateX(-Math.PI/2);const ring=new THREE.Mesh(g,new THREE.MeshBasicMaterial({color:0xab9b72,side:THREE.DoubleSide}));ring.position.set(x,1.015,z);root.add(ring);}
 for(let k=0;k<14;k++){let x=-13+(k*5.3)%26,z=-1+(k*7.7)%26;line([[x,1.01,z],[x,1.01,z+3],[x+2,1.01,z+5]],0x58594e);}
 root.setPress=k=>{switches.forEach(s=>s.setPress(k));};root.setExplode=k=>{components.forEach((p,i)=>p.mesh.position.y=p.y+k*(6+(i%3)*3));};
 root.userData.spec={kind:'approved-plan-5',variant,thicknessMM:1,filletRadiusMM:1,usbZMM:B.usbZ,holes:B.holes,outline:B.outline,notchFlatMM:B.notchFlat,physicalFitValidated:false};return root;
}
function palette(root){root.traverse(o=>{if(!o.isMesh)return;o.castShadow=true;o.receiveShadow=true;for(const m of (Array.isArray(o.material)?o.material:[o.material])){if(!m?.color)continue;const hsl={};m.color.getHSL(hsl);if(hsl.s>.35&&hsl.h>.7&&hsl.h<.99)m.color.set(0x398cff);if(hsl.l<.12)m.color.set(0x394552);if(m.transmission>.1){m.transmission=0;m.transparent=true;m.opacity=.24;m.depthWrite=false;m.color.set(0x8bbcff);m.roughness=.35;}}});}
function create(canvas,kind){
 const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,preserveDrawingBuffer:true,powerPreference:'low-power'});renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.5));renderer.setClearColor(0x101214);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;renderer.localClippingEnabled=true;
 const scene=new THREE.Scene();scene.add(new THREE.HemisphereLight(0xeaf1ff,0x424a55,2.5));for(const [pos,power] of [[[1,2,3],3.5],[[-3,1,-1],2],[[1,1,-3],2]]){const light=new THREE.DirectionalLight(0xffffff,power);light.position.set(...pos);scene.add(light);}
 const model=kind==='shell'||kind==='finish'?buildReferenceShell({finish:kind==='finish'}):kind==='gt01'?buildGT01({cover:'clear'}):kind==='wheel'?buildScrollWheel():buildBoard(kind==='boardB'?'B':'A');palette(model);
 const frame=new THREE.Group();frame.add(model);scene.add(frame);const box=new THREE.Box3().setFromObject(model),center=box.getCenter(new THREE.Vector3()),size=box.getSize(new THREE.Vector3());frame.position.copy(center).multiplyScalar(-1);const camera=new THREE.OrthographicCamera(-1,1,1,-1,.01,10000);
 const handle={renderer,scene,camera,model,frame,kind,baseSize:size,center,disposed:false};render(handle,{yaw:.6,pitch:.35,press:0,explode:0});return handle;
}
function render(h,{yaw=.6,pitch=.35,press=0,explode=0}={}){if(h.disposed)return;h.model.setPress?.(press);h.model.setScroll?.(press*Math.PI*2);h.model.setExplode?.(explode);h.frame.updateMatrixWorld(true);h.model.traverse(o=>{if(typeof o.setCutaway==='function')o.setCutaway(0);});const canvas=h.renderer.domElement,w=Math.max(1,canvas.clientWidth||1000),hh=Math.max(1,canvas.clientHeight||550);h.renderer.setSize(w,hh,false);const box=new THREE.Box3().setFromObject(h.frame),size=box.getSize(new THREE.Vector3()),center=box.getCenter(new THREE.Vector3());let radius=Math.max(h.baseSize.length(),size.length())*.57,aspect=w/hh;const halfY=radius*Math.max(1,1/aspect),halfX=halfY*aspect;h.camera.left=-halfX;h.camera.right=halfX;h.camera.top=halfY;h.camera.bottom=-halfY;h.camera.position.set(center.x+radius*4*Math.cos(pitch)*Math.sin(yaw),center.y+radius*4*Math.sin(pitch),center.z+radius*4*Math.cos(pitch)*Math.cos(yaw));h.camera.lookAt(center);h.camera.updateProjectionMatrix();h.renderer.render(h.scene,h.camera);h.last={yaw,pitch,press,explode};}
function dispose(h){if(!h||h.disposed)return;h.disposed=true;h.model.dispose?.();h.scene.traverse(o=>{o.geometry?.dispose();for(const m of (Array.isArray(o.material)?o.material:[o.material]))m?.dispose?.();});h.renderer.dispose();}
window.AstraSpatial={create,render,dispose,version:'astra-spatial-1'};
