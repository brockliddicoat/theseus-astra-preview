"""Write a current review summary from the explicitly reviewed ledger and receipts."""
from collections import Counter
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[3]
HANDOFF = ROOT / 'astra/handoff/astra'
ledger = json.loads((ROOT / 'astra/film/ledger.json').read_text(encoding='utf-8'))
state = json.loads((ROOT / 'work/feedback-closeout/scene-state-audit.json').read_text(encoding='utf-8'))
imports = json.loads((ROOT / 'work/feedback-closeout/review-import-audit.json').read_text(encoding='utf-8'))
validation = json.loads((HANDOFF / 'ledger-validation.json').read_text(encoding='utf-8'))
counts = Counter(c['status'] for c in ledger['clauses'])

def safe(text):
    return str(text or '').replace('|', '/').replace('\n', ' ')

lines = [
    '# Independent Astra feedback closeout', '',
    f"All **283** corrected clauses have individual responses: **{counts['implemented']} implemented, {counts['partial']} partial, {counts['pending']} pending, {counts['deferred']} deferred and {counts['superseded']} superseded**. Implemented means that the specified presentation or code response exists with the listed evidence; it does not mean Brock accepted it, the final hardware passed a test, or a later build is identical.", '',
    'All 114 original rating records, 100 exact written notes, 269 written-note clauses, 14 no-note records and both extraction correction histories remain unchanged. All 263 current numbered instructions through F37 are indexed alongside the original 252-item audit. Each unresolved clause states its actual remaining reason. A scene mapping, rewritten sentence or historical DONE label never closes a record.', '',
    f"The latest source-state receipt covers {len(state['scenes'])} registered scenes and {len(state['assertions'])} named checks (all passed: {state['passed']}). The import-function receipt has {len(imports['assertions'])} checks (all passed: {imports['passed']}). Ledger integrity and negative guard checks passed **{validation['checksPassed']}** checks for SHA-256 `{validation['ledgerSha256']}`.", '',
    'Source snapshot hashes and each scene-specific assertion are attached to clause evidence. Actual tolerance drawing primitives verify pad/cap contact, a fixed PCB and pins crossing it. Front-stop, SPDT, linkage, arch-rim, equal-mass section and power/timing checks concern their named invariants; none is a general physical-product or pixel-correctness proof.', '',
    'Named image inspections are recorded in `work/feedback-closeout/render-review*.json`; newer images are frozen under their exact build ID. The compiler attaches an image only when its pixel hash and relevant scene, engine, model and shared-data hashes match. It refuses overwritten historical paths. The 42-scene browser receipts sampled 126 frames without reported browser errors or offstage text. Eight selected mechanical frames from `astra-51297997a0b6`, eight current systems frames from `astra-4cdb287225a8` and six real 3D captures were directly inspected and frozen here. Later narrow source fixes remain distinct. The earlier unsupported header/caption crop allegations were retracted and are not findings.', '',
    'The frozen `work/feedback-closeout/review-ui-proof.json` records 28 actual browser workflow checks at `astra-4cdb287225a8`, including touch navigation, phone diagram zoom, Escape save/history, rating-clear history, a real downloaded export and file-chooser import, reload persistence, a simulated update manifest, six real software-WebGL part controls and the storage-error recovery path. Final GT01/label parity, independent side-button press and common-spec actuator fixes require the final build-specific regression receipt. `spatial-review.json` distinguishes real geometry and appearance from unimplemented shell stress-field calculation.', '',
    'The initial distinct public preview was served-checked at `astra-e5d88aa6d325` in `work/qa-live-first/report.json`. That receipt is historical 17-scene evidence. Root owns final expanded-build publication and served verification. This ledger worker did not publish, contact Claude, read `refs/scan`, copy Sol implementation or edit the primary worktree.', '',
    'Actual local session records verify the lead at `gpt-6-astra / ultra` and the three direct workers at `gpt-6-astra / max`; `model-evidence.json` records their identities and all observed model/effort profiles.', '',
    '## F33.5 priority concepts', '',
    'These 19 concepts are preserved. The table reports their individual clause dispositions; a mapping alone is not completion.', '',
    '| Original concept | Current scenes | Clause status | Actual remaining work |',
    '| --- | --- | --- | --- |',
]
priority = ['cutouts', 'clk_front', 'clk_wedge', 'arc', 'anchors', 'sidebuttons', 'thinwall', 'shlSpecific', 'shlNoPick', 'shlMargin', 'shlThin', 'shlWork', 'shcArms', 'tolerance', 'shlsheet1', 'ntr_density', 'zerograms', 'market', 'grip']
for old in priority:
    records = [c for c in ledger['clauses'] if c['oldSlide'] == old]
    scenes = sorted({s for c in records for s in c['scenes']})
    status = Counter(c['status'] for c in records)
    remaining = list(dict.fromkeys(c['pendingReason'] for c in records if c.get('pendingReason')))
    lines.append('| `' + old + '` | ' + ', '.join('`'+s+'`' for s in scenes) + ' | ' + ', '.join(f'{n} {k}' for k,n in status.items()) + ' | ' + safe(' '.join(remaining) if remaining else 'The requested explanation is implemented within its stated teaching/source/target scope; user acceptance remains separate.') + ' |')
lines += ['', '## Standing requirements', '',
          'Each of the 24 standing records now has a concrete response, source/evidence identity and any remaining reason. Original requirement text is preserved and protected from response overrides.', '',
          '| Rule | Status | Evidence-backed response and remaining scope |', '| --- | --- | --- |']
for item in ledger['standing']:
    lines.append(f"| `{item['id']}` | {item['status']} | {safe(item['response'])}" + (f" Remaining: {safe(item['pendingReason'])}" if item.get('pendingReason') else '') + ' |')
lines += ['', '## Remaining clauses', '',
          'This is the current actionable list, distinct from the intact raw notes. A finished explained model can close a presentation requirement even while real final measurements remain unavailable. In particular, the raw front-gap and skate-placement notes permit honestly labelled schematic comparisons; they do not automatically require a new retail measurement campaign.', '',
          '| Clause | Status | Scenes | Remaining reason |', '| --- | --- | --- | --- |']
for item in ledger['clauses']:
    if item['status'] not in {'implemented', 'superseded'}:
        lines.append(f"| `{item['id']}` | {item['status']} | " + ', '.join('`'+s+'`' for s in item['scenes']) + ' | ' + safe(item['pendingReason']) + ' |')
lines += ['', '## Reproduction', '',
          'After intentionally reviewing changed source, run the state audit, compile the explicit clause and standing responses, regenerate the ledger, verify preservation and write this report. An audit failure stops evidence compilation. The film must be rebuilt after ledger changes because the ledger is a build input.', '',
          '```powershell',
          'node astra/film/tools/audit_scene_states.cjs',
          'node astra/film/tools/audit_review_import.cjs',
          'python -X utf8 astra/film/tools/compile_standing.py',
          'python -X utf8 astra/film/tools/compile_closeout.py',
          'python -X utf8 astra/film/tools/build_ledger.py',
          'python -X utf8 astra/film/tools/verify_ledger.py',
          'python -X utf8 astra/film/tools/write_closeout_report.py',
          '```', '',
          'Do not rerun a visual-inspection receipt merely because a capture directory changed. View the new images and record their actual build identity first. Reopen is global and remains open through navigation, reload, import and later revisions; a partial or deferred item must never be displayed as closed.', '']
(HANDOFF / 'closeout-review.md').write_text('\n'.join(lines), encoding='utf-8')
resource_ids = {'F27.wheel.1', 'F27.wheel.2', 'F27.clk_pomtune.3', 'F27.flagships.1', 'F27.arc.1', 'F27.shcArms.1', 'F27.shcArms.3'}
approval_ids = {'F27.sidebuttons.3', 'F27.srf_gripmap.1'}
open_items = [c for c in ledger['clauses'] if c['status'] not in {'implemented', 'superseded'}]
queue = [
    '# Current implementation and evidence queue', '',
    'This file is generated from the current explicitly reviewed ledger. It replaces the initial gap list: items already implemented are omitted. The complete per-clause review and standing-rule table are in `closeout-review.md`.', '',
    f"Current clauses: {counts['implemented']} implemented, {counts['partial']} partial, {counts['pending']} pending, {counts['deferred']} deferred, {counts['superseded']} superseded. Each open record below states the concrete remaining work; a missing finished product is not automatically a blocker for an explained model.", '',
]
groups = [
    ('Source, geometry or verification work', [c for c in open_items if c['id'] not in resource_ids|approval_ids and c['status'] != 'deferred']),
    ('Unavailable source or direct comparison evidence', [c for c in open_items if c['id'] in resource_ids]),
    ('Explicit design approval or deferral', [c for c in open_items if c['id'] in approval_ids or c['status'] == 'deferred']),
]
for name, items in groups:
    queue += ['## ' + name, '', '| Clause | Scenes | Remaining work |', '| --- | --- | --- |']
    for c in items:
        queue.append('| `' + c['id'] + '` | ' + ', '.join('`'+s+'`' for s in c['scenes']) + ' | ' + safe(c['pendingReason']) + ' |')
    queue += ['']
queue += ['The schematic front-gap comparison and same-material skate-area model are implemented and therefore absent from this queue. The specifically requested weighed wheel test group and direct named-rival tolerance comparison remain source boundaries. The old fitted price frontier is explicitly superseded by a direct scatter, rather than falsely marked as a repaired curve. A completed teaching model still does not validate whole-mouse strength, runtime, latency, wear, ergonomic performance or manufactured fit.', '']
(HANDOFF / 'implementation-gaps.md').write_text('\n'.join(queue), encoding='utf-8')
print(json.dumps({'written': 'astra/handoff/astra/closeout-review.md', 'clauses': len(ledger['clauses']), 'standing': len(ledger['standing'])}))
