"""Regenerate and audit the editable plan-5 board, without rendering or browser access.

python astra/film/tools/board_geometry.py --write
python astra/film/tools/board_geometry.py

Only nominal parameters are edited by hand. --write updates outline, bayOutline and
derived measurements. Normal execution fails if those generated fields are stale.
This checks a placement plan, not electrical routing or a finished assembly.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[1]
SPEC = ROOT / 'data' / 'board-spec.json'

def near(a, b, tol=1e-8):
    return abs(a-b) <= tol

def fillets(poly, radius):
    out = []
    for i, p in enumerate(poly):
        a, b = poly[(i-1) % len(poly)], poly[(i+1) % len(poly)]
        u, v = [a[j]-p[j] for j in range(2)], [b[j]-p[j] for j in range(2)]
        lu, lv = math.hypot(*u), math.hypot(*v)
        u, v = [x/lu for x in u], [x/lv for x in v]
        theta = math.acos(max(-1, min(1, sum(x*y for x,y in zip(u,v)))))
        if near(theta, math.pi):
            out.append({'vertex':p, 'start':p, 'end':p, 'tangentTrim':0, 'radius':None})
            continue
        trim = min(radius / math.tan(theta/2), .45*lu, .45*lv)
        actual_radius = trim * math.tan(theta/2)
        start, end = [[p[j]+uv[j]*trim for j in range(2)] for uv in [u,v]]
        bisector = [u[j]+v[j] for j in range(2)]
        bn = math.hypot(*bisector)
        center = [p[j]+bisector[j]/bn*actual_radius/math.sin(theta/2) for j in range(2)]
        out.append({'vertex':p, 'start':start, 'end':end, 'center':center, 'tangentTrim':trim, 'radius':actual_radius})
    return out

def derive(b):
    b = copy.deepcopy(b)
    w, wx, dep, ta = b['halfWidth'], b['waist'], b['notchDepth'], b['chamferSlope']
    zn, zb, zf, zt = b['notchZ'], b['rear'], b['wingFront'], b['front']
    zlo, zhi = b['sideNotchZ']
    xn, xt = b['notchFlat']/2, b['noseTabHalf']
    right = [[xt,zt],[xt+dep/ta,zf],[w,zf],[w,zhi+dep*ta],[wx,zhi],[wx,zlo],[w,zlo-dep*ta],[w,zb],[xn+dep/ta,zb],[xn,zn]]
    b['outline'] = [[0,zt]]+right+[[0,zn]]+[[-x,z] for x,z in reversed(right)]
    x0,z0,x1,z1 = b['bay']
    d, dz = b['bayChamferHorizontal'], b['bayChamferHorizontal']*ta
    b['bayOutline'] = [[x0+d,z1],[x1-d,z1],[x1,z1-dz],[x1,z0+dz],[x1-d,z0],[x0+d,z0],[x0,z0+dz],[x0,z1-dz]]
    f = fillets(b['outline'], b['radius'])
    at = lambda x,z: next(k for k in f if near(k['vertex'][0],x) and near(k['vertex'][1],z))
    side = math.dist(at(wx,zhi)['end'], at(wx,zlo)['start'])
    rear = math.dist(at(xn,zn)['end'], at(-xn,zn)['start'])
    m = b['components']['module']['placementEnvelope']
    sh = b['components']['sensor']['placementSize'][1]/2
    b['derived'] = {
      'outerBounds':[-w,zb,w,zt], 'sideNominalFlatLength':zhi-zlo, 'rearNominalFlatLength':b['notchFlat'],
      'sideStraightLength':side, 'rearStraightLength':rear,
      'rearMinusSideStraight':rear-side,
      'rearNominalForEqualFinishedStraight':b['notchFlat']-(rear-side),
      'straightLengthNote':'Finished side and rear straight segments are equal. The rear nominal span is shortened to compensate for its different 1 mm fillet tangent trims.',
      'centerlineGaps':[m['z0']-zn, b['sensorZ']-sh-m['z1'], z0-(b['sensorZ']+sh)],
      'usbFrontLegClearance':zt-(b['usbZ']+.78+.85),
      'usbBodyOverhang':b['usbZ']+7.35/2-zt,
      'outlineFillets':f, 'bayFillets':fillets(b['bayOutline'],b['radius'])
    }
    return b

def audit(b):
    checks = []
    def ck(name, ok):
        checks.append({'name':name,'passed':bool(ok)})
        if not ok: raise AssertionError(name)
    d = b['derived']
    ck('fixed plan-5 mounting coordinates preserved', b['holes']==[[-10.1,29.5],[10.1,29.5],[-14.59,-2.25],[14.59,-2.25]])
    ck('outline, bay and mounts mirror about x=0', all(any(near(-x,xx) and near(z,zz) for xx,zz in poly) for poly in [b['outline'],b['bayOutline'],b['holes']] for x,z in poly))
    ck('approved 1 mm thickness and true 1 mm fillet radius', near(b['thickness'],1) and near(b['radius'],1) and all(near(f['radius'],1) for f in d['outlineFillets']+d['bayFillets'] if f['radius'] is not None))
    ck('all fillet arcs have the stated radius and meet edges at right angles', all(near(math.dist(f['center'],f['start']),1) and near(math.dist(f['center'],f['end']),1) and all(near(sum((f['center'][j]-f[end][j])*(f['vertex'][j]-f[end][j]) for j in range(2)),0) for end in ['start','end']) for f in d['outlineFillets']+d['bayFillets'] if f['radius'] is not None))
    ck('fillets do not consume any adjoining full edge', all(math.dist(poly[i]['end'],poly[(i+1)%len(poly)]['start'])>1e-5 for poly in [d['outlineFillets'],d['bayFillets']] for i in range(len(poly))))
    ck('three independent centerline clearances equal 1.60 mm', all(near(g,1.6) for g in d['centerlineGaps']))
    ck('USB front legs stay 0.44 mm inside front edge', near(d['usbFrontLegClearance'],.44))
    ck('USB body retains 1.605 mm overhang', near(d['usbBodyOverhang'],1.605))
    ck('bay centered and front shortened to z44.13', near(b['bay'][0]+b['bay'][2],0) and near(b['bay'][3],44.13))
    ck('all nominal notch depths equal 3.61 mm', near(b['halfWidth']-b['waist'],3.61) and near(b['front']-b['wingFront'],3.61) and near(b['notchZ']-b['rear'],3.61))
    ck('side nominal 13.09 mm preserved; rear nominal corrected for its fillet angles', near(b['sideNotchZ'][1]-b['sideNotchZ'][0],13.09) and near(b['notchFlat'],12.689534528287762))
    ck('finished side and rear straight lengths are equal to 12.054261463 mm', near(d['sideStraightLength'],12.054261462966881) and near(d['rearStraightLength'],d['sideStraightLength']) and near(d['rearMinusSideStraight'],0))
    ck('same approved chamfer slope on every diagonal', all(near(abs((p2[1]-p1[1])/(p2[0]-p1[0])),.70656) for poly in [b['outline'],b['bayOutline']] for p1,p2 in zip(poly,poly[1:]+poly[:1]) if abs(p2[0]-p1[0])>1e-8 and abs(p2[1]-p1[1])>1e-8))
    ck('no removed locator holes or extra rear cutouts', b['removedHoles']==['LH1','LH2','SH1','SH2'] and b['rearCutouts']==[] and len(b['holes'])==4)
    ck('A and B preserve a real switch-access distinction', b['variants']['A']['window'] is not None and b['variants']['B']['window'] is None)
    ck('published module body separated from planning envelope', b['components']['module']['bodySize']==[9.9,13.3] and near(b['components']['module']['placementEnvelope']['z1']-b['components']['module']['placementEnvelope']['z0'],13.85))
    return checks

if __name__ == '__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--write',action='store_true'); args=ap.parse_args()
    original=json.loads(SPEC.read_text(encoding='utf-8')); expected=derive(original)
    if args.write: SPEC.write_text(json.dumps(expected,indent=2)+'\n',encoding='utf-8')
    elif original != expected: raise SystemExit('Generated board fields stale: run board_geometry.py --write')
    checks=audit(expected)
    report={'schemaVersion':1,'specSHA256':hashlib.sha256(SPEC.read_bytes()).hexdigest(),'checks':checks,'count':len(checks),'sideStraightLength_mm':expected['derived']['sideStraightLength'],'rearStraightLength_mm':expected['derived']['rearStraightLength'],'scope':'Geometry consistency only. No routing, electrical, assembly or manufactured validation.'}
    reportPath=ROOT.parent/'handoff'/'astra'/'board-geometry-checks.json'
    reportPath.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))
