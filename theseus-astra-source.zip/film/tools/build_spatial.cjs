const path=require('path'),fs=require('fs'),crypto=require('crypto');
const roots=[process.env.ASTRA_NODE_MODULES,path.resolve(__dirname,'../../3d/node_modules'),path.resolve(__dirname,'../node_modules')].filter(Boolean);
const esbuild=require(require.resolve('esbuild',{paths:roots}));
const result=esbuild.buildSync({entryPoints:[path.resolve(__dirname,'../spatial-entry.js')],outfile:path.resolve(__dirname,'../spatial.bundle.js'),bundle:true,format:'iife',platform:'browser',target:'es2020',nodePaths:roots,minify:true,legalComments:'eof',metafile:true});
const root=path.resolve(__dirname,'../..'),hashes={};for(const input of Object.keys(result.metafile.inputs)){const p=path.resolve(input),rel=path.relative(root,p);if(!rel.startsWith('..')&&!path.isAbsolute(rel))hashes[rel.replaceAll('\\','/')]=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');}
fs.writeFileSync(path.resolve(__dirname,'../spatial.inputs.json'),JSON.stringify({esbuild:esbuild.version,inputs:hashes},null,2));
console.log('Bundled procedural parts inspector.');
