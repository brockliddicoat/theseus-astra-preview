"""Independent preservation checks plus negative checks of ledger closure guards."""
from __future__ import annotations

from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CONTEXT = ROOT / "handoff/astra/context"
WORK = ROOT.parent / "work/feedback-ledger-check"
checks = []


def require(ok, label):
    if not ok:
        raise AssertionError(label)
    checks.append(label)


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


ledger_path = ROOT / "film/ledger.json"
ledger = read(ledger_path)
audit = read(CONTEXT / "handoff/codex/feedback-audit.json")
lines = (CONTEXT / "FEEDBACK.md").read_text(encoding="utf-8-sig").splitlines()
require(ledger["ratings"] == audit["ratings"], "All original rating fields preserved exactly")
require(ledger["sourceFeedbackItems"] == audit["feedbackItems"], "All 252 original numbered item records preserved exactly")
require(len(ledger["ratings"]) == 114, "114 original ratings")
require(sum(r["note"] is not None for r in ledger["ratings"]) == 100, "100 original written notes")
expected = {c["id"]: (r, c) for r in audit["ratings"] for c in r["clauses"]}
actual = {c["id"]: c for c in ledger["clauses"]}
require(len(ledger["clauses"]) == len(actual) == 283, "283 unique normalized clauses")
require(set(expected) == set(actual), "Exact corrected clause ID set preserved")
require(sum(c["hasWrittenNote"] for c in actual.values()) == 269, "269 written-note clauses and 14 no-note records")
line_deltas = Counter()
for ident, (rating, source_clause) in expected.items():
    current = actual[ident]
    require(current["originalNote"] == rating["note"], f"{ident}: exact note")
    require(current["clause"] == source_clause["text"] and current["sourceClause"] == source_clause, f"{ident}: exact source clause")
    raw_line = lines[current["sourceLine"] - 1]
    require(f"`{rating['legacyId']}`" in raw_line and f"**{rating['score']}/10**" in raw_line, f"{ident}: resolved source identity")
    if rating["note"] is not None:
        require(raw_line.endswith(': "' + rating["note"] + '"'), f"{ident}: raw written note byte-content")
    else:
        require(raw_line.rstrip().endswith(f"**{rating['score']}/10**"), f"{ident}: no invented note")
    require(current["importedSource"] == rating["source"], f"{ident}: imported pointer retained")
    line_deltas[current["sourceLine"] - int(rating["source"].split(":")[-1])] += 1
    if current["status"] in {"pending", "partial", "deferred"}:
        require(bool(current["pendingReason"]), f"{ident}: explicit remaining reason")
    if current["status"] == "implemented":
        require(bool(current["evidence"]), f"{ident}: evidence attached")
require(len(actual["F27.sealed.1"]["originalNote"]) > 100, "Sealed's real note retained")
require(len(next(r for r in ledger["ratings"] if r["legacyId"] == "sealed")["clauses"]) == 4, "Four repaired sealed clauses retained")
require("Remove" in actual["F27.shlGrams.1"]["clause"], "ShlGrams removal correction retained")
require(sum(bool(r.get("auditCorrections")) for r in ledger["ratings"]) == 2, "Both extraction histories retained")
require({"F34.3", "F35.1", "F36.1", "F37.1"}.issubset({x["id"] for x in ledger["currentFeedbackItems"]}), "Latest F34-F37 items indexed")
require(ledger["reviewPolicy"]["mappingIsCompletion"] is False, "Mapping cannot imply completion")
require(ledger["reviewPolicy"]["automaticArchiveOnTextOrMetadataChange"] is False, "Text/metadata cannot autoarchive")
require(ledger["reviewPolicy"]["userReopenOverridesImplementationStatus"] is True, "User reopen overrides implementation")
require(ledger["reviewPolicy"]["storage"] == "browser-local" and ledger["reviewPolicy"]["sync"] == "none", "Storage boundary is honest")

# Exercise real guards with a temporary responses input, never rewriting the real ledger.
spec = importlib.util.spec_from_file_location("astra_ledger_builder", ROOT / "film/tools/build_ledger.py")
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
require(builder.encode(builder.build()) == ledger_path.read_bytes(), "Regeneration is deterministic")
rules = {ident: (ids, rule) for ident, ids, rule in builder.RULES}
require(len(ledger['standing']) == len(rules) == 24, 'All 24 standing requirements retained')
for item in ledger['standing']:
    require((item['feedbackIds'], item['requirement']) == rules[item['id']], item['id'] + ': authoritative standing text preserved')
    require(bool(item['response']) and item['response'] != 'Standing rule; verify against each applicable scene and the final player.', item['id'] + ': specific standing response')
    require(bool(item['evidence']), item['id'] + ': standing evidence attached')
    if item['status'] in {'pending', 'partial', 'deferred'}:
        require(bool(item['pendingReason']), item['id'] + ': explicit standing remaining reason')
WORK.mkdir(parents=True, exist_ok=True)
probe = WORK / "test-responses.json"
builder.RESPONSES = probe
probe.write_text(json.dumps({"schemaVersion": 1, "clauses": {"F27.cover.1": {"scenes": ["test_scene"]}}}), encoding="utf-8")
mapped = next(c for c in builder.build()["clauses"] if c["id"] == "F27.cover.1")
require(mapped["status"] == "pending" and mapped["scenes"] == ["test_scene"], "Adding only a scene link leaves status pending")
for label, payload in [
    ("Implemented without evidence is rejected", {"F27.cover.1": {"status": "implemented"}}),
    ("Unknown feedback IDs are rejected", {"F27.unknown.1": {"response": "mistaken key"}}),
    ("Raw note overwrite is rejected", {"F27.cover.1": {"originalNote": "rewritten"}}),
]:
    probe.write_text(json.dumps({"schemaVersion": 1, "clauses": payload}), encoding="utf-8")
    try:
        builder.build()
    except AssertionError:
        require(True, label)
    else:
        require(False, label)

builder.RESPONSES = ROOT / 'handoff/astra/ledger-responses.json'
builder.STANDING_RESPONSES = probe
probe.write_text(json.dumps({'schemaVersion': 1, 'standing': {'motion': {'scenes': ['test_scene']}}}), encoding='utf-8')
mapped = next(c for c in builder.build()['standing'] if c['id'] == 'motion')
require(mapped['status'] == 'pending', 'Mapping only cannot close a standing rule')
for label, payload in [
    ('Standing implemented without evidence is rejected', {'motion': {'status': 'implemented'}}),
    ('Unknown standing IDs are rejected', {'made-up-rule': {'response': 'wrong identifier'}}),
    ('Standing requirement overwrite is rejected', {'motion': {'requirement': 'rewritten'}}),
]:
    probe.write_text(json.dumps({'schemaVersion': 1, 'standing': payload}), encoding='utf-8')
    try:
        builder.build()
    except AssertionError:
        require(True, label)
    else:
        require(False, label)

report = {
    "schemaVersion": 1, "result": "pass", "scope": "Source and ledger integrity only; no scene rendering, browser interactions or product-performance acceptance.",
    "checksPassed": len(checks), "ledgerSha256": hashlib.sha256(ledger_path.read_bytes()).hexdigest(),
    "ratings": len(ledger["ratings"]), "clauses": len(actual),
    "currentNumberedFeedbackItems": len(ledger["currentFeedbackItems"]),
    "originalNumberedFeedbackItems": len(ledger["sourceFeedbackItems"]),
    "statusCounts": dict(Counter(c["status"] for c in actual.values())),
    "standingStatusCounts": dict(Counter(c['status'] for c in ledger['standing'])),
    "sourceLineOffsetDistribution": dict(line_deltas),
    "guardChecks": checks[-8:],
}
path = ROOT / "handoff/astra/ledger-validation.json"
path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
