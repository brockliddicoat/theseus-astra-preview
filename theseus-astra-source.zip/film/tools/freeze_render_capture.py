"""Freeze a named capture before visual review; record review only after viewing.

--reviewed is an explicit reviewer attestation, not a screenshot test. Never use
it until every listed frozen image has actually been inspected at full size.
"""
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--capture', required=True)
parser.add_argument('--build', required=True)
parser.add_argument('--images', nargs='+', required=True)
parser.add_argument('--reviewed', action='store_true')
args = parser.parse_args()
capture = ROOT / args.capture
target = ROOT / 'work/feedback-closeout/render-snapshots' / args.build
target.mkdir(parents=True, exist_ok=True)

if not args.reviewed:
    report_raw = (capture / 'report.json').read_bytes()
    report = json.loads(report_raw)
    assert report['build']['id'] == args.build
    for filename in args.images:
        assert Path(filename).name == filename and filename.endswith('.png')
        source = capture / filename
        raw = source.read_bytes()
        output = target / filename
        if output.exists():
            assert output.read_bytes() == raw, f'Immutable capture differs: {output}'
        else:
            output.write_bytes(raw)
        assert source.read_bytes() == raw, f'Capture changed while freezing: {source}'
    assert (capture / 'report.json').read_bytes() == report_raw, 'Capture report changed while freezing'
    output = target / 'report.json'
    if output.exists():
        assert output.read_bytes() == report_raw
    else:
        output.write_bytes(report_raw)
    print(json.dumps({'frozen': len(args.images), 'build': args.build, 'reviewed': False, 'directory': str(target)}))
else:
    report = json.loads((target / 'report.json').read_text(encoding='utf-8'))
    assert report['build']['id'] == args.build
    records = []
    for filename in args.images:
        path = target / filename
        stem = path.stem
        scene = stem.split('-')[0]
        records.append({'scene': scene, 'frame': stem[len(scene)+1:],
                        'artifact': path.relative_to(ROOT).as_posix(),
                        'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                        'method': 'Directly viewed at full image size by feedback_integrity.'})
    receipt_path = ROOT / 'work/feedback-closeout' / f'render-review-{args.build}.json'
    if receipt_path.exists():
        previous = json.loads(receipt_path.read_text(encoding='utf-8'))['reviewed']
        records = list({r['artifact']: r for r in previous+records}.values())
    receipt_path.write_text(json.dumps({'schemaVersion': 1, 'build': report['build'],
        'captureReport': (target / 'report.json').relative_to(ROOT).as_posix(),
        'reviewed': records,
        'scope': 'Only the named directly inspected frozen frames. Source state, UI regressions, physical performance and acceptance are separate evidence.'}, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'reviewed': len(records), 'build': args.build, 'receipt': str(receipt_path)}))
