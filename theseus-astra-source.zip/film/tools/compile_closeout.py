"""Compile individually reviewed responses, retaining an exact evidence snapshot identity.

Run audit_scene_states.cjs first after intentionally reviewing source changes, then this
script, build_ledger.py, and verify_ledger.py. This never edits scene or player code.
"""
from __future__ import annotations
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re

REPO = Path(__file__).resolve().parents[2]
WORKSPACE = REPO.parent
HANDOFF = REPO / 'handoff/astra'
WORK = WORKSPACE / 'work/feedback-closeout'
source_audit = json.loads((WORK / 'scene-state-audit.json').read_text(encoding='utf-8'))
assert source_audit['passed'], 'Resolve actual source-state audit failures before refreshing ledger evidence'
audit = json.loads((HANDOFF / 'context/handoff/codex/feedback-audit.json').read_text(encoding='utf-8-sig'))
expected = {c['id'] for r in audit['ratings'] for c in r['clauses']}
scene_records = {s['id']: s for s in source_audit['scenes']}
source_locations = {}
for name in [Path(p).name for p in source_audit['sourceFiles'] if p.endswith('.js')]:
    source_path = WORK / 'source' / name
    raw = source_path.read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    assert source_audit['sourceFiles']['astra/film/' + name] == sha
    for line, text in enumerate(raw.decode('utf-8').splitlines(), 1):
        for ident in re.findall(r"Film\.add\(\{id:'([^']+)'", text):
            source_locations[ident] = (name, line, sha)
assert set(source_locations) == set(scene_records)

render_records = []
unavailable_render_records = []
for receipt_path in sorted(WORK.glob('render-review*.json')):
    receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
    for item in receipt['reviewed']:
        artifact = WORKSPACE / item['artifact']
        if not artifact.exists() or hashlib.sha256(artifact.read_bytes()).hexdigest() != item['sha256']:
            unavailable_render_records.append({'artifact': item['artifact'], 'expectedSha256': item['sha256'], 'captureBuild': receipt['build']['id'], 'reason': 'Mutable capture path was replaced or removed. No current clause evidence is attached from this historical receipt.'})
            continue
        render_records.append((receipt, item))

def captured_hash(receipt, relative):
    return next((sha for name, sha in receipt['build']['sourceFiles'].items()
                 if name.replace('\\', '/') == relative), None)

status_names = {'I': 'implemented', 'P': 'partial', 'N': 'pending', 'D': 'deferred', 'S': 'superseded'}
responses = {}
for line in (HANDOFF / 'ledger-closeout.tsv').read_text(encoding='utf-8').splitlines():
    if not line or line.startswith('#'):
        continue
    parts = line.split('|')
    assert len(parts) == 5, parts
    suffix, short, scene_list, response, remaining = parts
    ident = 'F27.' + suffix
    assert ident not in responses and ident in expected, ident
    status = status_names[short]
    scenes = scene_list.split(',') if scene_list else []
    assert len(scenes) == len(set(scenes)) and all(s in scene_records for s in scenes), ident
    assert len(response) >= 20 and (status not in {'pending', 'partial', 'deferred'} or remaining.strip()), ident
    evidence = []
    for scene in scenes:
        name, number, sha = source_locations[scene]
        evidence.append({
            'kind': 'source-inspection', 'scene': scene,
            'artifact': f'work/feedback-closeout/source/{name}:{number}',
            'currentSource': f'astra/film/{name}:{number}', 'sourceSha256': sha,
            'result': f"Inspected {scene_records[scene]['title']} in the frozen source; see the specific response and remaining reason. This is implementation evidence, not user acceptance or a product test.",
        })
        matching = [a for a in source_audit['assertions'] if a['id'] == scene]
        if matching:
            evidence.append({
                'kind': 'source-state-assertion', 'scene': scene,
                'artifact': 'work/feedback-closeout/scene-state-audit.json',
                'result': '; '.join(a['name'] + (': PASS' if a['passed'] else ': FAIL') for a in matching),
                'scope': 'Only the named numerical/state invariants; no inference of pixel correctness or physical performance.',
            })
        for receipt, image in render_records:
            if image['scene'] != scene or captured_hash(receipt, 'film/' + name) != sha:
                continue
            if captured_hash(receipt, 'film/engine.js') != source_audit['sourceFiles'].get('astra/film/engine.js'):
                continue
            dependencies = ['model.js', 'data/verified.json', 'data/spec.json', 'data/x2f.json']
            if scene == 'a_board':
                dependencies.append('data/board-spec.json')
            if any(captured_hash(receipt, 'film/' + dep) != source_audit['sourceFiles'].get('astra/film/' + dep) for dep in dependencies):
                continue
            frame = image.get('frame', Path(image['artifact']).stem.split('-', 1)[-1])
            evidence.append({
                'kind': 'rendered-frame-inspection', 'scene': scene, 'frame': frame,
                'artifact': image['artifact'], 'sha256': image['sha256'],
                'captureBuild': receipt['build']['id'], 'captureReport': receipt['captureReport'],
                'result': f"Directly inspected the named {frame} frame. The scene module, engine and named shared model/data inputs match the reviewed source hashes; see the clause response for remaining issues.",
                'scope': 'This specific capture only, not current complete-build acceptance or a physical test. A single frame does not establish a complete event sequence.',
            })
        if scene in {'a_board', 'a_cure', 'a_finish_tests'}:
            receipt = HANDOFF / 'systems-source-receipts.json'
            evidence.append({
                'kind': 'bounded-primary-source-receipt', 'scene': scene,
                'artifact': receipt.relative_to(WORKSPACE).as_posix(),
                'sha256': hashlib.sha256(receipt.read_bytes()).hexdigest(),
                'result': 'Reviewed manufacturer document identities, page scope and limitations: HumiSeal liquid density is not cured-film density; F-Series cure is 82 °C for one hour at part temperature; UV/chemical coupons are not Theseus or sweat validation.',
                'scope': 'Only the specifically attributed retrieved manufacturer evidence, not a physical product result.',
            })
    responses[ident] = {'status': status, 'response': response,
                        'scenes': scenes, 'evidence': evidence,
                        'pendingReason': remaining or None}
    if ident in {'F27.clicks.1', 'F27.clicks.2', 'F27.clk_switch.1', 'F27.shlShell3d.1', 'F27.surfacecard.1', 'F27.srf_twotone.2'}:
        artifact = WORK / 'spatial-review.json'
        evidence.append({
            'kind': 'spatial-source-and-appearance-review',
            'artifact': artifact.relative_to(WORKSPACE).as_posix(),
            'sha256': hashlib.sha256(artifact.read_bytes()).hexdigest(),
            'result': 'Directly inspected six real WebGL part captures, the named 3D source files and supplied GT01 reference photos. The receipt identifies exact artifacts and the later control-fix boundary.',
            'scope': 'Appearance and implemented code geometry only; no computed shell stress, physical fit, product performance or final color/pattern acceptance.',
        })
assert set(responses) == expected and len(responses) == 283

def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')

write_json(HANDOFF / 'ledger-responses.json', {
    'schemaVersion': 1,
    'reviewScope': 'All 283 original clauses individually reviewed against the named source snapshot. Implemented is a scoped engineering response, not acceptance. Current source may have later changes; compare hashes.',
    'sourceAudit': 'work/feedback-closeout/scene-state-audit.json',
    'sourceFiles': source_audit['sourceFiles'],
    'clauses': responses,
})
by_scene = defaultdict(list)
for ident, item in responses.items():
    for scene in item['scenes']:
        by_scene[scene].append({'id': ident, **{k: item[k] for k in ('status', 'response', 'pendingReason')}})
summary = {
    'schemaVersion': 1, 'clauses': len(responses),
    'statusCounts': dict(Counter(x['status'] for x in responses.values())),
    'sourceFiles': source_audit['sourceFiles'],
    'sourceStateAssertions': {'passed': source_audit['passed'], 'count': len(source_audit['assertions'])},
    'unavailableHistoricalCaptures': unavailable_render_records,
    'renderBoundary': 'Named reviewed captures are recorded in work/feedback-closeout/render-review*.json, with newer captures frozen under their build ID. Evidence is attached only when the PNG and relevant source/model/data hashes still match. Historical overwritten paths do not contribute current evidence. These captures do not prove later source changes, physical results or complete event/3D acceptance. Unsupported header/caption cropping allegations were retracted.',
    'byScene': dict(by_scene),
}
write_json(HANDOFF / 'closeout-status.json', summary)
print(json.dumps({'clauses': len(responses), 'mappedScenes': len(by_scene), 'statusCounts': summary['statusCounts']}, indent=2))
