/* Execute the actual current import function with controlled local state.
 * Browser interactions and storage persistence require the separate player QA. */
const fs=require('fs'),path=require('path'),vm=require('vm'),crypto=require('crypto');
const repo=path.resolve(__dirname,'../..'),work=path.resolve(repo,'../work/feedback-closeout');
const raw=fs.readFileSync(path.join(repo,'film/player.js'));
const match=raw.toString('utf8').match(/^function importReview\(data\)\{[^\r\n]+/m);
if(!match)throw Error('Import function layout changed: inspect before updating this audit.');
const source=match[0],ledger=JSON.parse(fs.readFileSync(path.join(repo,'film/ledger.json'),'utf8'));
const id=ledger.clauses[0].id,assertions=[];
function trial(name,incoming,expectThrow,inspect){
 const original={schemaVersion:1,project:'theseus-astra',ratings:{a_cover:{score:7,note:'before'}},edits:{},clauses:{[id]:{reopened:true}},history:[]};
 const context={store:structuredClone(original),FILM_LEDGER:ledger,save(){},render(){}};
 vm.createContext(context);vm.runInContext(source,context);
 let threw=false,error='';try{context.importReview(incoming);}catch(e){threw=true;error=e.message;}
 const passed=threw===expectThrow&&inspect(context.store,original);
 assertions.push({name,passed,threw,error});
}
const valid=clauses=>({schemaVersion:1,project:'theseus-astra',ratings:{},edits:{},clauses});
trial('Incoming false never clears an existing global reopen',valid({[id]:{reopened:false}}),false,s=>s.clauses[id].reopened===true);
trial('Incoming empty entry never clears an existing global reopen',valid({[id]:{}}),false,s=>s.clauses[id].reopened===true);
trial('Import retains pre-import data in history',valid({}),false,s=>s.history.length===1&&s.history[0].ratings.a_cover.note==='before');
trial('Unknown clause is rejected before any mutation',valid({'F27.not_real.1':{reopened:true}}),true,(s,o)=>JSON.stringify(s)===JSON.stringify(o));
trial('Invalid reopen type is rejected before any mutation',valid({[id]:{reopened:'true'}}),true,(s,o)=>JSON.stringify(s)===JSON.stringify(o));
trial('Array clause entry is rejected before any mutation',valid({[id]:[]}),true,(s,o)=>JSON.stringify(s)===JSON.stringify(o));
const report={schemaVersion:1,scope:'Actual importReview function only; no DOM, touch, file-dialog or reload verification.',source:'astra/film/player.js',sourceSha256:crypto.createHash('sha256').update(raw).digest('hex'),assertions,passed:assertions.every(a=>a.passed)};
fs.mkdirSync(work,{recursive:true});fs.writeFileSync(path.join(work,'review-import-audit.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));if(!report.passed)process.exitCode=1;
