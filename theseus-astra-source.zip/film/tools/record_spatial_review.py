"""Record only the six 3D captures already directly inspected by this reviewer.

This is an explicit review receipt, not an automatic visual-quality test. Keep
the stated inspected build fixed; a later UI run needs a new review decision.
"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'work/feedback-closeout'
build='astra-4cdb287225a8'
source=ROOT/'work/qa-review'
report_raw=(source/'report.json').read_bytes()
report=json.loads(report_raw)
assert report['build']['id']==build
target=OUT/'spatial-snapshots'/build
target.mkdir(parents=True,exist_ok=True)

def freeze(path,raw):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        assert path.read_bytes()==raw, f'Immutable review artifact differs: {path}'
    else:
        path.write_bytes(raw)
    return {'artifact':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(raw).hexdigest()}

captures=[]
for kind in ['shell','finish','gt01','wheel','board','boardB']:
    raw=(source/f'{kind}-phone.png').read_bytes()
    item=freeze(target/f'{kind}-phone.png',raw)
    expected=next(p['changed'] for p in report['parts'] if p['kind']==kind)
    assert item['sha256']==expected
    captures.append({'kind':kind,**item,'inspection':'Directly viewed at native full image size. Real shaded perspective, exploded parts, materials and complete board switches are visible.'})
assert (source/'report.json').read_bytes()==report_raw
freeze(target/'report.json',report_raw)

sources=[]
for relative in ['astra/film/spatial-shell.js','astra/film/spatial-entry.js','astra/film/spatial-ui.js','astra/3d/parts/gt01.js','astra/3d/parts/scrollwheel.js','astra/film/data/board-spec.json']:
    raw=(ROOT/relative).read_bytes()
    sources.append({'currentSource':relative,**freeze(OUT/'spatial-source'/relative,raw)})
references=[]
for name in ['gateron-gt01-vertical-push.jpg','gateron-gt01-render.jpg','gateron-gt01-exploded.jpg']:
    relative='astra/refs/photos/'+name
    references.append({'artifact':relative,'sha256':hashlib.sha256((ROOT/relative).read_bytes()).hexdigest(),'inspection':'Supplied baseline reference directly viewed, with the recovered GT01-PLUNGER.md trace contract.'})

receipt={
 'schemaVersion':1,'captureBuild':build,'captureReport':(target/'report.json').relative_to(ROOT).as_posix(),
 'scope':'Appearance and source inspection only. Six real WebGL parts were directly viewed; their existence or rotation does not prove force dispersion, physical fit, selected-part identity or design acceptance.',
 'captures':captures,'sources':sources,'references':references,
 'findings':[
  'The finish view maps a code-generated light coat and dark exposed-composite pattern onto the actual shell and trigger geometry. Final color and pattern are explicitly unapproved.',
  'The GT01 cap uses 1.5 mm along by 2.1 mm across, a 0.75 mm radius and 0.80 mm proud top. The below-cover flange and nose remain as the recovered accepted construction.',
  'Both Plan 5 board variants show four holes and two complete main switches. The shared rear-notch adjustment equalizes the finished filleted straight lengths. Manufactured fit remains unvalidated.',
  'The actual shell reference has no computed structural stress field. The explicit lattice stress-spreading request remains partial.',
  'After this capture, the source fixes independent side-button press/explode composition and reads the A actuator size from the common spec. These source corrections require their own final workflow receipt and are not proved by the older combined-control screenshot hashes.'
 ]
}
(OUT/'spatial-review.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'build':build,'reviewed3D':len(captures),'sources':len(sources),'references':len(references)}))
