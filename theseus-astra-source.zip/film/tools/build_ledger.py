"""Build Astra's review ledger from byte-preserved feedback, without closing notes.

Run from any directory. --capture-context copies only the explicit context allowlist.
Normal generation is offline and uses that immutable snapshot and ledger-responses.json.
--check validates all source invariants and compares the expected output without writing.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import re

REPO = Path(__file__).resolve().parents[2]
HANDOFF = REPO / "handoff" / "astra"
CONTEXT = HANDOFF / "context"
OUTPUT = REPO / "film" / "ledger.json"
RESPONSES = HANDOFF / "ledger-responses.json"
STANDING_RESPONSES = HANDOFF / "standing-responses.json"
PRIMARY = REPO.parent.parent / "https-claude-ai-share-4ce6f186-6380" / "theseus-codex"
BASELINE = "7d8f926ebb8fca1653b3d30509ef6f8f60ac093e"

# This is a document/data allowlist. Never traverse or copy refs/scan or scene code.
CONTEXT_FILES = [
    "FEEDBACK.md", "HANDOFF.md", "PUBLISHING.md", "deck/DESIGN.md",
    "handoff/README.md", "handoff/K1-PROGRESS.md", "handoff/K2-PROGRESS.md",
    "handoff/GT01-PLUNGER.md", "handoff/INTEGRATOR-NOTES.md",
    "handoff/briefs/k-common.md",
    *[f"handoff/briefs/k{i}-prompt.md" for i in range(1, 9)],
    "handoff/codex/ASTRA-ULTRA-ASSIGNMENT.md", "handoff/codex/FEEDBACK-AUDIT.md",
    "handoff/codex/feedback-audit.json", "handoff/codex/EVIDENCE.md",
    "research/data/codex-verified.json", "research/codex-resources/RESOURCE-HANDOFF.md",
]

RULES = [
    ("astra-model", ["F37.1"], "Independent Astra ultra lead; only Astra max workers. The Sol-only rule is scoped to the other implementation."),
    ("isolation", ["F34.2", "F37.1"], "Build independently from imported baseline 7d8f926 in Astra's checkout. Sol and Claude worktrees and live sites remain separate. Do not contact Claude."),
    ("code-only", ["F34.1"], "All film visuals are code-drawn. No AI-generated raster assets. Use a coherent drawn style and human words."),
    ("private-scan", ["F0.6"], "Do not read, copy, commit, publish or redistribute refs/scan in this Astra task."),
    ("palette", ["F35.1", "F34.6", "F11.1", "F11.2"], "Theseus blue; sparse yellow comparisons and secondary items; neutral black/grey/white stage, type and chapter chrome; red faults. F35.1 does not restore rainbow chapter colors."),
    ("new-story", ["F32.2", "F33.4", "F33.6", "F33.7"], "New story, fewer denser scenes, built directly. ZERO compromises is the spine. Establish the rival problem, show the mechanism, then the strongest relevant player benefit."),
    ("important-concepts", ["F33.5"], "Retain and prioritize the 19 important but poorly executed concepts. Low old ratings are not permission to delete important information."),
    ("classroom", ["F33.8", "F27:G2"], "Use researched classroom demonstrations, state illustrative human-scale loads, and carry their load path into the actual mouse."),
    ("motion", ["F34.5", "F0.4", "F2.39", "F14.10", "F16.1"], "Animate causal input, geometry response and correction under the same condition. Keep the before case visible. Inspect event frames, not only a settled still."),
    ("context", ["F27:G3", "F27:cutouts", "F27:clk_front", "F27:anchors"], "Make the mouse region recognizable before zooming. Preserve coordinate frames, fixed supports/PCB, identical claimed parts, continuous arches and correct switch state."),
    ("glance", ["F14.10", "F15.1", "F27:G9"], "Header and meaningful geometry are visible in the opening frame. At a glance, show which direction is better and the supported magnitude; label peak experienced stress as lower is better."),
    ("type-style", ["F7.3", "F8.1", "F9.2", "F9.5", "F9.8", "F9.10", "F9.19", "F9.24"], "Large legible Inter text, plain type labels, limited rounding, no dot pills, no dot separators, no matched colored outlines, no peach skin, and gradients only selectively in Theseus headline/number type."),
    ("words", ["F21.8", "F27:G6", "F14.9"], "Use battery, weight for the concept, khz lowercase, Dual 8khz wired and wireless, and PIAKNOW'S in caps context. Never use pts or points as a metric."),
    ("numbers", ["F27:G5", "F12.3", "F27:ntr_densrank", "F18.4"], "One decimal precision per comparison. Preserve measured, manufacturer, owner, model and target distinctions. Include strong rivals and unknown values honestly. Wireless-only density ranking with wired comparators identified separately."),
    ("no-fabricated-results", ["F18.8", "F21.12", "F31.1", "F31.2"], "No invented aim gain, product latency, wheel group mean, competitor gap, strength test, battery guarantee or unqualified whole-device efficiency claim."),
    ("mobile", ["F23.1", "F23.2", "F24.1"], "Real viewport metadata and wrapping controls. Test isMobile+hasTouch portrait and landscape taps, reachable drawer close/navigation, keyboard-safe notes, and text editing."),
    ("review-identity", ["F24.1", "F29.2"], "Bind each note and edit to its captured scene ID. Save before navigation. Keep exact original notes and clause responses together; mapping or wording changes do not archive feedback."),
    ("review-reopen", ["F26.13", "F29.2"], "A deliberate substantive revision requires every clause answered with evidence or an explicit remaining reason. Reopen survives navigation, reload, import and future revisions. Partial or pending is never shown as closed."),
    ("review-cross-scene", ["F32.2", "F29.2"], "Look up clauses globally by stable ID. A shared requirement answered elsewhere has an addressed-in scene link and the same status everywhere, without duplicating closure."),
    ("review-local", ["F34.1", "F23.2", "F29.2"], "Reviews and text edits are browser-local in this player. Label storage truthfully and provide export/import. Do not imply the original artifact database or cloud synchronization is connected."),
    ("publication", ["F34.4", "F36.1", "F37.1"], "Astra gets its own Pages preview. Publish useful tested batches, show content build ID/version manifest, verify served runtime, and offer safe updates without losing unsaved review/text work."),
    ("deferred", ["F12.5", "F21.3", "F21.9", "F21.12", "F21.16", "F27:pltOptions", "F29.3", "F31.4"], "Keep explicit unknown/deferred design boundaries open. Improved drawings do not imply approval of the grip map, guide, bottom cover, shell switch notch, side seam or physical first-fit/rethread simulation."),
    ("geometry-latest", ["F30.24", "F30.25", "F30.8", "F31.3", "F27:sealed"], "Plan 5 plus final edits governs the PCB. GT01 lower walls still need thickening. Use straight wheel tread, POM everywhere and a magnetic encoder with an inspectable transparent top."),
    ("verification", ["F29.2", "F32.2", "F34.5", "F36.1"], "Syntax/build, deterministic first/mid/event/settled captures, causal and numerical checks, actual screenshot inspection, mobile interaction checks and exact tested publication identity are separate evidence."),
]

EXTRA_PRECEDENCE = [
    {"legacyId": "F11.2", "supersededBy": ["F34.6", "F35.1"], "disposition": "Neutral chapter chrome replaces the old rainbow chapter palette; blue Theseus and sparse yellow remain."},
    {"legacyId": "F34.6", "supersededBy": ["F35.1"], "disposition": "Only the all-yellow-primary interpretation is overridden. Neutral stage/type and red faults remain."},
    {"legacyId": "F34.3", "supersededBy": ["F37.1"], "disposition": "Astra task only: lead Astra ultra, all workers Astra max. Sol implementation keeps its separate model rule."},
    {"legacyId": "DESIGN:0.1/2b.1/8.4", "supersededBy": ["F27:G4", "F32.2"], "disposition": "Fewer denser scenes replaces many sparse slides; readability and generous simulation space remain."},
    {"legacyId": "F26.13", "supersededBy": ["F29.2"], "disposition": "A text/code/metadata change alone must never archive a note. Require substantive clause responses and retain reopen."},
    {"legacyId": "F27:arc:20-percent", "supersededBy": ["F31.2"], "disposition": "Approved 6% sooner is an ideal equal-travel/equal-path-speed example, not 20% or measured reaction time."},
    {"legacyId": "F27:sidebuttons:PTFE", "supersededBy": ["F31.3"], "disposition": "Use POM everywhere, including side-button pads; retain original raw spelling as history."},
    {"legacyId": "K1:idea59", "supersededBy": ["F12.6"], "disposition": "The taller fulcrum is abandoned; old K1 prompt cannot restore it."},
    {"legacyId": "F10.2/PUBLISHING:Claude-artifact", "supersededBy": ["F34.4", "F36.1", "F37.1"], "disposition": "Publish only the distinct Astra preview through root. Historical Claude URLs are read-only context."},
]

BOUNDARIES = [
    ("wheel-test-group", ["F27.wheel.1", "F27.wheel.2"], "missing-measurement", "No matched retail plastic/rubber wheel test group has been weighed. Group mean and claimed savings remain unavailable.", "Named samples/revisions, complete rotating-assembly boundary, common scale/protocol, recorded readings and uncertainty."),
    ("rival-rail-gaps", ["F27.clk_pomtune.3"], "missing-measurement", "No named competitor's measured rail clearances/tolerances with matched datums and load state.", "Product/sample/revision, reference planes, instrument and measurements under stated loads."),
    ("personal-arm-photo", ["F27.shcArms.1", "F27.shcArms.3", "F28.3"], "missing-reference", "Brock's exact broken G-Wolves arm/board photos are absent. A general schematic cannot be described as traced from them.", "Actual referenced photographs and separately qualified scale; retain shipping-break account as Brock's experience."),
    ("personal-tensioner-photos", ["F26.1", "F28.2"], "missing-reference", "The three exact tensioner photos from F28.2 are absent; supplied descriptions/equivalents are available.", "Actual photographs for exact matching, or clearly described reconstruction from available references."),
    ("tensioner-dimensions", ["F12.5", "F21.16"], "unknown-design", "Actual width/span/crown remain unknown; any dimensional example stays labelled.", "Brock's design dimensions or actual measured prototype."),
    ("bottom-cover", ["F27.pltPlate.1", "F27.pltSim.1", "F27.pltOptions.2"], "user-deferred", "All shown bottom-cover options were rejected and deferred. Their old simulations do not establish an approved part.", "A later explicitly requested development round and user decision."),
    ("shell-notch", ["F29.3", "F30.17", "F30.19"], "user-deferred", "Final power-switch shell notch is decided with the bottom cover. Show board variants A/window and B/edge as requested without final shell-fit approval.", "Bottom-cover round and shell interface decision."),
    ("side-seam", ["F17.2", "F21.16"], "user-deferred", "Side seam by trigger cutout is explicitly next iteration.", "Later authorized seam development round."),
    ("first-fit-rethread", ["F21.3", "F21.12"], "user-deferred", "Physical first-fit and rethread simulations belong to a later iteration. First-fit benefit remains in words; 90/70/0 are owner estimates of changed feel after reassembly.", "Validated first-fit/rethread model or physical test under stated assumptions."),
    ("grip-map", ["F21.9", "F27.srf_gripmap.1", "F27.srf_gripmap.2"], "approval-open", "Improved directional grip can be shown; final map has not been approved.", "Show completed improved pattern, then obtain Brock's requested review."),
    ("side-guide", ["F31.4"], "approval-open", "Fixed side-button guide shown for review is not accepted geometry.", "Brock's rating or note after seeing the actual completed guide."),
    ("gt01-choice", ["F27.clk_switch2.2"], "unknown-design", "GT01 may be a style/reference rather than the purchased switch. A derived SKU or scaled render is not a factory drawing.", "Selected component and verified supplier dimensions."),
    ("gt01-walls", ["F30.24"], "implementation-open", "The historical 0.45 mm repair was later rejected as too thin. Thicker lower walls must be checked against the available Gateron render.", "Independent implemented geometry plus inspected reference and event frames."),
    ("pcb-plan5", ["F30.25"], "implementation-open", "Plan 5 is approved only with the listed final edits. The source plan image is not evidence of a finished matching board.", "Final outline, mirrored holes, corrected wheel bay/rear notch, USB clearance and both switch variants verified in the new build."),
    ("battery-part", ["F21.8", "F21.15"], "unknown-design", "Battery selection is not final. LP402535JU is an example; tail placement targets mouse-center balance.", "Selected finished battery/holder mass and prototype center-of-mass test."),
    ("sensor-access", ["F21.6", "F27.sensor.1", "F27.sensor.2"], "conditional-design", "PAW3970 identity in the Viper V4 Pro is suspected per Brock, and Theseus access is a plan after exclusivity. No availability date is established.", "Verified identity and supplier availability; retain conditional language meanwhile."),
    ("razer-quote", ["F31.1", "F27.clk_switch.3"], "unverified-attribution", "Almost half is attributed to Razer staff online via Brock; a public quotation was not recovered.", "Recover the actual source and measurement conditions, or retain explicit attribution without turning it into a product result."),
    ("hall-runtime", ["F27.clk_switch.4", "F27.clk_switch.5", "F30.20"], "missing-product-measurement", "Hall has no emitter but consumes current. Replacement power, duty cycle, channels, MCU work and losses are not a measured Theseus runtime advantage.", "Matched complete-system power and latency/first-scroll tests with selected parts and firmware."),
    ("electrical-latency", ["F18.5", "F27.targets.2", "F27.arc.4"], "target-model-boundary", "70 microseconds is an electrical target, not the entire physical press-to-PC interval. 6% is a conditional local travel model.", "Matched physical press, switch threshold and PC-event timestamps before claiming product latency."),
    ("coating-mass", ["F21.10", "F27.srf_weight.2", "F27.elecsheet1.2"], "missing-measurement", "Net shell coating mass remains unnumbered. Conformal-film mass is unweighed; liquid density is not cured-film density.", "Before/after dry finished-part weighing and coating specification."),
    ("raw-scan", ["F0.6"], "excluded-private", "Raw Sora scan is outside this task and must never enter a commit, public artifact or resource package.", "No closure by acquisition; retain exclusion."),
    ("remote-review-db", ["F23.2", "F24.1", "F29.2"], "unavailable-history", "Original artifact ratings.history and edits database were not imported or live-verified. This ledger preserves the supplied F27 record only.", "Authorized export/import if those historical records later become available."),
    ("unavailable-opus-film", ["F37.1"], "unavailable-reference", "Newest embedded Opus film was inaccessible. Do not claim a comparison against that newer runtime.", "An actual accessible version and recorded build identity."),
]

SPECIAL_PENDING = {
    "wheel": "The required matched plastic/rubber wheel test group is absent. Source reports and PMM's specification do not close either test-group clause.",
    "clk_pomtune": "A new drawing can explain factory tuning, but the requested direct competitor tolerance comparison lacks named matched measurements.",
    "shcArms": "Exact personal broken-arm photographs are absent. Preserve the whole-board concept and owner account without claiming traced photographic fidelity.",
    "tensioner": "New scene and causal-motion verification are pending. Real tensioner dimensions remain unknown and an example must stay labelled.",
    "clk_switch": "New mechanism/power scene is pending. Razer's almost-half statement is an attribution via Brock, and Hall does not establish doubled runtime.",
    "clicks": "New geometry inspection is pending. The above-housing cap orientation and later thicker lower-wall request must both survive the independent rebuild.",
    "sidebuttons": "New uniform POM guide demonstration is pending. Brock has not accepted the fixed-guide geometry simply because it was shown.",
    "pltPlate": "The old proposal was rejected and deferred. Verify omission from the new pitch; this does not approve bottom-cover geometry.",
    "pltSim": "Bottom-cover development is explicitly deferred. Verify removal of the rejected simulation story, preserving the raw note.",
    "pltOptions": "The old options were rejected and the choice deferred. Verify film omission; do not mark the physical design complete.",
    "sealed": "The old optical slide must be removed while magnetic sensing, dust-path explanation and transparent inspection housing move into the new encoder story.",
    "shlGrams": "Verify removal of the unneeded standalone grams scene. The prior no-written-change extraction was wrong and is retained only as audit history.",
    "srf_gripmap": "New directional patterns and blends are pending; final grip-map approval remains open after the actual demonstration is shown.",
    "srf_weight": "Merge the useful coating story and keep net coating mass unnumbered until weighed. The old 0.49 g assertion is not an accepted measurement.",
    "elc_sheet2": "Remove the standalone sheet and preserve no-RGB content in the magnetic-encoder scene next to web software.",
    "sensor": "New scene must retain suspected PAW3970 identity and access-after-exclusivity as a conditional plan, with no invented date.",
}


def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def encode(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def capture(source: Path) -> None:
    manifest = []
    for relative in CONTEXT_FILES:
        assert "refs/scan" not in relative
        incoming = (source / relative).read_bytes()
        destination = CONTEXT / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists() and destination.read_bytes() != incoming:
            raise ValueError(f"Existing context differs: {relative}. Preserve its snapshot before recapturing.")
        destination.write_bytes(incoming)
        manifest.append({"path": relative, "bytes": len(incoming), "sha256": digest(incoming)})
    (CONTEXT / "manifest.json").write_bytes(encode({
        "schemaVersion": 1, "capturedDate": "2026-11-05", "baseline": BASELINE,
        "scope": "Exact feedback, original handoff and independently supplied research context. No film implementation copied.",
        "files": manifest,
    }))


def original_ratings(text: str) -> dict:
    pattern = re.compile(r'^\s+- `([^`]+)` \(([^\n]*)\) \*\*(\d+)/10\*\*(?:: "(.*)")?\s*$')
    result = {}
    for n, line in enumerate(text.splitlines(), 1):
        match = pattern.match(line)
        if not match:
            continue
        ident, description, score, note = match.groups()
        if ident in result:
            raise ValueError(f"Duplicate raw rating {ident}")
        result[ident] = {"score": int(score), "note": note, "sourceLine": n, "sourceText": line}
    return result


def numbered_items(text: str) -> list:
    lines = text.splitlines()
    starts = [(i, re.match(r'^- \*\*(F\d+\.\d+)\b', line)) for i, line in enumerate(lines)]
    starts = [(i, m.group(1)) for i, m in starts if m]
    items = []
    for i, ident in starts:
        end = i + 1
        while end < len(lines) and lines[end].strip() and not re.match(r'^- \*\*F\d+\.\d+\b|^## ', lines[end]):
            end += 1
        items.append({"id": ident, "sourceLine": i + 1, "sourceText": "\n".join(lines[i:end])})
    assert len({i["id"] for i in items}) == len(items)
    return items


def build() -> dict:
    manifest = load(CONTEXT / "manifest.json")
    for record in manifest["files"]:
        data = (CONTEXT / record["path"]).read_bytes()
        assert len(data) == record["bytes"] and digest(data) == record["sha256"], record["path"]
    feedback_path = CONTEXT / "FEEDBACK.md"
    feedback = feedback_path.read_text(encoding="utf-8-sig")
    audit = load(CONTEXT / "handoff/codex/feedback-audit.json")
    ratings = copy.deepcopy(audit["ratings"])
    raw = original_ratings(feedback)
    assert len(raw) == len(ratings) == 114
    assert sum(r["note"] is not None for r in ratings) == 100
    assert sum(len(r["clauses"]) for r in ratings) == 283
    assert sum(len(r["clauses"]) for r in ratings if r["note"] is not None) == 269
    responses = load(RESPONSES) if RESPONSES.exists() else {"schemaVersion": 1, "clauses": {}}
    assert responses["schemaVersion"] == 1
    changes = responses["clauses"]
    clauses = []
    source_items = numbered_items(feedback)
    source_index = {x["id"]: x for x in source_items}
    for rating in ratings:
        old = rating["legacyId"]
        original = raw[old]
        assert original["score"] == rating["score"], old
        assert original["note"] == rating["note"], f"Exact raw note mismatch: {old}"
        for clause in rating["clauses"]:
            reason = SPECIAL_PENDING.get(old, "Awaiting an independent Astra scene, a concrete clause response and relevant rendered/causal verification. A mapping alone is not completion.")
            item = {
                "id": clause["id"], "oldSlide": old, "originalNote": rating["note"],
                "clause": clause["text"], "sourceLine": original["sourceLine"],
                "status": "pending", "response": reason, "scenes": [], "evidence": [],
                "pendingReason": reason, "originalScore": rating["score"],
                "hasWrittenNote": rating["note"] is not None,
                "originalNoteSha256": digest((rating["note"] or "").encode("utf-8")),
                "source": f"handoff/astra/context/FEEDBACK.md:{original['sourceLine']}",
                "importedSource": rating["source"], "sourceClause": copy.deepcopy(clause),
                "sourceDisposition": rating["disposition"], "priority": rating["priority"],
                "relevantIds": copy.deepcopy(rating["relevantIds"]),
                "boundaryIds": [b[0] for b in BOUNDARIES if clause["id"] in b[1] or any(x in b[1] for x in rating["relevantIds"])],
            }
            if clause["id"] in changes:
                patch = changes[clause["id"]]
                assert not (set(patch) - {"status", "response", "scenes", "evidence", "pendingReason"}), clause["id"]
                item.update(copy.deepcopy(patch))
            assert item["status"] in {"pending", "implemented", "partial", "superseded", "deferred"}
            assert isinstance(item["response"], str) and item["response"].strip()
            assert isinstance(item["scenes"], list) and all(isinstance(x, str) and x for x in item["scenes"])
            assert len(set(item["scenes"])) == len(item["scenes"])
            assert isinstance(item["evidence"], list)
            if item["status"] == "implemented":
                assert item["evidence"], f"Implemented requires explicit evidence: {item['id']}"
                assert all(isinstance(e, dict) and e.get("kind") and e.get("result") and e.get("artifact") for e in item["evidence"]), item["id"]
                item["pendingReason"] = None
            elif item["status"] in {"pending", "partial", "deferred"}:
                assert item["pendingReason"], f"Open state needs explicit remaining reason: {item['id']}"
            clauses.append(item)
    assert len({x["id"] for x in clauses}) == 283
    assert not (set(changes) - {x["id"] for x in clauses}), "Response for unknown clause"
    assert len(next(r for r in ratings if r["legacyId"] == "sealed")["clauses"]) == 4
    assert sum(bool(r.get("auditCorrections")) for r in ratings) == 2
    standing = [{"id": ident, "feedbackIds": ids, "requirement": rule,
                 "sourceLines": {i: source_index[i]["sourceLine"] for i in ids if i in source_index},
                 "status": "pending", "response": "Standing rule; verify against each applicable scene and the final player.",
                 "pendingReason": "Awaiting a scoped standing-rule review with explicit evidence.",
                 "scenes": [], "evidence": []} for ident, ids, rule in RULES]
    standing_changes = load(STANDING_RESPONSES).get("standing", {}) if STANDING_RESPONSES.exists() else {}
    assert not (set(standing_changes) - {item["id"] for item in standing}), "Response for unknown standing rule"
    for item in standing:
        patch = standing_changes.get(item["id"], {})
        assert not (set(patch) - {"status", "response", "scenes", "evidence", "pendingReason"}), item["id"]
        item.update(copy.deepcopy(patch))
        assert item["status"] in {"pending", "implemented", "partial", "superseded", "deferred"}, item["id"]
        assert isinstance(item["response"], str) and item["response"].strip(), item["id"]
        assert isinstance(item["scenes"], list) and len(set(item["scenes"])) == len(item["scenes"]), item["id"]
        assert isinstance(item["evidence"], list), item["id"]
        if item["status"] == "implemented":
            assert item["evidence"] and all(isinstance(e, dict) and e.get("kind") and e.get("result") and e.get("artifact") for e in item["evidence"]), item["id"]
            item["pendingReason"] = None
        elif item["status"] in {"pending", "partial", "deferred"}:
            assert item["pendingReason"], item["id"]
    boundaries = [{"id": ident, "feedbackIds": ids, "type": kind, "status": "open",
                   "reason": reason, "needed": needed} for ident, ids, kind, reason, needed in BOUNDARIES]
    by_old = {r["legacyId"]: [c["id"] for c in r["clauses"]] for r in ratings}
    by_scene = {}
    for clause in clauses:
        for scene in clause["scenes"]:
            by_scene.setdefault(scene, []).append(clause["id"])
    return {
        "schemaVersion": 1, "title": "Theseus independent Astra feedback ledger",
        "baseline": BASELINE, "ratings": ratings, "clauses": clauses,
        "standing": standing, "boundaries": boundaries,
        "statistics": {"ratings": 114, "writtenNotes": 100, "clauses": 283,
                       "writtenNoteClauses": 269, "noWrittenNoteRecords": 14,
                       "standingStatusCounts": {s: sum(c["status"] == s for c in standing) for s in ("pending", "implemented", "partial", "superseded", "deferred")},
                       "statusCounts": {s: sum(c["status"] == s for c in clauses) for s in ("pending", "implemented", "partial", "superseded", "deferred")}},
        "sourceFeedbackItems": copy.deepcopy(audit["feedbackItems"]),
        "currentFeedbackItems": source_items,
        "precedence": copy.deepcopy(audit["precedence"]) + EXTRA_PRECEDENCE,
        "sourceAudit": {k: copy.deepcopy(v) for k, v in audit.items() if k not in {"ratings", "feedbackItems", "precedence"}},
        "sourceSnapshot": {"feedbackSha256": digest(feedback_path.read_bytes()),
                           "auditSha256": digest((CONTEXT / "handoff/codex/feedback-audit.json").read_bytes()),
                           "contextManifest": "handoff/astra/context/manifest.json"},
        "lookup": {"byLegacySlide": by_old, "byScene": by_scene},
        "reviewPolicy": {
            "storage": "browser-local", "sync": "none", "exportImportRequired": True,
            "mappingIsCompletion": False, "sourceHistoryIsAcceptance": False,
            "automaticArchiveOnTextOrMetadataChange": False,
            "originalNotesImmutable": True, "userReopenOverridesImplementationStatus": True,
            "reopenScope": "global clause ID, never only the current scene",
            "closure": "Only explicit clause evidence can support implemented. User acceptance is separate; reopened, pending, partial and deferred remain open.",
        },
        "sourceAuditCautions": [
            "Imported FEEDBACK.md line pointers predate later sections. Flat clauses sourceLine points to the captured current file; importedSource preserves history.",
            "The imported Markdown audit body still prints old sealed/shlGrams placeholders. The corrected JSON and intact raw notes govern; auditCorrections is retained inside each rating.",
            "Original DONE/archive labels and source answers are historical claims, not current Astra evidence or acceptance.",
            "No-note records are review records, not invented written user feedback. A written no comment remains an exact written note.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture-context", action="store_true")
    parser.add_argument("--source", type=Path, default=PRIMARY)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.capture_context:
        if args.check:
            parser.error("--check cannot capture or write context")
        capture(args.source)
    ledger = build()
    expected = encode(ledger)
    if args.check:
        assert OUTPUT.read_bytes() == expected, "Ledger differs from deterministic source/response generation"
    else:
        OUTPUT.parent.mkdir(parents=True, exist_ok=True)
        OUTPUT.write_bytes(expected)
    print(json.dumps({"ok": True, "checkedWithoutWrite": args.check,
                      "sha256": digest(expected), **ledger["statistics"]}, indent=2))


if __name__ == "__main__":
    main()
