"""Record this worker's completed visual inspection, never infer a new inspection.

The 20 named qa-full images were directly viewed. The other 14 were directly
viewed in qa-publish and verified byte-identical to qa-full. If these immutable
captures change, stop and perform a fresh visual review instead of updating a hash.
"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
capture = ROOT / 'work/qa-full'
prior = ROOT / 'work/qa-publish'
report = json.loads((capture / 'report.json').read_text(encoding='utf-8'))
assert report['build']['id'] == 'astra-a0424d26e0b5'
direct = set('a_direct a_rails a_bridge a_front a_seams a_spdt a_focus a_support a_ruler a_material a_lattice a_arches a_fillets a_pcb a_wiring a_shape a_repair a_inertia a_tolerance a_price'.split())
reviewed = []
for path in sorted(capture.glob('a_*-settled.png')):
    ident = path.name.removesuffix('-settled.png')
    raw = path.read_bytes()
    if ident in direct:
        method = 'Directly viewed at full image size by feedback_integrity.'
    else:
        assert (prior / path.name).read_bytes() == raw, ident
        method = 'Byte-identical to the qa-publish image directly viewed by feedback_integrity; equality verified.'
    reviewed.append({'scene': ident, 'artifact': path.relative_to(ROOT).as_posix(),
                     'sha256': hashlib.sha256(raw).hexdigest(), 'method': method})
assert len(reviewed) == 34 and direct.issubset({x['scene'] for x in reviewed})
result = {'schemaVersion': 1, 'build': report['build'], 'captureReport': 'work/qa-full/report.json',
          'reviewed': reviewed,
          'scope': 'Settled frame inspection plus separately reported first/middle/settled source states. This is not a complete mechanical event-frame sequence or a newer source/build acceptance.',
          'retracted': 'Apparent crop allegations from an earlier image presentation were contradicted by exact-file reopening and are not findings.'}
out = ROOT / 'work/feedback-closeout/render-review.json'
out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'build': report['build']['id'], 'reviewed': len(reviewed), 'direct': len(direct)}))

# These five full-size files were directly reopened after the root additions.
# The loadpaths and tolerance captures predate later source corrections; a
# consumer must compare source hashes rather than infer that they show a fix.
root_capture = ROOT / 'work/qa-root'
root_report = json.loads((root_capture / 'report.json').read_text(encoding='utf-8'))
assert root_report['build']['id'] == 'astra-780219233b48'
root_reviewed = []
for ident in ['a_loadpaths', 'a_budget', 'a_binning', 'a_density', 'a_tolerance']:
    path = root_capture / (ident + '-settled.png')
    root_reviewed.append({'scene': ident, 'artifact': path.relative_to(ROOT).as_posix(),
                          'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                          'method': 'Directly viewed at full image size by feedback_integrity.'})
(ROOT / 'work/feedback-closeout/render-review-root.json').write_text(json.dumps({
    'schemaVersion': 1, 'build': root_report['build'], 'captureReport': 'work/qa-root/report.json',
    'reviewed': root_reviewed,
    'scope': 'Five named settled frames only. Loadpaths overlap and tolerance pin changes occurred after this capture; these images do not prove those later fixes.',
}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'build': root_report['build']['id'], 'reviewed': len(root_reviewed)}))
