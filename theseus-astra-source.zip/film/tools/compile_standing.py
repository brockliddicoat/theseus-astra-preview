"""Compile the explicitly authored standing-rule review, without closing by mapping.

Revisit these decisions after source changes. Evidence hashes identify the actual
artifacts inspected; this is not an automatic acceptance or publication audit.
"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
HANDOFF = ROOT / 'astra/handoff/astra'

# id, status, scenes, specific response, remaining reason, evidence artifacts
REVIEWS = [
('astra-model', 'implemented', [],
 'Actual session_meta identities and every observed turn_context profile show the independent lead using gpt-6-astra/ultra and all three workers using gpt-6-astra/max. This covers the recorded sessions at this audit, not future workers.', None,
 ['astra/handoff/astra/model-evidence.json']),
('isolation', 'implemented', [],
 'The independent Astra checkout is based on 7d8f926ebb8fca1653b3d30509ef6f8f60ac093e. This lane copied only the explicit authoritative document/data allowlist and independently authored its ledger and audit tools. No primary Sol source was edited or imported, and this lane made no Claude contact. The separate preview is identified in the initial served-build receipt.', None,
 ['astra/handoff/astra/context/manifest.json', 'astra/handoff/astra/feedback-requirements.md', 'work/qa-live-first/report.json']),
('code-only', 'implemented', [],
 'The reviewed film modules construct the visuals from procedural canvas geometry and text; the build uses code geometry and bundled fonts. This review found no generated bitmap art. The new 3D integration must retain the same code-only boundary.', None,
 ['work/feedback-closeout/source/engine.js', 'work/feedback-closeout/source/build.py', 'work/feedback-closeout/scene-state-audit.json']),
('private-scan', 'implemented', [],
 'The context copy uses an explicit document/data allowlist, and the inspected build input manifest excludes refs/scan. This worker did not read or copy that private directory. The exclusion remains active for every later package.', None,
 ['astra/film/tools/build_ledger.py', 'astra/handoff/astra/context/manifest.json', 'work/qa-root/report.json']),
('palette', 'implemented', [],
 'The shared palette assigns blue to Theseus, sparse yellow to comparisons, neutral stage/type/chapter chrome and red to faults. The reviewed settled captures use that hierarchy; muted material colors identify parts without restoring rainbow chapters.', None,
 ['work/feedback-closeout/source/engine.js', 'work/feedback-closeout/render-review.json']),
('new-story', 'partial', ['a_cover', 'a_budget', 'a_loadpaths', 'a_close'],
 'The independent story compresses the original 114 rated scenes into a substantially smaller film, opens with ZERO COMPROMISES, and links weight, geometry, power and service mechanisms to their player benefits. The added common budget and equal-mass section give the pitch a stronger causal foundation.',
 'The latest mechanics and systems corrections plus full 3D/event review are still being integrated; the mapped story is not final acceptance.',
 ['work/feedback-closeout/source/build.py', 'work/feedback-closeout/scene-state-audit.json']),
('important-concepts', 'partial', ['a_density', 'a_inertia', 'a_loadpaths', 'a_tolerance', 'a_direct', 'a_pcb'],
 'All 19 F33.5 priority concepts remain represented and have individual clause responses. The new X2F box, actual reversal, fixed clearance geometry, mass budget and common stress/section example close specific earlier omissions.',
 'The latest source implements connected front/guide detail, arch reactions, a common-load beam graph, serviceable sensor supports and debounce waves. Remaining per-clause boundaries concern exact reference fidelity, missing measurements/photos, final finish appearance and requested force-dispersion behavior; they are listed individually.',
 ['astra/handoff/astra/ledger-closeout.tsv', 'work/feedback-closeout/scene-state-audit.json']),
('classroom', 'partial', ['a_ruler', 'a_material', 'a_lattice', 'a_arches', 'a_loadpaths'],
 'The ruler, equal-mass materials, frame, hanging-chain arch and section-morph models cite their sources and state illustrative loads or assumptions. The section example now carries its principle into ribs and arches and labels its half-peak-stress teaching threshold.',
 'The latest source adds checked constant-length arch spreading, matched 10 N statics, a normalized load-at-deflection rib example and a wood-grain analogy. Fresh captures of the final added grain sequence remain for visual review; the actual molded shell is not a solved or tested version of these classroom models.',
 ['work/feedback-closeout/scene-state-audit.json', 'work/feedback-closeout/source/loadpaths.js']),
('motion', 'partial', ['a_inertia', 'a_direct', 'a_tolerance', 'a_spdt', 'a_loadpaths'],
 'Checks execute real scene state functions and actual tolerance drawing primitives: reversal becomes negative velocity, aligned contact crosses first, SPDT states remain exclusive, clearance reaches physical contact and the section morph preserves mass. The old tolerance and frame defects were reported rather than accepted.',
 'Computed image-offset recovery, hot-swap sequencing and actual SPDT/front contacts now have checks. Final event-frame inspection of the changed mechanics, manufacturing, grip and 3D sequences remains required; settled frames alone do not close causal motion.',
 ['work/feedback-closeout/scene-state-audit.json', 'work/feedback-closeout/render-review.json']),
('context', 'partial', ['a_tolerance', 'a_rails', 'a_front', 'a_arches', 'a_board'],
 'The rebuilt tolerance view connects shell, trigger, cap, switch, support and fixed PCB, including six pins that physically cross the PCB. Shared guide dimensions, SPDT state and the Plan 5 board dimensions have explicit checks.',
 'The connected locator/enlargement and arch-foot geometry are now inspected and checked. Final integrated 3D part interfaces and their appearance still need the last build-specific visual review.',
 ['work/feedback-closeout/scene-state-audit.json']),
('glance', 'partial', ['a_loadpaths', 'a_density', 'a_budget'],
 'Meaningful geometry and clear headlines appear immediately in the reviewed film; comparisons label direction and magnitude, including peak stress as lower is better. The earlier apparent caption/header crop allegations were retracted and are not audit defects.',
 'Full-size captures confirmed the corrected load-deflection labels and clear new material graph. They exposed two force-arrow/label intersections and a first-frame percentage mismatch, which are now fixed in source; final captures must confirm those fixes and the new phone zoom.',
 ['work/feedback-closeout/render-review.json', 'work/qa-root/report.json']),
('type-style', 'partial', [],
 'The renderer uses Inter and plain labels, neutral hands, restrained corners and the shared color hierarchy. The source and reviewed settled captures establish the requested general type/style direction.',
 'The final 3D overlay and the newly changed diagram/event labels still need visual review at their actual rendered sizes.',
 ['work/feedback-closeout/source/engine.js', 'work/feedback-closeout/render-review.json']),
('words', 'implemented', ['a_close', 'a_power', 'a_battery', 'a_software'],
 'The inspected copy uses battery, weight, lowercase khz and PIAKNOW’S; comparison metrics do not use points. The software Polling row now explicitly says Dual 8khz wired and wireless.', None,
 ['work/feedback-closeout/source/intro.js', 'work/feedback-closeout/source/systems.js']),
('numbers', 'implemented', ['a_density', 'a_rank', 'a_market', 'a_budget', 'a_loadpaths'],
 'The reviewed comparisons keep a consistent precision within each metric and distinguish targets, owner samples, manufacturer claims and teaching calculations. Wireless density ranking, separately identified wired comparators, and missing values retain their stated boundaries. The common budget computes a residual shell allowance rather than presenting it as a weighed shell.', None,
 ['work/feedback-closeout/source/intro.js', 'work/feedback-closeout/source/budget.js', 'work/feedback-closeout/source/data/verified.json', 'work/feedback-closeout/scene-state-audit.json']),
('no-fabricated-results', 'implemented', ['a_direct', 'a_power', 'a_budget', 'a_loadpaths'],
 'The reviewed quantitative claims stay scoped: 6% is ideal equal-speed local travel, 18% power removal gives a conditional 21.95% runtime gain, targets remain targets, the budget is proposed, and section strength is an illustrative beam calculation. Missing wheel-group, rival-gap, coating-mass and physical-product tests remain explicit open boundaries.', None,
 ['work/feedback-closeout/scene-state-audit.json', 'astra/handoff/astra/feedback-requirements.md']),
('mobile', 'partial', [],
 'The recorded isMobile+hasTouch runs exercise portrait and landscape taps, scene-bound notes, text editing, import/reload and reachable close controls without horizontal overflow. Those receipts identify their tested builds.',
 'The final player revision adds review history, all standing/source records and later 3D controls; its complete touch/keyboard/update regression receipt is still pending.',
 ['work/qa-root/report.json', 'work/verify.js']),
('review-identity', 'implemented', [],
 'The current player captures scene IDs for notes and edits, saves before navigation, and archives prior note/score values on edits, score changes and clear. Exact source notes and original scores remain global. Actual touch/browser workflows at astra-51297997a0b6 verify Escape save/history, score clearing/history, scene attribution, downloaded export, file-chooser import, reload and a simulated update navigation. Final added phone zoom is tracked separately.', None,
 ['work/feedback-closeout/source/player.js', 'astra/film/tools/build_ledger.py', 'work/feedback-closeout/review-ui-proof.json']),
('review-reopen', 'implemented', [],
 'All 283 clauses have explicit responses and evidence or a remaining reason. Reopen is keyed by global clause ID; the actual import function preserves a local true reopen against incoming false or empty state and rejects malformed/unknown clause entries before mutation. Actual downloaded export, file-chooser import, reload and simulated-update navigation preserve the global reopen flag in the 26-check browser receipt; a data mapping still never closes it.', None,
 ['work/feedback-closeout/review-import-audit.json', 'work/feedback-closeout/review-ui-proof.json', 'astra/handoff/astra/ledger-closeout.tsv']),
('review-cross-scene', 'implemented', [],
 'The ledger keeps one record per stable clause ID with a global byScene index. The player uses that shared record for all scene links and a single reopen state; implemented and unresolved links are labelled according to the same status. The all-feedback view includes standing rules and exact numbered source items.', None,
 ['astra/film/tools/build_ledger.py', 'work/feedback-closeout/source/player.js']),
('review-local', 'implemented', [],
 'The player explicitly says browser-only storage and supplies export/import for ratings, notes, edits and reopened clauses. It retains pre-import data in local history and makes no cloud or original artifact-database synchronization claim. Earlier real touch/import/reload checks passed.', None,
 ['work/feedback-closeout/source/player.js', 'work/feedback-closeout/review-import-audit.json', 'work/qa-root/report.json']),
('publication', 'partial', [],
 'The separate brockliddicoat/theseus-astra-preview site was actually served and checked at initial 17-scene build astra-e5d88aa6d325. Its report records the URL and source identity. The current build generator hashes source/data/ledger inputs, and the player preserves local work before applying an update.',
 'The final expanded build has not yet been published and served-verified by this audit. Root owns that mutation and its exact tested artifact/commit receipt.',
 ['work/qa-live-first/report.json', 'work/feedback-closeout/source/build.py', 'work/feedback-closeout/source/player.js']),
('deferred', 'implemented', [],
 'The ledger preserves bottom-cover, switch-notch, side-seam and decorative deferrals and does not turn clearer illustrations into user approval. Missing final grip-map/guide approval, selected parts, actual first-fit/rethread results and measured coating mass remain explicit boundaries.', None,
 ['astra/handoff/astra/ledger-closeout.tsv', 'astra/handoff/astra/feedback-requirements.md']),
('geometry-latest', 'partial', ['a_direct', 'a_rails', 'a_board', 'a_wheel'],
 'The inspected source uses the later 0.80 mm illustrative GT01 lower wall, uniform POM main/side guides, straight wheel tread, magnetic encoding, four mirrored PCB holes and the 44.13 mm bay front. The rear nominal span is now 12.689535 mm so true one-millimeter fillets leave the same 12.054261 mm finished straight as the side notches; 13.09 mm is not misrepresented as a user-approved rear value.',
 'Final 3D geometry, both switch variants and the integrated wheel/board/housing interfaces still need the upcoming source and event review; manufactured fit remains separately unmeasured.',
 ['work/feedback-closeout/scene-state-audit.json']),
('verification', 'partial', [],
 'Source integrity, numerical/state invariants, actual tolerance drawing endpoints, import semantics, rendered settled-frame review and real mobile interactions have separate evidence receipts. No test report is treated as prototype proof or user acceptance.',
 'The 42-scene/126-frame and 28-workflow receipts are present. The final narrow GT01, dimension-label, independent side-press and shared-actuator fixes still need the root-owned final regression receipt and exact served publication identity.',
 ['work/feedback-closeout/scene-state-audit.json', 'work/feedback-closeout/review-import-audit.json', 'work/feedback-closeout/render-review.json', 'work/qa-root/report.json']),
]

# Final explicit source/appearance review. These dispositions concern the stated
# standing requirement, not a blanket acceptance of every related old clause.
FINAL_REVIEWS = {
 'new-story': ('The independently authored 42-scene film replaces the 114 rated scenes, opens with ZERO COMPROMISES, and repeatedly connects a rival problem, a visible mechanism and its relevant player benefit. The common weight budget and section example provide the shared argument; original notes and actual unresolved clauses remain visible.', ['work/feedback-closeout/source/build.py','work/feedback-closeout/scene-state-audit.json']),
 'important-concepts': ('All 19 F33.5 priority concepts are retained and prioritized, including the formerly weak cutouts, direct drive, front stop, arches, tolerance, density, inertia and grip. Low old scores did not cause important concepts to disappear. Their detailed clause responses still expose missing personal photos, measurements and requested design approval.', ['astra/handoff/astra/ledger-closeout.tsv','work/feedback-closeout/scene-state-audit.json']),
 'classroom': ('The film uses source-attributed ruler, frame, hanging-chain/arch, wood-grain and equal-mass-section demonstrations with stated loads or assumptions. It connects them to ribs, continuous mouse arches, shell/board ties and support positions. The 10 N static example and normalized 5 N/mm rib example stay separate from unvalidated whole-shell stress and material orientation.', ['work/feedback-closeout/scene-state-audit.json','work/feedback-closeout/source/mechanics.js','work/feedback-closeout/source/loadpaths.js']),
 'motion': ('The reviewed source and event captures show shared-clock input and before/after correction for reversal, direct drive, SPDT bounce, trigger stops, tolerance, arch supports, load paths, grip and manufacturing. Actual endpoint/state checks cover contact and support constraints. The final source also separates side-button press from explosion; final runtime verification remains a separate standing record.', ['work/feedback-closeout/scene-state-audit.json','work/feedback-closeout/render-review-astra-51297997a0b6.json','work/feedback-closeout/spatial-review.json']),
 'context': ('The revised diagrams locate the main trigger and marked cutouts on complete mouse outlines before enlargement. Shared main/side posts and pads, fixed PCB/pins, actual SPDT contact endpoints and continuous arches ending at their common rim pass checks. The last GT01 pass unifies the 2D and 3D 0.80 mm housing profile and openings.', ['work/feedback-closeout/scene-state-audit.json','work/feedback-closeout/source/mechanics.js','work/feedback-closeout/spatial-review.json']),
 'glance': ('The source supplies meaningful first-frame geometry and quantity labels; lower stress, lower density, mass, price and load-capacity directions are explicit. Full-size inspection confirmed the new material graph and corrected load-path labels. It found the first-frame material-percentage mismatch and local force/dimension-label intersections; those exact source issues are corrected in the final frozen mechanics revision.', ['work/feedback-closeout/source/mechanics.js','work/feedback-closeout/render-review-astra-51297997a0b6.json','work/feedback-closeout/render-review-astra-4cdb287225a8.json']),
 'type-style': ('The code film uses Inter, plain type labels, neutral hands/chrome and restrained rounding. The inspected full-size surface, electronics and mechanical captures show the requested hierarchy; decorative dot separators introduced during editing were removed. Phone diagram zoom provides a readable larger canvas with a fit control rather than hiding information outside the page.', ['work/feedback-closeout/source/engine.js','work/feedback-closeout/source/index.html','work/feedback-closeout/review-ui-proof.json']),
 'mobile': ('Actual isMobile+hasTouch workflows verify viewport metadata, portrait/landscape controls, scene note identity, Escape/history, file export/import, reload and safe simulated updates. The 28-check astra-4cdb287225a8 receipt adds the pannable phone diagram zoom without page overflow and reachable 3D close controls. Later spatial-only fixes and final served identity remain separately tested.', ['work/feedback-closeout/review-ui-proof.json','work/qa-root/astra-4cdb287225a8/report.json']),
 'geometry-latest': ('Plan 5 uses four mirrored mounting holes, the 44.13 mm bay front and a rear nominal span of 12.689535 mm, producing the same 12.054261 mm finished notch straight as the sides after true 1 mm fillets. The final source has matching 2D/3D 0.80 mm GT01 lower geometry, shared POM guides, straight wheel tread, magnetic encoding and an inspectable clear encoder top. Both board variants are real geometry; final cover/access and manufactured fit remain unapproved.', ['work/feedback-closeout/scene-state-audit.json','work/feedback-closeout/spatial-review.json','work/feedback-closeout/source/data/board-spec.json']),
}
REVIEWS = [(r[0], 'implemented', r[2], FINAL_REVIEWS[r[0]][0], None, FINAL_REVIEWS[r[0]][1]) if r[0] in FINAL_REVIEWS else r for r in REVIEWS]
records = {}
for ident, status, scenes, response, remaining, paths in REVIEWS:
    assert ident not in records
    evidence = []
    for relative in paths:
        raw = (ROOT / relative).read_bytes()
        evidence.append({'kind': 'scoped-standing-review', 'artifact': relative,
                         'sha256': hashlib.sha256(raw).hexdigest(),
                         'result': response,
                         'scope': 'Only the stated review scope and artifact identity; later changes require a refreshed review.'})
    records[ident] = {'status': status, 'response': response, 'pendingReason': remaining,
                      'scenes': scenes, 'evidence': evidence}
assert len(records) == 24
(HANDOFF / 'standing-responses.json').write_text(json.dumps({
    'schemaVersion': 1, 'scope': 'Explicit standing-rule review; independent of user acceptance.',
    'standing': records,
}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'standing': len(records), 'implemented': sum(r['status'] == 'implemented' for r in records.values()), 'partial': sum(r['status'] == 'partial' for r in records.values())}))
