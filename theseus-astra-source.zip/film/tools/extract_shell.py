"""Extract only authored shell parts from the imported, scan-derived GLB.

Never reads refs/scan. Omit the deferred bottom plate and hidden engravings.
"""
from pathlib import Path
import struct,json,base64,hashlib
root=Path(__file__).resolve().parents[2]
source=root/'3d/shell/shell-theseus-1seam.glb'
raw=source.read_bytes();length=struct.unpack_from('<I',raw,12)[0]
doc=json.loads(raw[20:20+length]);binary=raw[28+length:]
allowed={'body','core','sideFront','sideRear','triggerL','triggerR','usbC','wheelBay'}
def accessor(i):
    a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']]
    if v.get('byteStride'): raise ValueError('Unexpected interleaved input')
    sizes={5125:4,5123:2,5126:4};dims={'SCALAR':1,'VEC3':3}
    start=v.get('byteOffset',0)+a.get('byteOffset',0);size=a['count']*dims[a['type']]*sizes[a['componentType']]
    return {'data':base64.b64encode(binary[start:start+size]).decode(),'type':a['componentType'],'count':a['count'],'itemSize':dims[a['type']]}
meshes=[]
for node in doc['nodes']:
    if node['name'] not in allowed: continue
    for p in doc['meshes'][node['mesh']]['primitives']:
        meshes.append({'name':node['name'],'position':accessor(p['attributes']['POSITION']),'normal':accessor(p['attributes']['NORMAL']),'index':accessor(p['indices'])})
result={'source':'Authored baseline 3d/shell/shell-theseus-1seam.glb','sourceSHA256':hashlib.sha256(raw).hexdigest(),'rawScanIncluded':False,'omitted':['plate','engraveLT','engraveRT','engraveSerial','sideMark'],'meshes':meshes}
out=root/'film/data/shell-mesh.json';out.write_text(json.dumps(result,separators=(',',':')),encoding='utf-8');print(json.dumps({'meshes':len(meshes),'bytes':out.stat().st_size,'sourceSHA256':result['sourceSHA256']}))
