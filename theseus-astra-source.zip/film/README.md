# Theseus — independent Astra film

This is a new 42-scene code film built independently from the original imported baseline `7d8f926ebb8fca1653b3d30509ef6f8f60ac093e`. The lead used GPT-6 Astra at ultra effort; the three workers used GPT-6 Astra at max effort. Runtime session attestations are in `handoff/astra/model-evidence.json`.

## Open and review

Open `index.html` from the deliverable or use the independent GitHub Pages preview. Play, Replay, the scene selector and the timeline control the film. **Zoom diagram** opens a full-resolution, pannable 2D drawing; **Fit diagram** restores the overview. **3D parts** opens the scan-derived shell reference, GT01-style switch, wheel, board A/B models and a coating/etched-composite appearance concept. Drag a part to turn it; use the press/turn and explode controls to inspect motion.

**Rate & note** records a score and note for the current scene. **Original feedback** shows the exact original note, original score and clause-specific response, plus a global search for all clauses and later project instructions. Reopening a clause overrides the builder's implementation status. Implementation is not user acceptance.

Reviews and text replacements are saved **only in the current browser**. They do not sync to a server or between devices. Use **Export review** to download a JSON file and **Import review** on another browser. Imports retain the old local state in history and cannot silently clear a reopened clause. A newer hosted build offers an update; drafts are saved before navigation, and a storage failure blocks that navigation with an export recovery path.

## Edit and rebuild

The source package contains the original font/silhouette inputs, the independent scene sources, exact feedback context, procedural parts dependencies, a prebuilt 3D bundle and its input hashes. No `refs/scan` files or raw scan data are included. The shell inspector uses selected meshes from the authored baseline shell, with the deferred bottom plate and hidden engraving removed.

From the source package root:

```powershell
python film/tools/board_geometry.py
python film/tools/verify_ledger.py
python film/build.py --out film/dist
python -m http.server 8000 --directory film/dist
```

Open `http://localhost:8000` in a browser. The prebuilt spatial bundle permits an ordinary film rebuild without installing Node packages. If a procedural 3D source changes, the build deliberately fails until that bundle is regenerated:

```powershell
npm ci --prefix 3d
node film/tools/build_spatial.cjs
python film/build.py --out film/dist
```

The bundler also accepts `ASTRA_NODE_MODULES` pointing to an existing directory containing `three` and `esbuild`. It records every local input hash in `film/spatial.inputs.json`. The HTML build hashes scene code, template, board data, target/parts data, ledger, fonts, silhouette and spatial dependencies. Repeated builds from identical inputs produce identical HTML and version manifests.

## Authoritative editable data

- `film/data/spec.json`: mass, dimensions, price and endurance targets; component allowances. `AstraBudget()` computes the residual shell/skate allowance and total.
- `film/data/board-spec.json`: board parameters, derived outline, component envelopes and A/B switch-access variants. After changing parameters, run `python film/tools/board_geometry.py --write`, then rerun without `--write` to verify the generated fields.
- `handoff/astra/ledger-responses.json`: implementation responses. `python film/tools/build_ledger.py` regenerates `film/ledger.json`; original ratings/notes are immutable imported evidence.
- `film/intro.js`, `budget.js`, `mechanics.js`, `loadpaths.js`, `systems.js`: scene drawings and causal state.
- `film/player.js`, `index.html`, `spatial-ui.js`: transport, review persistence, text editing and responsive controls.
- `film/spatial-entry.js`, `spatial-shell.js`, and `3d/parts/`: 3D reference views.

## Evidence limits

This film explains a proposed design. Its target mass, endurance, electrical timing, materials models and placement geometry are not completed Theseus prototype measurements. Source notes distinguish manufacturer specifications, one-owner samples, Brock's reports and illustrative calculations. The ledger separately records absent matched wheel and rival-clearance measurements, missing personal reference photos, final component decisions, user approvals and deferred physical validation.

The accompanying review report and verification receipts identify the exact tested build. Browser WebGL verification used SwiftShader software rendering; it establishes functional geometry and controls, not GPU performance.
